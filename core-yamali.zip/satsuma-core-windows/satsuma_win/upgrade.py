"""Installation and update under the owner's eyes (owner's rules 2026-11-24).

* The only authorised account is typed by hand at the first installation (no signed owner yet).
  It must exist here, be enabled and be an administrator. Nothing changes it later: not an
  update, not the panel, not a request file. An update given --owner is refused.
* Every installation writes a manifest of what it brings (exe digests, every rule with its digest,
  the device policy). An update compares the installed manifest with the new one and lists what
  changes; nothing is installed until the person types "onaylıyorum". Otherwise the previous
  version stays as it is.
* Before an update the installed exes are copied to Program Files\\Satsuma\\previous. After it the
  owner is checked again; when the owner record changed or the owner account is no longer
  usable (missing, disabled, not an administrator), the update is rolled back: the previous exes
  go back and the service starts on them.

Kurulum ve güncelleme sahibinin gözü önünde: tek yetkili hesap ilk kurulumda elle yazılır ve
sonra hiçbir yolla değişmez; güncelleme önceki sürümle farkı listeler ve "onaylıyorum" yazılmadan
kurulmaz; sahip hesabında sorun çıkarsa güncelleme geri alınır, önceki sürüme dönülür.
"""
import hashlib
import json
import os
import shutil
from pathlib import Path

MANIFEST = 'install-manifest.json'
CONFIRM = 'onaylıyorum'
EXES = ('satsuma-core-windows.exe', 'satsuma-panel.exe')


def install_dir():
    return Path(os.environ.get('ProgramFiles', r'C:\Program Files')) / 'Satsuma'


def _digest(path):
    try:
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    except OSError:
        return None


def policy_digest(module):
    """A digest of the device policy's rules themselves (patterns, names, lists), not of a source file:
    inside the frozen exe there is no .py file (CI 2026-11-24). Politikanın kendisinin özeti."""
    parts = []

    def walk(code):
        for const in code.co_consts:
            if hasattr(const, 'co_consts'):
                walk(const)
            elif isinstance(const, (str, int, tuple, frozenset)):
                parts.append(repr(const))
    for name, test in getattr(module, 'CATEGORIES', ()):
        parts.append(name)
        walk(test.__code__)
    for name in sorted(dir(module)):
        value = getattr(module, name)
        if name.isupper() and isinstance(value, (tuple, frozenset, set, str)) and name != 'CATEGORIES':
            parts.append(name + '=' + repr(sorted(value) if isinstance(value, (set, frozenset)) else value))
    return hashlib.sha256('\n'.join(parts).encode()).hexdigest()


def manifest(exe, rules_folder):
    """What this installation brings. Bu kurulumun getirdikleri."""
    import yaml
    from satsuma import device_policy
    rules = {}
    for path in sorted(Path(rules_folder).glob('*.yaml')):
        for rule in yaml.safe_load(path.read_text(encoding='utf-8')) or []:
            if isinstance(rule, dict) and rule.get('id'):
                body = json.dumps(rule, sort_keys=True, ensure_ascii=False, default=str)
                rules[str(rule['id'])] = {'name': str(rule.get('name', '')), 'severity': str(rule.get('severity', '')),
                                          'sha256': hashlib.sha256(body.encode()).hexdigest()}
    policy = policy_digest(device_policy)
    panel = Path(exe).with_name('satsuma-panel.exe')
    from . import changes as behaviour
    return {'exe': _digest(exe), 'panel': _digest(panel) if panel.exists() else None, 'rules': rules,
            'device_policy': policy, 'change_ids': behaviour.ids()}


def load_manifest(directory):
    try:
        return json.loads((Path(directory) / MANIFEST).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None


def save_manifest(directory, data):
    path = Path(directory) / MANIFEST
    path.parent.mkdir(parents=True, exist_ok=True)
    path.with_suffix('.tmp').write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')
    os.replace(path.with_suffix('.tmp'), path)


def changes(old, new):
    """Plain Turkish lines: what the update changes. Güncellemenin değiştirdikleri."""
    if not old:
        from . import changes as behaviour
        return (['Önceki kurulumun kaydı yok: kurulacak olan ' + str(len(new['rules'])) + ' kural ve aygıt politikası.']
                + (behaviour.since(None)[1:] if new.get('change_ids') is not None else []))
    lines = []
    if old.get('exe') != new.get('exe'):
        lines.append(f"Hizmet exe'si değişiyor: {str(old.get('exe'))[:12]} → {str(new.get('exe'))[:12]}")
    if old.get('panel') != new.get('panel'):
        lines.append(f"Panel exe'si değişiyor: {str(old.get('panel'))[:12]} → {str(new.get('panel'))[:12]}")
    before, after = old.get('rules') or {}, new.get('rules') or {}
    for rid in sorted(set(after) - set(before)):
        lines.append(f"Yeni kural: {rid} {after[rid]['name']} ({after[rid]['severity']})")
    for rid in sorted(set(before) - set(after)):
        lines.append(f"Kaldırılan kural: {rid} {before[rid]['name']}")
    for rid in sorted(set(before) & set(after)):
        if before[rid]['sha256'] != after[rid]['sha256']:
            lines.append(f"Değişen kural: {rid} {after[rid]['name']}")
    if old.get('device_policy') != new.get('device_policy'):
        lines.append('Aygıt politikası değişiyor (hangi aygıtların kapatıldığı).')
    # Behaviour changes in the code, numbered (owner's rule 2026-11-24). Koddaki davranış değişiklikleri.
    if new.get('change_ids') is not None:
        from . import changes as behaviour
        lines.extend(behaviour.since(old.get('change_ids')))
    return lines or ['Kurallarda ve politikada değişiklik yok; yalnızca aynı sürüm yeniden kuruluyor.']


def owner_on_disk(directory):
    """The owner SID recorded (the service signed it). Kayıtlı sahip SID'i."""
    try:
        return str(json.loads((Path(directory) / 'approved-owner.json').read_text(encoding='utf-8')).get('sid') or '') or None
    except (OSError, ValueError):
        return None


def owner_problem(sid, runner):
    """None when the owner account is usable; else the reason. Sahip hesabı kullanılabilir mi?"""
    from .firewall import run_powershell
    if not sid:
        return 'imzalı sahip kaydı yok'
    script = ("$u = Get-LocalUser -SID '" + sid.replace("'", "") + "' -ErrorAction SilentlyContinue; "
              "if (-not $u) { @{found=$false} | ConvertTo-Json -Compress; return }; "
              "$admin = [bool](Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction SilentlyContinue | "
              "Where-Object { $_.SID.Value -eq $u.SID.Value }); "
              "@{found=$true; name=[string]$u.Name; enabled=[bool]$u.Enabled; admin=$admin} | ConvertTo-Json -Compress")
    row = json.loads(run_powershell(script, runner) or '{}')
    if not row.get('found'):
        return 'sahip hesabı bu bilgisayarda yok'
    if not row.get('enabled'):
        return 'sahip hesabı kapalı'
    if not row.get('admin'):
        return 'sahip hesabı artık yönetici değil'
    return None


def backup(folder=None):
    """Copy the installed exes aside before an update. Güncellemeden önce kurulu exe'ler yedeklenir."""
    folder = Path(folder or install_dir())
    keep = folder / 'previous'
    copied = []
    for name in EXES:
        if (folder / name).exists():
            keep.mkdir(parents=True, exist_ok=True)
            shutil.copy2(folder / name, keep / name)
            copied.append(name)
    return copied


def rollback_script(folder=None):
    folder = str(folder or install_dir()).replace("'", "''")
    return ("$dir = '" + folder + "'; "
            "Stop-Service -Name SatsumaCore -Force -NoWait -ErrorAction SilentlyContinue; "
            "try { (Get-Service -Name SatsumaCore).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(90)) } catch { }; "
            "Get-Process satsuma-panel -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue; "
            "foreach ($n in @('satsuma-core-windows.exe','satsuma-panel.exe')) { $p = Join-Path (Join-Path $dir 'previous') $n; "
            "if (Test-Path -LiteralPath $p) { Copy-Item -LiteralPath $p -Destination (Join-Path $dir $n) -Force } }; "
            "Start-Service -Name SatsumaCore -ErrorAction SilentlyContinue; "
            "@{status=[string](Get-Service -Name SatsumaCore).Status} | ConvertTo-Json -Compress")


def rollback(runner, folder=None):
    from .firewall import run_powershell
    return json.loads(run_powershell(rollback_script(folder), runner, timeout=180) or '{}')


def consent_text(sure):
    return 'onaysız kuruldu (--yes, otomatik sınama)' if sure else '"onaylıyorum" yazılarak kuruldu'


CONSENT_PENDING = 'install-consent-pending.json'
CONSENT = 'install-consent.json'
CONSENT_KEEP = 10  # builds remembered, so a rollback to an approved build is still approved


def write_consent_request(directory, sure, exes):
    """The installer's word on how this build was approved, for the service to sign at its next start.
    The installer runs as an administrator and cannot use the SYSTEM-only machine key.
    Kurulumun onay bilgisi; hizmet bir sonraki açılışta imzalar."""
    import time
    path = Path(directory) / CONSENT_PENDING
    path.parent.mkdir(parents=True, exist_ok=True)
    body = {'consent': 'unapproved' if sure else 'typed', 'text': consent_text(sure),
            'exes': {name: exes.get(name) for name in EXES}, 'time': time.time()}
    path.write_text(json.dumps(body, ensure_ascii=False), encoding='utf-8')
    return body


def _load_consents(directory, key):
    try:
        stored = json.loads((Path(directory) / CONSENT).read_text(encoding='utf-8'))
    except OSError:
        return {}, None
    except ValueError:
        return {}, 'onay kaydı okunamıyor'
    builds = stored.get('builds') if isinstance(stored, dict) else None
    if not isinstance(builds, dict) or not key.verify(json.dumps(builds, sort_keys=True).encode(), str(stored.get('signature'))):
        return {}, 'onay kaydının imzası bozuk'
    return builds, None


def settle_consent(directory, key, current, clock=None):
    """At every service start: was the running build installed with "onaylıyorum"?
    Returns (kind, fields): satsuma_started_approved, or satsuma_started_unapproved (critical) with the reason.
    Her açılışta: çalışan sürüm "onaylıyorum" yazılarak mı kuruldu?"""
    import time
    directory = Path(directory)
    exe = current.get('satsuma-core-windows.exe')
    if key is None:
        return 'satsuma_started_unapproved', {'severity': 'critical', 'reason': 'makine anahtarı yok; onay doğrulanamadı', 'exes': current}
    builds, broken = _load_consents(directory, key)
    pending_note = None
    pending = directory / CONSENT_PENDING
    if pending.exists():
        try:
            request = json.loads(pending.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            request = None
        if isinstance(request, dict) and exe and request.get('exes') == current:
            builds[exe] = {'consent': 'typed' if request.get('consent') == 'typed' else 'unapproved',
                           'text': str(request.get('text') or ''), 'panel': current.get('satsuma-panel.exe'),
                           'time': float(request.get('time') or 0), 'signed': (clock or time.time)()}
            kept = sorted(builds.items(), key=lambda item: item[1].get('signed', 0))[-CONSENT_KEEP:]
            builds = dict(kept)
            path = directory / CONSENT
            path.with_suffix('.tmp').write_text(json.dumps({'builds': builds, 'signature': key.sign(
                json.dumps(builds, sort_keys=True).encode())}, ensure_ascii=False), encoding='utf-8')
            os.replace(path.with_suffix('.tmp'), path)
            broken = None
        else:
            pending_note = 'kurulumun onay bilgisi çalışan exe ile eşleşmiyor'
        try:
            pending.unlink()
        except OSError:
            pass
    entry = builds.get(exe) if exe else None
    if entry is None:
        reason = broken or pending_note or 'bu exe için onay kaydı yok (kurulum aracı atlanmış olabilir)'
    elif entry.get('consent') != 'typed':
        reason = entry.get('text') or 'onaysız kuruldu'
    elif entry.get('panel') != current.get('satsuma-panel.exe'):
        reason = "panel exe'si onaylı kurulumdakinden farklı"
    else:
        return 'satsuma_started_approved', {'consent': entry.get('text'), 'exes': current}
    return 'satsuma_started_unapproved', {'severity': 'critical', 'reason': reason,
                                          'consent': (entry or {}).get('text') or 'onay yok', 'exes': current}


def record(directory, kind, **fields):
    """One line in events.jsonl from the installer (an administrator may write there). Kurulumun kaydı."""
    import time
    event = {'time': time.time(), 'kind': kind, **fields}
    try:
        Path(directory).mkdir(parents=True, exist_ok=True)
        with open(Path(directory) / 'events.jsonl', 'a', encoding='utf-8') as stream:
            stream.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + '\n')
    except OSError:
        pass
    return event
