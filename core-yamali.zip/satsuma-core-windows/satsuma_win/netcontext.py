"""Who opened the connection? (owner's choice C, 2026-11-25)

The owner's fixed PTR rule stays at full strength for any program that is unsigned, runs outside the
system and program folders, or cannot be identified. Only when every process talking to the peer is a
signed program from C:\\Windows, C:\\Program Files (x86) / C:\\Program Files or Defender's platform
folder is the peer recorded instead of blocked ('ptr_flood_trusted_process'): Windows, Defender, Windows
Update and installed browsers reach CDNs that have no PTR. OTX on a shared CDN front records instead of
blocking, and Defender / Windows Update connections are never blocked by OTX.

Bağlantıyı kim açtı? PTR kuralı imzasız, yazılabilir klasörden çalışan ya da tanınmayan her program için
aynen geçerli; yalnız bağlantıyı açan bütün süreçler sistem/program klasörlerinden imzalı programsa
engel yerine kayıt. OTX, ortak CDN önyüzünde engellemez; Defender ve Windows Update bağlantısını asla.
"""
import ipaddress

TRUSTED_FOLDERS = ('c:\\windows\\', 'c:\\program files\\', 'c:\\program files (x86)\\',
                   'c:\\programdata\\microsoft\\windows defender\\platform\\')
DEFENDER_UPDATE = ('c:\\programdata\\microsoft\\windows defender\\platform\\', 'c:\\program files\\windows defender\\',
                   'c:\\windows\\system32\\svchost.exe')

# The shared fronts of very many sites (restored for OTX only, owner's choice C 2026-11-25). An OTX pulse
# on such an address names one of thousands of sites behind it; it is recorded, not blocked.
SHARED = ('104.16.0.0/13', '104.24.0.0/14', '172.64.0.0/13', '162.158.0.0/15', '173.245.48.0/20',
          '188.114.96.0/20', '190.93.240.0/20', '141.101.64.0/18', '108.162.192.0/18', '198.41.128.0/17',
          '151.101.0.0/16', '199.232.0.0/16', '140.82.112.0/20', '185.199.108.0/22', '192.30.252.0/22',
          '142.250.0.0/15', '172.217.0.0/16', '216.58.192.0/19', '74.125.0.0/16', '13.107.0.0/16',
          '150.171.0.0/16', '52.123.0.0/16', '204.79.197.0/24', '20.190.128.0/18', '160.79.104.0/23',
          '3.160.0.0/14', '3.164.0.0/15', '3.172.0.0/15', '13.32.0.0/15', '13.224.0.0/14', '18.64.0.0/14',
          '54.230.0.0/16', '54.239.128.0/18', '99.84.0.0/16', '205.251.192.0/19')  # last line: AWS CloudFront
_NETWORKS = [ipaddress.ip_network(n) for n in SHARED]


def shared_network(ip):
    try:
        address = ipaddress.ip_address(ip)
    except ValueError:
        return None
    return next(('shared_cdn ' + str(n) for n in _NETWORKS if address in n), None)


def image_of(pid):
    """The full image path of a running process, or None (Windows: QueryFullProcessImageNameW)."""
    import ctypes
    from ctypes import wintypes
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    k.OpenProcess.restype = wintypes.HANDLE
    handle = k.OpenProcess(0x1000, False, int(pid))
    if not handle:
        return None
    try:
        size, buffer = wintypes.DWORD(32768), ctypes.create_unicode_buffer(32768)
        return buffer.value if k.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(size)) else None
    finally:
        k.CloseHandle(handle)


class Context:
    def __init__(self, signed, image=image_of):
        self.signed, self.image = signed, image
        self.cache = {}

    def path(self, pid):
        try:
            return self.image(pid)
        except (OSError, ValueError, AttributeError):
            return None

    def trusted(self, pid):
        """(True, path) for a signed program from the system or program folders; otherwise (False, path)."""
        path = self.path(pid)
        if not path or not path.lower().startswith(TRUSTED_FOLDERS):
            return False, path
        if path not in self.cache:
            try:
                self.cache[path] = bool(self.signed(path))
            except Exception:  # an unreadable signature is not trusted
                self.cache[path] = False
            if len(self.cache) > 2000:
                self.cache.clear()
        return self.cache.get(path, False), path

    def all_trusted(self, processes):
        """True only when there is at least one process and every one of them is trusted."""
        rows = [self.trusted(pid) for pid, _name in processes]
        return bool(rows) and all(ok for ok, _ in rows), [p for _, p in rows]

    def defender_or_update(self, processes):
        rows = [self.trusted(pid) for pid, _name in processes]
        return bool(rows) and all(ok and (p or '').lower().startswith(DEFENDER_UPDATE) for ok, p in rows)
