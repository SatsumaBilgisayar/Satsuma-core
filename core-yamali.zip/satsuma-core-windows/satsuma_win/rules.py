"""The Windows rule engine: reads the shared Satsuma YAML rule language and matches Sysmon events.

Two engines, one language (owner's decision 2026-11-24): Linux has satsuma.smart_rules,
Windows has this one. A rule is the same YAML mapping on both (id, name, severity,
classification, confidence, mitre, base_match, actions, ...) and passes the same schema
check (satsuma.rule_schema.validate_rule); only the event fields differ. The Windows rules
are kept in satsuma-core-windows/rules (the Linux engine loads every YAML file under rules/
and would refuse Windows fields). Whether a match stops the process is decided by the
shared satsuma.enforcement.eligible, exactly as on Linux.

Sources and fields (from Sysmon; every text is matched case-insensitively unless *_cs):

* win_proc (1)            cmd = CommandLine, exe = Image, parent = ParentCommandLine,
                          parent_exe = ParentImage, operation = start
* win_image (7)           exe = Image, file_path = ImageLoaded, details = signed=…;status=…
* win_remote_thread (8)   exe = SourceImage, target = TargetImage
* win_process_access (10) exe = SourceImage, target = TargetImage, details = GrantedAccess
* win_tamper (25)         exe = Image, details = Type
* win_network (3)         exe = Image, target = ip:port and host name, operation = outbound|inbound
* win_file (11)           exe = Image, file_path = TargetFilename, operation = create
* win_registry (12-14)    exe = Image, target = TargetObject, details = Details,
                          operation = CreateKey|DeleteKey|SetValue|DeleteValue|RenameKey
* win_dns (22)            exe = Image, target = QueryName, details = QueryResults

Matchers (all keys of base_match must match, AND; the values of one key are alternatives,
OR; *_not keys must match none): source, operation, cmd_contains, cmd_not_contains,
cmd_regex, cmd_regex_cs, cmd_not_regex, exe_contains, exe_regex, exe_not_regex,
parent_contains, parent_exe_regex, file_path, file_path_not (glob: * matches anything,
also \\), target_contains, target_regex, details_regex. cmd_contains is a plain substring of
the command line with runs of white space collapsed (Windows command lines are not argv
lists). A rule with an unknown matcher, a matcher of another source, or no positive
matcher besides source and operation is invalid and reported, never silently ignored. Text
is cut to 8192 characters before matching. Satsuma's own processes (the service and what
it starts) are not matched.

Windows kural motoru: ortak Satsuma YAML kural dilini okur, Sysmon olaylarını eşler. İki
motor, tek dil (sahibinin kararı 2026-11-24): Linux'ta satsuma.smart_rules, Windows'ta bu.
Kural iki tarafta da aynı YAML eşlemesidir ve aynı şema denetiminden geçer; yalnızca olay
alanları farklıdır. Windows kuralları satsuma-core-windows/rules klasöründedir. Eşleşmenin
süreci durdurup durdurmadığına Linux'taki gibi ortak satsuma.enforcement.eligible karar
verir. Tanınmayan, başka kaynağa ait ya da olumlu eşleyicisi olmayan kural geçersizdir ve
bildirilir. Satsuma'nın kendi süreçleri eşlenmez.
"""
import fnmatch
import os
import re
import sys
from pathlib import Path

import yaml

MAX_TEXT = 8192
SOURCES = {1: 'win_proc', 7: 'win_image', 8: 'win_remote_thread', 10: 'win_process_access', 25: 'win_tamper',
           3: 'win_network', 11: 'win_file', 12: 'win_registry', 13: 'win_registry', 14: 'win_registry',
           22: 'win_dns'}
FIELDS = ('cmd', 'exe', 'parent', 'parent_exe', 'file_path', 'target', 'details', 'operation')
# Which fields each source has: a matcher on a field the source lacks could never match.
# Her kaynağın alanları: kaynağın sahip olmadığı alana bakan eşleyici asla eşleşemezdi.
SOURCE_FIELDS = {
    'win_proc': {'cmd', 'exe', 'parent', 'parent_exe', 'operation'},
    'win_image': {'exe', 'file_path', 'details'},
    'win_remote_thread': {'exe', 'target'},
    'win_process_access': {'exe', 'target', 'details'},
    'win_tamper': {'exe', 'details'},
    'win_network': {'exe', 'target', 'operation'},
    'win_file': {'exe', 'file_path', 'operation'},
    'win_registry': {'exe', 'target', 'details', 'operation'},
    'win_dns': {'exe', 'target', 'details'},
}
# matcher -> (field, kind); kind: contains | not_contains | regex | regex_cs | not_regex | glob | not_glob | equals
MATCHERS = {
    'cmd_contains': ('cmd', 'contains'), 'cmd_not_contains': ('cmd', 'not_contains'),
    'cmd_regex': ('cmd', 'regex'), 'cmd_regex_cs': ('cmd', 'regex_cs'), 'cmd_not_regex': ('cmd', 'not_regex'),
    'exe_contains': ('exe', 'contains'), 'exe_regex': ('exe', 'regex'), 'exe_not_regex': ('exe', 'not_regex'),
    'parent_contains': ('parent', 'contains'), 'parent_exe_regex': ('parent_exe', 'regex'),
    'file_path': ('file_path', 'glob'), 'file_path_not': ('file_path', 'not_glob'),
    'target_contains': ('target', 'contains'), 'target_regex': ('target', 'regex'),
    'details_regex': ('details', 'regex'), 'operation': ('operation', 'equals'),
}
POSITIVE = ('contains', 'regex', 'regex_cs', 'glob')
NEGATIVE = ('not_contains', 'not_regex', 'not_glob')


def rules_dir():
    """Next to this package, or inside the frozen exe (PyInstaller --add-data ...;windows_rules)."""
    bundled = getattr(sys, '_MEIPASS', None)
    if bundled and Path(bundled, 'windows_rules').is_dir():
        return Path(bundled, 'windows_rules')
    return Path(__file__).resolve().parents[1] / 'rules'


def _text(value):
    return re.sub(r'\s+', ' ', str(value or '')).strip()[:MAX_TEXT]


def _list(value):
    return list(value) if isinstance(value, (list, tuple)) else [value]


def view(event):
    """The fields of one parsed Sysmon event (satsuma_win.sysmon.parse); None for other events."""
    source = SOURCES.get(event.get('id'))
    if source is None:
        return None
    get = lambda key: event.get(key) or ''
    row = {'source': source, 'record': event.get('record'), 'pid': get('ProcessId'), 'exe': get('Image'),
           'guid': get('ProcessGuid')}
    if source == 'win_proc':
        row.update(cmd=get('CommandLine'), parent=get('ParentCommandLine'), parent_exe=get('ParentImage'),
                   parent_pid=get('ParentProcessId'), operation='start')
    elif source == 'win_image':
        row.update(file_path=get('ImageLoaded'),
                   details='signed=%s;status=%s' % (get('Signed').lower(), get('SignatureStatus')))
    elif source in ('win_remote_thread', 'win_process_access'):
        row.update(pid=get('SourceProcessId'), exe=get('SourceImage'), guid=get('SourceProcessGuid'),
                   target=get('TargetImage'), target_pid=get('TargetProcessId'))
        if source == 'win_process_access':
            row['details'] = get('GrantedAccess')
    elif source == 'win_tamper':
        row['details'] = get('Type')
    elif source == 'win_network':
        port = get('DestinationPort')
        row.update(target=' '.join(x for x in (get('DestinationIp') + ':' + port, get('DestinationHostname')) if x),
                   operation='outbound' if get('Initiated').lower() == 'true' else 'inbound')
    elif source == 'win_file':
        row.update(file_path=get('TargetFilename'), operation='create')
    elif source == 'win_registry':
        operation = get('EventType')
        row.update(target=get('TargetObject'), details=get('Details'),
                   operation={'createkey': 'CreateKey', 'deletekey': 'DeleteKey', 'setvalue': 'SetValue',
                              'deletevalue': 'DeleteValue', 'renamekey': 'RenameKey'}.get(operation.lower(),
                                                                                         operation))
    elif source == 'win_dns':
        row.update(target=get('QueryName'), details=get('QueryResults'))
    for field in FIELDS:
        row[field] = _text(row.get(field))
    return row


def view_normalized(event):
    """A test event in the shared Linux test-case shape (source, cmd, exe, parent_cmd, ...) as a row.

    DeepSeek's test events use the field names of the Linux package schema. Linux paket şemasının
    alan adlarıyla yazılmış deneme olayı.
    """
    if not isinstance(event, dict) or event.get('source') not in SOURCE_FIELDS:
        return {'source': str((event or {}).get('source') if isinstance(event, dict) else ''), 'record': None,
                'pid': '', **{f: '' for f in FIELDS}}
    row = {'source': event['source'], 'record': None, 'pid': str(event.get('pid') or '')}
    names = {'cmd': 'cmd', 'exe': 'exe', 'parent': 'parent_cmd', 'parent_exe': 'parent_exe', 'file_path': 'file_path',
             'target': 'target', 'details': 'details', 'operation': 'operation'}
    for field, key in names.items():
        row[field] = _text(event.get(key))
    return row


def _glob(pattern):
    """A case-insensitive glob over a Windows path: * matches anything, also \\ and /."""
    normal = str(pattern).replace('/', '\\')
    return re.compile(fnmatch.translate(normal), re.IGNORECASE | re.DOTALL)


class RuleError(ValueError):
    pass


def compile_rule(rule):
    """Check one rule (shared schema + Windows fields) and compile it; raises RuleError."""
    from satsuma.rule_schema import validate_rule
    errors = validate_rule(rule)
    if errors:
        raise RuleError('; '.join(errors[:5]))
    match = rule['base_match']
    source = match.get('source')
    if source not in SOURCE_FIELDS:
        raise RuleError('%s: source %r is not a Windows source' % (rule['id'], source))
    checks, positive = [], 0
    for key, value in match.items():
        if key == 'source':
            continue
        if key not in MATCHERS:
            raise RuleError('%s: matcher %s is not supported on Windows' % (rule['id'], key))
        field, kind = MATCHERS[key]
        if field not in SOURCE_FIELDS[source]:
            raise RuleError('%s: %s has no %s field (%s)' % (rule['id'], source, field, key))
        values = [str(v) for v in _list(value)]
        if kind in ('contains', 'not_contains', 'equals'):
            compiled = [_text(v).lower() for v in values]
        elif kind in ('glob', 'not_glob'):
            compiled = [_glob(v) for v in values]
        else:
            try:
                compiled = [re.compile(v, 0 if kind == 'regex_cs' else re.IGNORECASE) for v in values]
            except re.error as exc:
                raise RuleError('%s: invalid %s: %s' % (rule['id'], key, exc)) from None
        checks.append((field, kind, compiled))
        positive += kind in POSITIVE
    if not positive:
        raise RuleError('%s: needs a positive matcher besides source and operation' % rule['id'])
    return {'rule': rule, 'source': source, 'checks': tuple(checks)}


def _check(kind, compiled, text):
    if kind == 'contains':
        return any(value in text.lower() for value in compiled)
    if kind == 'not_contains':
        return not any(value in text.lower() for value in compiled)
    if kind == 'equals':
        return text.lower() in compiled
    if kind in ('regex', 'regex_cs'):
        return any(pattern.search(text) for pattern in compiled)
    if kind == 'not_regex':
        return not any(pattern.search(text) for pattern in compiled)
    if kind == 'glob':
        return bool(text) and any(pattern.match(text) for pattern in compiled)
    if kind == 'not_glob':
        return not any(pattern.match(text) for pattern in compiled)
    return False


def matches(compiled, row):
    return compiled['source'] == row['source'] and all(
        _check(kind, values, row.get(field, '')) for field, kind, values in compiled['checks'])


def load_file(path):
    loaded = yaml.safe_load(Path(path).read_text(encoding='utf-8'))
    if loaded is None:
        return []
    if not isinstance(loaded, list):
        raise RuleError('YAML root must be a list')
    return loaded


class Engine:
    """Bundled Windows rules plus the activated DeepSeek rules; load errors are kept, never hidden."""

    def __init__(self, directory=None, extra=lambda: (), satsuma_exe=None, own_pid=None, clock=None):
        from satsuma.ai_guard import RuntimeGuard
        import time as _time
        self.timer = clock or _time.perf_counter
        # The Linux run-time guard: a DeepSeek rule that runs over its budget three times in ten
        # minutes is suspended and raises a critical alarm. Linux'un çalışma zamanı bekçisi.
        self.ai_guard = RuntimeGuard()
        self.directory = Path(directory) if directory else rules_dir()
        self.extra = extra
        self.satsuma_exe = (satsuma_exe or '').lower()
        self.own_pid = str(os.getpid() if own_pid is None else own_pid)
        self.rules, self.by_source, self.load_errors = [], {}, []
        self.reload()

    def reload(self):
        rules, errors, seen = [], [], set()
        files = sorted(self.directory.glob('*.yaml')) if self.directory.is_dir() else []
        if not files:
            errors.append({'file': str(self.directory), 'error': 'no_rule_files'})
        batches = []
        for path in files:
            try:
                batches.append((path.name, load_file(path), 'bundled'))
            except (OSError, ValueError, yaml.YAMLError) as exc:
                errors.append({'file': path.name, 'error': str(exc)[:300]})
        try:
            batches.extend((name, [rule], 'deepseek') for name, rule in self.extra())
        except Exception as exc:  # the bundled rules still load
            errors.append({'file': 'deepseek', 'error': type(exc).__name__ + ': ' + str(exc)[:300]})
        for name, batch, origin in batches:
            for index, rule in enumerate(batch):
                try:
                    compiled = compile_rule(rule)
                except (RuleError, TypeError, AttributeError, KeyError) as exc:
                    errors.append({'file': name, 'index': index, 'error': str(exc)[:300]})
                    continue
                if rule['id'] in seen:
                    errors.append({'file': name, 'index': index, 'error': 'duplicate id ' + rule['id']})
                    continue
                seen.add(rule['id'])
                compiled['origin'] = origin
                rules.append(compiled)
        by_source = {}
        for compiled in rules:
            by_source.setdefault(compiled['source'], []).append(compiled)
        self.rules, self.by_source, self.load_errors = rules, by_source, errors
        return self.stats()

    def compiled(self, rule_id):
        return next((c for c in self.rules if c['rule']['id'] == rule_id), None)

    def own(self, row):
        """Satsuma itself, or a program the service started (its PowerShell, Sysmon setup)."""
        exe = row.get('exe', '').lower()
        if self.satsuma_exe and (exe == self.satsuma_exe or row.get('parent_exe', '').lower() == self.satsuma_exe):
            return True
        return row.get('pid') == self.own_pid or row.get('parent_pid') == self.own_pid

    def match(self, event):
        """Findings for one parsed Sysmon event: one per matching rule."""
        row = view(event)
        if row is None or self.own(row):
            return []
        from satsuma import enforcement
        from satsuma.ai_guard import RULE_BUDGET_SECONDS
        findings = []
        for compiled in self.by_source.get(row['source'], ()):
            if compiled['origin'] == 'deepseek':
                rule_id = compiled['rule']['id']
                if not self.ai_guard.active(rule_id):
                    continue
                started = self.timer()
                hit = matches(compiled, row)
                if self.timer() - started > RULE_BUDGET_SECONDS:
                    self.ai_guard.strike(rule_id)
                if not hit:
                    continue
            elif not matches(compiled, row):
                continue
            rule = compiled['rule']
            finding = {'rule_id': rule['id'], 'rule': rule['name'], 'severity': rule['severity'],
                       'classification': rule['classification'], 'confidence': rule.get('confidence'),
                       'mitre': rule.get('mitre'), 'origin': compiled['origin'], 'source': row['source'],
                       'record': row['record'], 'pid': row['pid'], 'image': row['exe'],
                       **{k: row[k] for k in ('cmd', 'parent', 'parent_exe', 'file_path', 'target', 'details',
                                              'operation') if row.get(k)}}
            finding['stop'] = enforcement.eligible(finding)
            findings.append(finding)
        return findings

    def take_alarms(self):
        """Suspended DeepSeek rules since the last call, as the Linux finding (SATSUMA-AI-GUARD-001)."""
        from satsuma.ai_guard import suspended_finding
        return [suspended_finding(rule_id) for rule_id in self.ai_guard.take_alarms()]

    def stats(self):
        counts = {}
        for compiled in self.rules:
            counts[compiled['origin']] = counts.get(compiled['origin'], 0) + 1
        return {'rules': len(self.rules), 'by_origin': counts, 'sources': sorted(self.by_source),
                'load_errors': self.load_errors[:20], 'load_error_count': len(self.load_errors)}
