"""The Satsuma administrator password on Windows (owner's request 2026-11-25; the Linux design).

Linux (satsuma.dashboard_auth): a salted PBKDF2-SHA256 digest, never the password, 5 failures
then 5 minutes locked. On Windows the administrator's command line and the panel write request
files that the service (SYSTEM) carries out, so the password has to reach the service without
lying on disk:

* The salt and the iteration count are kept in ``owner-password-salt.json`` (readable by the
  administrator's command line). The derived key (the verifier) is kept only by the service,
  encrypted with DPAPI for SYSTEM (``owner-password.dpapi``).
* A request carries ``nonce``, ``at`` and ``proof`` = HMAC-SHA256(derived key, the request).
  The service accepts it only with a valid proof, within WINDOW seconds, with a nonce never seen
  before. Reading a request file therefore never gives the password or a reusable proof.
* The installer cannot use the SYSTEM-only DPAPI, so it leaves ``owner-password-pending.json``
  (salt, iterations, derived key) that the service takes at its next start and deletes. While a
  password exists, a new one is accepted only with a proof made with the old one.
* MAX_FAILURES wrong proofs within LOCKOUT seconds lock every request for LOCKOUT seconds; every
  refusal is a critical record. A verifier that disappears after one existed is a critical record.

An administrator who becomes SYSTEM can still read the verifier: the password guards Satsuma's own
commands, not the machine against its administrators.

Satsuma yönetici parolası (Linux tasarımı): parola hiçbir yerde saklanmaz; istekler parolanın
türettiği anahtarla HMAC imzalı gelir, hizmet doğrular; 5 hata 5 dakika kilit; her ret kritik kayıt.
"""
import hashlib
import hmac
import json
import os
import secrets
import time
from pathlib import Path

SALT_FILE = 'owner-password-salt.json'
VERIFIER = 'owner-password.dpapi'
PENDING = 'owner-password-pending.json'
STATE = 'owner-password-state.json'
ITERATIONS = 600_000
WINDOW = 300.0
MAX_FAILURES = 5
LOCKOUT = 300.0
MIN_LENGTH = 8


def derive(password, salt_hex, iterations=ITERATIONS):
    if not isinstance(password, str) or not password:
        raise ValueError('parola boş olamaz')
    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt_hex), int(iterations))


def _canonical(body):
    return json.dumps({k: v for k, v in body.items() if k != 'proof'}, sort_keys=True, ensure_ascii=False).encode('utf-8')


def proof(derived, body):
    return hmac.new(derived, _canonical(body), hashlib.sha256).hexdigest()


def salt(directory):
    """(salt, iterations) or None when no password was ever set."""
    try:
        row = json.loads((Path(directory) / SALT_FILE).read_text(encoding='utf-8'))
        return str(row['salt']), int(row['iterations'])
    except (OSError, ValueError, KeyError, TypeError):
        return None


def is_set(directory):
    return salt(directory) is not None


def sign(directory, password, body, clock=time.time):
    """The administrator's side: add nonce, time and proof to a request body."""
    found = salt(directory)
    if found is None:
        raise ValueError('Satsuma yönetici parolası belirlenmemiş')
    body = dict(body, nonce=secrets.token_hex(16), at=clock())
    body['proof'] = proof(derive(password, *found), body)
    return body


def check_strength(password):
    if len(password) < MIN_LENGTH:
        raise ValueError('parola en az %d karakter olmalı' % MIN_LENGTH)


def prepare(directory, password, old_password=None, clock=time.time):
    """Installer / --set-password: leave a new password for the service. Old one signs the change."""
    check_strength(password)
    new_salt = secrets.token_hex(16)
    body = {'salt': new_salt, 'iterations': ITERATIONS, 'verifier': derive(password, new_salt).hex()}
    if is_set(directory):
        if not old_password:
            raise ValueError('parolayı değiştirmek için eski parola gerekir')
        body = sign(directory, old_password, body, clock)
    path = Path(directory) / PENDING
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(body), encoding='utf-8')
    os.replace(temporary, path)
    return path


def ask(prompt='Satsuma yönetici parolası: ', getpass=None):
    """The password from SATSUMA_OWNER_PASSWORD (automated tests) or the keyboard, never echoed."""
    if os.environ.get('SATSUMA_OWNER_PASSWORD'):
        return os.environ['SATSUMA_OWNER_PASSWORD']
    if getpass is None:
        from getpass import getpass
    return getpass(prompt)


def for_request(directory, getpass=None):
    """The password for a request, asked only when one is set (otherwise the service refuses anyway)."""
    if not is_set(directory):
        print('Uyarı: Satsuma yönetici parolası belirlenmemiş; hizmet bu isteği reddedecek. '
              'Parolayı --set-password ile belirleyin.')
        return None
    return ask(getpass=getpass)


class Gate:
    """The service's side: settles a pending password and checks every request."""

    def __init__(self, directory, protect, unprotect, record, clock=time.time):
        self.dir, self.protect, self.unprotect = Path(directory), protect, unprotect
        self.record, self.clock = record, clock
        self.state = self._load_state()
        self._missing_reported = False

    def _load_state(self):
        try:
            state = json.loads((self.dir / STATE).read_text(encoding='utf-8'))
            if isinstance(state, dict):
                return state
        except (OSError, ValueError):
            pass
        return {'failures': [], 'locked_until': 0, 'nonces': {}, 'had_password': False}

    def _save(self):
        temporary = self.dir / (STATE + '.tmp')
        temporary.write_text(json.dumps(self.state), encoding='utf-8')
        os.replace(temporary, self.dir / STATE)

    def _verifier(self):
        try:
            return self.unprotect((self.dir / VERIFIER).read_bytes())
        except OSError:
            return None

    def settle(self):
        """Take a pending password; report a verifier that disappeared. Called at start and each poll."""
        pending = self.dir / PENDING
        if pending.exists():
            try:
                body = json.loads(pending.read_text(encoding='utf-8'))
                verifier = bytes.fromhex(str(body['verifier']))
                new_salt, iterations = str(body['salt']), int(body['iterations'])
                bytes.fromhex(new_salt)
            except (OSError, ValueError, KeyError, TypeError) as exc:
                body, problem = None, 'okunamadı: ' + type(exc).__name__
            else:
                problem = None
                if self._verifier() is not None:
                    problem = self.verify(body, consume=True)
            try:
                pending.unlink()
            except OSError:
                pass
            if problem:
                self.record('owner_password_set_refused', severity='critical', alarm='critical', reason=problem)
            else:
                temporary = self.dir / (VERIFIER + '.tmp')
                temporary.write_bytes(self.protect(verifier))
                os.replace(temporary, self.dir / VERIFIER)
                salt_tmp = self.dir / (SALT_FILE + '.tmp')
                salt_tmp.write_text(json.dumps({'salt': new_salt, 'iterations': iterations}), encoding='utf-8')
                os.replace(salt_tmp, self.dir / SALT_FILE)
                self.state.update(had_password=True, failures=[], locked_until=0)
                self._save()
                self._missing_reported = False
                self.record('owner_password_set', ok=True)
        if self.state.get('had_password') and self._verifier() is None and not self._missing_reported:
            self._missing_reported = True
            self.record('owner_password_missing', severity='critical', alarm='critical',
                        reason='Satsuma yönetici parolasının doğrulayıcısı silinmiş ya da okunamıyor')

    def verify(self, body, consume=True):
        """None when the request is genuine; otherwise the reason it is refused."""
        now = self.clock()
        if now < float(self.state.get('locked_until') or 0):
            return 'kilitli: çok sayıda yanlış parola'
        verifier = self._verifier()
        if verifier is None:
            return 'Satsuma yönetici parolası belirlenmemiş'
        nonce, at, given = body.get('nonce'), body.get('at'), body.get('proof')
        nonces = {k: v for k, v in self.state.get('nonces', {}).items() if now - float(v) < 2 * WINDOW}
        problem = None
        if not isinstance(given, str) or not isinstance(nonce, str) or not isinstance(at, (int, float)):
            problem = 'parola kanıtı yok'
        elif abs(now - float(at)) > WINDOW:
            problem = 'istek süresi geçmiş'
        elif nonce in nonces:
            problem = 'aynı istek ikinci kez geldi'
        elif not hmac.compare_digest(proof(verifier, body), given):
            problem = 'yanlış parola'
        if problem is None:
            if consume:
                nonces[nonce] = now
            self.state['nonces'] = nonces
            self._save()
            return None
        if problem in ('yanlış parola', 'parola kanıtı yok'):
            failures = [t for t in self.state.get('failures', []) if now - float(t) < LOCKOUT] + [now]
            self.state['failures'] = failures
            if len(failures) >= MAX_FAILURES:
                self.state['locked_until'] = now + LOCKOUT
        self.state['nonces'] = nonces
        self._save()
        return problem

    def check(self, body, what):
        """Verify one request; a refusal is a critical record. Returns the reason or None."""
        problem = self.verify(body)
        if problem:
            self.record('owner_password_refused', severity='critical', alarm='critical', request=str(what)[:80],
                        reason=problem)
        return problem
