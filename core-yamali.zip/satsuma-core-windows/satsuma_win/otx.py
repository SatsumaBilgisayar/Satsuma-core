"""AlienVault OTX on Windows: the Linux OTX decision itself, then block, end the connections, keep the block.

The query, the summary and the block decision are the Linux code (satsuma.otx:
request_indicator with verified TLS, summarize, _should_block): one pulse never blocks; at
least MIN_BLOCK_PULSES (2) and the Linux threshold (pulse_threshold 11) and a pulse updated in
the last recent_pulse_days (14), as config_examples/policy.json sets them on Linux. The DNS
servers, the gateway and remote support (TeamViewer, AnyDesk) are never blocked.

Every minute the remote addresses of this machine's connections are checked, at most
max_queries_per_cycle (12) new ones, each answer kept cache_ttl_seconds (3600); the queries
run in a background thread so the guard never waits for the network. A decided block goes
to Windows Firewall, the open connections to the address are ended (satsuma_win.connkill),
and the block is kept in the signed list (satsuma_win.fwauto). The key: ``--otx-key``
(administrator), handed to the service and kept with DPAPI for SYSTEM.

Windows'ta AlienVault OTX: Linux'un OTX kararının kendisi; ardından engel, bağlantıların
sonlandırılması ve kalıcı engel. Tek pulse engellemez; en az 2 pulse, Linux eşiği (11) ve son 14
günde güncellenmiş pulse gerekir. DNS sunucuları, ağ geçidi ve uzak destek asla engellenmez.
Sorgular arka planda çalışır; bekçi ağı beklemez. Anahtar ``--otx-key`` ile verilir, DPAPI ile saklanır.
"""
import json
import os
import threading
import time
from pathlib import Path

POLICY = {'enabled': True, 'blocker_mode': True, 'pulse_threshold': 11, 'recent_pulse_days': 14,
          'require_tls': True, 'match_mode': 'threshold'}
CACHE_TTL = 3600.0
MAX_QUERIES = 12
EVERY = 60.0
KEY_FILE = 'otx.key.dpapi'
REQUEST = 'otx-key.request'


def _protect(data):
    import win32crypt
    return win32crypt.CryptProtectData(data, 'Satsuma OTX key', None, None, None, 0x1)


def _unprotect(data):
    import win32crypt
    return win32crypt.CryptUnprotectData(data, None, None, None, 0x1)[1]


def write_key_request(state_dir, key):
    path = Path(state_dir) / REQUEST
    path.parent.mkdir(parents=True, exist_ok=True)
    (path.with_suffix('.tmp')).write_text(key, encoding='ascii')
    os.replace(path.with_suffix('.tmp'), path)


class Otx:
    def __init__(self, state_dir, record, block, protected, clock=time.time, query=None,
                 protect=_protect, unprotect=_unprotect, threads=True):
        self.dir, self.record, self.block, self.protected = Path(state_dir), record, block, protected
        self.clock, self.protect, self.unprotect, self.threads = clock, protect, unprotect, threads
        self.query = query or self._query
        self.cache, self.at, self.worker, self.results = {}, None, None, []
        self.counts = {'queried': 0, 'blocked': 0, 'kept_open': 0, 'errors': 0}

    def _query(self, ip, api_key):
        from satsuma import otx
        data, tls = otx.request_indicator(ip, api_key)
        return otx.summarize(ip, data, tls)

    def api_key(self):
        request = self.dir / REQUEST
        if request.exists():
            key = request.read_text(encoding='ascii', errors='replace').strip()
            request.unlink()
            if 16 <= len(key) <= 200 and key.isalnum():
                (self.dir / KEY_FILE).write_bytes(self.protect(key.encode('ascii')))
                self.record('otx_key', ok=True, status='SAVED')
            else:
                self.record('otx_key', ok=False, status='INVALID_KEY')
        try:
            return self.unprotect((self.dir / KEY_FILE).read_bytes()).decode('ascii')
        except Exception:  # no key yet, or another account's DPAPI: OTX stays off and says so in status
            return None

    def decide(self, item):
        from satsuma import otx
        return otx._should_block(item, POLICY)

    def _work(self, ips, api_key):
        for ip in ips:
            try:
                item = self.query(ip, api_key)
                self.counts['queried'] += 1
                self.results.append(item)
            except Exception as exc:  # the address is asked again after the cache time
                self.counts['errors'] += 1
                self.results.append({'ip': ip, 'error': type(exc).__name__ + ': ' + str(exc)[:120]})

    def check(self, connections):
        """Once a minute: start the queries for new remote addresses; act on the answers that came back."""
        events = []
        while self.results:
            item = self.results.pop(0)
            self.cache[item['ip']] = (self.clock(), item)
            if 'error' in item:
                continue
            ok, reason = self.decide(item)
            if not ok or item.get('pulse_count', 0) <= 0:
                continue
            # Owner's choice C (2026-11-25): a shared CDN front, or Defender / Windows Update, is recorded, not blocked.
            from .netcontext import shared_network
            why = self.protected(item['ip']) or shared_network(item['ip']) \
                or (self.trusted_ip(item['ip']) if getattr(self, 'trusted_ip', None) else None)
            if why:
                self.counts['kept_open'] += 1
                events.append(self.record('otx_not_blocked', ip=item['ip'], protected=why, pulses=item.get('pulse_count')))
                continue
            self.counts['blocked'] += 1
            events.append(self.block(item['ip'], 'otx', otx={k: item.get(k) for k in
                                                              ('pulse_count', 'reputation', 'reason', 'latest_pulse_age_days')}))
        now = self.clock()
        if (self.at is not None and now - self.at < EVERY) or (self.worker is not None and self.worker.is_alive()):
            return events
        self.at = now
        api_key = self.api_key()
        if not api_key:
            return events
        seen = sorted({c['remote'] for c in connections if c.get('remote')})
        fresh = [ip for ip in seen if not self.protected(ip)
                 and (ip not in self.cache or now - self.cache[ip][0] >= CACHE_TTL)][:MAX_QUERIES]
        if fresh:
            if self.threads:
                self.worker = threading.Thread(target=self._work, args=(fresh, api_key), daemon=True, name='satsuma-otx')
                self.worker.start()
            else:
                self._work(fresh, api_key)
        return events
