"""Read and judge a program's writable+executable memory for the record of its stop (SATSUMA-RAM-001).

The Windows counterpart of satsuma.ram.rwx_inspection (Linux 2.2.67). Owner's decision
2026-11-24: on Windows a program not where it should be (Temp, a user folder, anywhere
outside the Windows folder, Program Files and the approved folders) or with a thread started
from fileless memory is stopped as soon as its fileless writable+executable memory is seen,
without exception. Before that stop the process is held (NtSuspendProcess), the bytes of each
such region are read through the same handle (ReadProcessMemory) and judged, and the verdict
(malicious, clean or inconclusive) with its signs goes into the record of the stop. The
verdict never keeps a program running; if the stop fails the program is resumed, as privd
does on Linux. A program in its place without such a thread is recorded, not held.

The judging is the Linux code itself (satsuma.ram.rwx_inspection.judge, verdict and its
limits) plus the signs only Windows attack code shows: a thread started inside fileless
memory (strong; the owner's 2026-11-11 stop decision), PEB access through gs:[60h]/fs:[30h],
ROR-13 API name hashing and direct system call stubs (medium each).

Safety of the hold, as on Linux (satsuma.process_hold): the identity is the process id and
its creation time; a hold never lasts beyond MAX_SECONDS, a watchdog resumes it at the
deadline whatever the reading does; every hold is written to holds.json before the process
is suspended, and a restarted service resumes what an earlier one left held, so a crash
never leaves a program frozen. Critical processes, the service itself and anything exempt
are never held. Nothing read is stored: only sizes, addresses, sign names and a SHA-256 of
each region.

Programın yazılabilir+çalıştırılabilir belleğini durdurma kaydı için okur ve değerlendirir
(RAM-001). Linux'taki satsuma.ram.rwx_inspection'ın (2.2.67) Windows karşılığı. Sahibinin
kararı 2026-11-24: Windows'ta olmaması gereken yerden (Temp, kullanıcı klasörü; Windows
klasörü, Program Files ve onaylı klasörler dışı) çalışan ya da dosyasız bellekten iş parçacığı
başlatan program, dosyasız RWX belleği görüldüğü an istisnasız durdurulur. Durdurmadan önce
süreç bekletilir, bölgeler okunur ve değerlendirilir; karar (kötü, temiz, belirsiz) ve işaretleri
durdurma kaydına girer. Karar programı asla çalışır bırakmaz; durdurma başarısız olursa süreç
sürdürülür. Yerinde olup böyle iş parçacığı olmayan program kaydedilir, bekletilmez. Değerlendirme
Linux'un kendi kodudur; üstüne yalnızca Windows saldırı kodunun gösterdiği işaretler eklenir.
Bekletme güvenliği Linux'takiyle aynıdır: kimlik süreç numarası ve oluşturma zamanıdır;
bekletme MAX_SECONDS'ı aşmaz, bekçi süresi dolanı kendisi sürdürür; her bekletme süreç
durdurulmadan önce holds.json'a yazılır, yeniden başlayan hizmet önceki bekletmeleri
sürdürür. Okunan bellek saklanmaz.
"""
import hashlib
import json
import os
import re
import threading
import time
from pathlib import Path

from satsuma.ram import rwx_inspection as shared

STRONG, MEDIUM, WEAK = shared.STRONG, shared.MEDIUM, shared.WEAK
REGION_LIMIT, REGION_BYTES, TOTAL_BYTES = shared.REGION_LIMIT, shared.REGION_BYTES, shared.TOTAL_BYTES
TIME_LIMIT = shared.TIME_LIMIT
HOLD_SECONDS = shared.HOLD_SECONDS
MAX_SECONDS = 10
CHUNK = 64 * 1024
HOLDS = 'holds.json'

# mov reg, gs:[60h] (x64 PEB) | mov eax, fs:[30h] | mov reg, fs:[30h] (x86 PEB)
PEB_ACCESS = re.compile(rb'\x65\x48\x8b[\x04\x0c\x14\x1c\x24\x2c\x34\x3c]\x25\x60\x00\x00\x00'
                        rb'|\x64\xa1\x30\x00\x00\x00|\x64\x8b[\x05\x0d\x15\x1d\x25\x2d\x35\x3d]\x30\x00\x00\x00')
# ror r32, 0Dh: the API name hash of Metasploit / Cobalt Strike stagers
ROR13 = re.compile(rb'\xc1[\xc8-\xcf]\x0d')
# mov r10, rcx; mov eax, <number>; (test/jne ...)? syscall: a hand-made ntdll stub
SYSCALL_STUB = re.compile(rb'\x4c\x8b\xd1\xb8..\x00\x00(?:\x0f\x05|.{0,24}\x0f\x05)', re.S)


def windows_signs(data):
    """Signs only Windows attack code shows in one region's bytes."""
    signs = []
    if not data or not data.strip(b'\x00'):
        return signs
    found = PEB_ACCESS.search(data)
    if found:
        signs.append({'sign': 'peb_access', 'level': MEDIUM, 'offset': found.start()})
    found = ROR13.search(data)
    if found:
        signs.append({'sign': 'api_hash_ror13', 'level': MEDIUM, 'offset': found.start()})
    found = SYSCALL_STUB.search(data)
    if found:
        signs.append({'sign': 'direct_syscall_stub', 'level': MEDIUM, 'offset': found.start()})
    return signs


def judge(data):
    """The Linux signs (satsuma.ram.rwx_inspection.judge) and the Windows ones."""
    return shared.judge(data) + windows_signs(data)


verdict = shared.verdict
stops = shared.stops


def rwx_regions(info):
    """The fileless writable+executable regions of a process read by satsuma_win.memory."""
    from .memory import region_indicators
    return [r for r in info.get('regions') or () if 'anonymous_rwx' in region_indicators(r)]


def shape(info):
    """Where the regions are: a changed shape is judged again."""
    return tuple((r['base'], r['size']) for r in rwx_regions(info))


class Holds:
    """Every hold, written down before the process is suspended; resumed at the deadline or after a restart."""

    def __init__(self, directory=None, clock=time.monotonic, timer=threading.Timer):
        self.file = Path(directory) / HOLDS if directory else None
        self.clock, self.timer = clock, timer
        self.lock = threading.Lock()
        self.active = {}                      # (pid, created) -> {'process', 'deadline', 'timer'}

    def _save(self):
        if self.file is None:
            return
        rows = [{'pid': pid, 'created': created, 'wall_deadline': hold['wall_deadline']}
                for (pid, created), hold in self.active.items()]
        try:
            self.file.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.file.with_suffix('.tmp')
            temporary.write_text(json.dumps(rows), encoding='utf-8')
            os.replace(temporary, self.file)
        except OSError:
            pass

    def hold(self, process, pid, created, seconds=HOLD_SECONDS):
        """Suspend; returns {'held': bool, ...}. The watchdog resumes it at the deadline whatever happens."""
        seconds = max(1, min(int(seconds), MAX_SECONDS))
        key = (pid, created)
        with self.lock:
            if key in self.active:
                return {'held': False, 'status': 'already_held'}
            watchdog = self.timer(seconds, self.expire, args=(key,))
            watchdog.daemon = True
            self.active[key] = {'process': process, 'deadline': self.clock() + seconds,
                                'wall_deadline': time.time() + seconds, 'timer': watchdog}
            self._save()                         # written down before the process is suspended
        try:
            process.suspend()
        except Exception as exc:
            with self.lock:
                self.active.pop(key, None)
                self._save()
            return {'held': False, 'status': 'suspend_failed', 'error': type(exc).__name__ + ': ' + str(exc)[:200]}
        watchdog.start()
        return {'held': True, 'status': 'held', 'seconds': seconds}

    def release(self, key, resume=True):
        """Resume (or, after a stop, only forget) a hold; True when this call ended it."""
        with self.lock:
            hold = self.active.pop(key, None)
            self._save()
        if hold is None:
            return False
        try:
            hold['timer'].cancel()
        except Exception:  # an already finished watchdog
            pass
        if resume:
            hold['process'].resume()
        return True

    def expire(self, key):
        """The watchdog: the deadline passed, the process goes on. Bekçi: süre doldu, süreç sürer."""
        try:
            self.release(key)
        except Exception:  # an exited process needs no resume
            pass

    def recover(self, reader, record=None):
        """Resume what an earlier service left held (it stopped or crashed while reading)."""
        if self.file is None:
            return []
        try:
            rows = json.loads(self.file.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            return []
        resumed = []
        for row in rows if isinstance(rows, list) else ():
            try:
                pid, created = int(row['pid']), row['created']
                with reader.open(pid) as process:
                    if process is None or process.created() != created:
                        continue
                    process.resume()
                    resumed.append(pid)
            except Exception:  # the process exited; nothing to resume
                continue
        try:
            self.file.unlink()
        except OSError:
            pass
        if record and resumed:
            record('memory_hold_recovered', pids=resumed)
        return resumed


def read_regions(process, regions, deadline=None, clock=time.monotonic):
    """[(region, bytes or None, error)] within the byte and time budget of the Linux code."""
    out, total = [], 0
    for region in regions[:REGION_LIMIT]:
        if total >= TOTAL_BYTES or (deadline and clock() > deadline):
            out.append((region, None, 'budget'))
            continue
        size = min(region['size'], REGION_BYTES, TOTAL_BYTES - total)
        chunks, offset, error = [], 0, None
        while offset < size:
            try:
                chunk = process.read_memory(region['base'] + offset, min(CHUNK, size - offset))
            except OSError as exc:
                error = type(exc).__name__ + (':%s' % exc.errno if getattr(exc, 'errno', None) else '')
                break
            if not chunk:
                break
            chunks.append(chunk)
            offset += len(chunk)
        data = b''.join(chunks)
        total += len(data)
        out.append((region, data if data or not error else None, error))
    return out


def inspect(process, info, holds=None, hold=True, clock=time.monotonic, hold_seconds=HOLD_SECONDS,
            keep_held=False):
    """Hold, read, judge. A malicious process (any process with ``keep_held``) stays held for the stop.

    Returns {'verdict', 'signs', 'regions', 'held', ...}; the caller ends the hold with finish().
    Bekletir, okur, değerlendirir; kötü süreç (keep_held ile her süreç) durdurma için bekletilir.
    """
    from .memory import executing_from_fileless
    started = clock()
    pid, created = info['pid'], info.get('created')
    regions = rwx_regions(info)
    report = {'verdict': 'inconclusive', 'signs': [], 'regions': [], 'held': False,
              'raw_memory_persisted': False,
              'policy': {'inconclusive_stops': shared.INCONCLUSIVE_STOPS, 'hold_seconds': hold_seconds}}
    for address in executing_from_fileless(info)[:1]:
        report['signs'].append({'sign': 'thread_started_from_fileless_memory', 'level': STRONG,
                                'offset': 0, 'region': hex(address)})
    if not regions:
        report.update(verdict=verdict(report['signs']), reason='no_anonymous_rwx_region_now')
        return report
    if hold and holds is not None:
        answer = holds.hold(process, pid, created, hold_seconds)
        report['hold'] = answer
        report['held'] = bool(answer.get('held'))
    readable = True
    digest = hashlib.sha256(repr(shape(info)).encode())
    try:
        for region, data, error in read_regions(process, regions, deadline=started + TIME_LIMIT, clock=clock):
            row = {'start': hex(region['base']), 'size': region['size'], 'type': region.get('type'),
                   'protect': region.get('protect')}
            if data is None:
                readable = False
                row['status'] = 'unreadable:' + str(error)
            else:
                row.update(bytes_read=len(data), empty=not data.strip(b'\x00'),
                           sha256=hashlib.sha256(data).hexdigest(), status='judged')
                digest.update(row['sha256'].encode())
                for sign in judge(data):
                    sign['region'] = row['start']
                    report['signs'].append(sign)
            report['regions'].append(row)
        report['verdict'] = verdict(report['signs'], readable)
        report['memory_digest'] = digest.hexdigest()
        if not readable:
            report['reason'] = 'some_regions_unreadable'
    finally:
        report['elapsed_seconds'] = round(clock() - started, 3)
        if report['held'] and not keep_held and not stops(report):
            report['resumed'] = finish(holds, info)
    return report


def finish(holds, info, stopped=False):
    """End the hold: forget it after a stop, resume it otherwise. True when this call ended it."""
    if holds is None:
        return False
    try:
        return holds.release((info['pid'], info.get('created')), resume=not stopped)
    except Exception:  # the process exited meanwhile
        return False


def summary(report):
    """What goes into the record: never the bytes. Kayda giden: baytlar asla."""
    return {key: report[key] for key in ('verdict', 'signs', 'regions', 'held', 'resumed', 'reason', 'error',
                                         'memory_digest', 'elapsed_seconds', 'raw_memory_persisted', 'policy')
            if key in report}
