"""Sysmon: process monitoring on Windows (owner's decisions 2026-11-11).

Installation: Sysmon is downloaded from Microsoft (download.sysinternals.com)
at install time, its Authenticode signature must be valid and signed by
Microsoft Corporation, otherwise it is not installed and the reason is
reported. It is installed with Satsuma's configuration (owner's decision
2026-11-25: the maximal one): every event type that only records is recorded
with no filter and no exemption (process create/terminate, network, driver and
image loads, remote threads, raw reads, process access, file create, time and
stream hashes, registry, pipes, WMI, DNS, tampering, deleted and new
executable files; see EVENT_GROUPS). Nothing is exempt: not Satsuma's own
programs, not Sysmon. Types that change the machine (file blocking, deleted
file archive, clipboard capture) are not enabled. The event log is made 1 GiB.
Every event is matched against the Windows rules (satsuma_win.rules).

Reading: the service reads the new events every poll (EvtQuery on
Microsoft-Windows-Sysmon/Operational, from the last record read). A new
process is checked against the shared compile tool decision
(satsuma.build_tools) and stopped through its own handle unless Windows
Installer or Windows Update runs; for events 1, 7, 8, 10 and 25 the process
concerned is memory scanned at once instead of waiting for the next scan.

Sysmon: Windows'ta süreç izleme (sahibinin kararları 2026-11-11). Kurulum:
Sysmon kurulum sırasında Microsoft'tan indirilir; Authenticode imzası geçerli ve
Microsoft Corporation imzalı olmalıdır, değilse kurulmaz ve nedeni bildirilir.
Satsuma yapılandırmasıyla kurulur (sahibinin kararı 2026-11-25: en üst düzey):
yalnızca kaydeden her olay türü süzgeçsiz ve muafiyetsiz kaydedilir (EVENT_GROUPS).
Satsuma'nın kendi programları ve Sysmon dahil hiçbir şey muaf değildir. Makineyi
değiştiren türler (dosya engelleme, silinen dosya arşivi, pano yakalama) açılmaz.
Olay günlüğü 1 GiB yapılır; her olay Windows kurallarına (satsuma_win.rules) verilir. Okuma: hizmet her turda yeni olayları okur. Yeni süreç ortak
derleme aracı kararıyla denetlenir ve Windows Installer ya da Windows Update
çalışmıyorsa kendi tutamacıyla durdurulur; 1, 7, 8, 10 ve 25 olaylarında
ilgili süreç bir sonraki taramayı beklemeden hemen bellek taramasından geçer.
"""
import io
import json
import subprocess
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from .firewall import run_powershell, safe_run

URL = 'https://download.sysinternals.com/files/Sysmon.zip'
OWN_ACCESS = ('0x100c11', '0x410', '0x1001', '0x1000', '0x1010', '0x1410')  # Satsuma's own read-only / stop masks (memory reader, psutil)
CHANNEL = 'Microsoft-Windows-Sysmon/Operational'
EXE = 'Sysmon64.exe'
SCAN_EVENTS = (1, 7, 8, 10, 25)
PACKAGE_MANAGERS = frozenset(('msiexec.exe', 'trustedinstaller.exe', 'tiworker.exe'))
NS = '{http://schemas.microsoft.com/win/2004/08/events/event}'

# Maximal recording (owner's decision 2026-11-25): every event type that only records, with an empty
# "exclude" list, so nothing is filtered and nothing is exempt: not Satsuma's own programs, not Sysmon itself.
# Satsuma's own read-only access (OWN_ACCESS) is therefore recorded by Sysmon too; the guard ignores it in
# code (guard.check_sysmon), as it must. Left out on purpose, because they change the machine instead of
# only recording: FileBlockExecutable (27) and FileBlockShredding (28) BLOCK files, FileDelete (23) copies
# every deleted file to an archive folder and ClipboardChange (24) stores what the user copied.
# En üst düzey kayıt: yalnızca kaydeden her olay türü, boş "exclude" ile; hiçbir şey süzülmez, hiçbir
# program (Satsuma ve Sysmon dahil) muaf değildir. Makineyi değiştiren türler bilerek dışarıda.
EVENT_GROUPS = (
    ('process-create', 'ProcessCreate'),            # 1
    ('file-time', 'FileCreateTime'),                # 2
    ('network', 'NetworkConnect'),                  # 3
    ('process-terminate', 'ProcessTerminate'),      # 5
    ('driver', 'DriverLoad'),                       # 6
    ('image', 'ImageLoad'),                         # 7
    ('remote-thread', 'CreateRemoteThread'),        # 8
    ('raw-read', 'RawAccessRead'),                  # 9
    ('access', 'ProcessAccess'),                    # 10
    ('file', 'FileCreate'),                         # 11
    ('registry', 'RegistryEvent'),                  # 12, 13, 14
    ('stream', 'FileCreateStreamHash'),             # 15
    ('pipe', 'PipeEvent'),                          # 17, 18
    ('wmi', 'WmiEvent'),                            # 19, 20, 21
    ('dns', 'DnsQuery'),                            # 22
    ('file-delete-seen', 'FileDeleteDetected'),     # 26 (logs only; FileDelete 23 would archive)
    ('tampering', 'ProcessTampering'),              # 25
    ('executable-seen', 'FileExecutableDetected'),  # 29
)

CONFIG = ('<Sysmon schemaversion="4.90">\n  <HashAlgorithms>SHA256</HashAlgorithms>\n  <EventFiltering>\n'
          + ''.join('    <RuleGroup name="satsuma-%s" groupRelation="or">\n      <%s onmatch="exclude" />\n'
                    '    </RuleGroup>\n' % group for group in EVENT_GROUPS)
          + '  </EventFiltering>\n</Sysmon>\n')
# The Sysmon event log is made large because everything is recorded (bytes). Olay günlüğü büyütülür.
LOG_SIZE = 1024 * 1024 * 1024


def signature_script(path):
    quoted = "'" + str(path).replace("'", "''") + "'"
    return ("$s = Get-AuthenticodeSignature -LiteralPath " + quoted + "; "
            "@{status=[string]$s.Status; subject=[string]$s.SignerCertificate.Subject} | ConvertTo-Json -Compress")


def microsoft_signed(result):
    return result.get('status') == 'Valid' and 'O=Microsoft Corporation' in (result.get('subject') or '')


def install(target_dir, runner=safe_run, fetch=None):
    """Download, verify and install Sysmon; never installs an unverified file. Returns a result dict."""
    target_dir = Path(target_dir)
    fetch = fetch or (lambda url: urllib.request.urlopen(url, timeout=120).read())
    exe = target_dir / EXE
    download_error = None
    try:
        archive = zipfile.ZipFile(io.BytesIO(fetch(URL)))
        data = archive.read(EXE)
    except (OSError, zipfile.BadZipFile, KeyError) as exc:
        data, download_error = None, str(exc)[:300]
    if data is None:
        # Owner's rule 2026-11-25: a failed download never keeps the new configuration out. The Sysmon
        # already here is used, only after its Microsoft signature is checked again.
        # İndirme başarısızsa da yeni yapılandırma yüklenir: buradaki Sysmon, imzası yeniden denetlenip kullanılır.
        if not exe.exists():
            return {'ok': False, 'status': 'DOWNLOAD_FAILED', 'error': download_error}
    else:
        target_dir.mkdir(parents=True, exist_ok=True)
        exe.write_bytes(data)
    try:
        signature = json.loads(run_powershell(signature_script(exe), runner) or '{}')
    except (ValueError, RuntimeError, OSError) as exc:   # FirewallError is a RuntimeError; never installs then
        signature = {'status': '', 'subject': '', 'error': str(exc)[:300]}
    if not microsoft_signed(signature):
        exe.unlink()
        return {'ok': False, 'status': 'SIGNATURE_REJECTED', 'signature': signature,
                **({'download_error': download_error} if download_error else {})}
    config = target_dir / 'satsuma-sysmon.xml'
    config.write_text(CONFIG, encoding='utf-8')
    # Installed means the Sysmon64 service exists; "Sysmon64 -c" also succeeds when it is not installed.
    # Kurulu demek Sysmon64 hizmetinin var olmasıdır; "Sysmon64 -c" kurulu değilken de başarılı döner.
    present = runner(['sc.exe', 'query', 'Sysmon64'], capture_output=True, text=True, timeout=60).returncode == 0
    argv = [str(exe), '-accepteula', '-c', str(config)] if present else [str(exe), '-accepteula', '-i', str(config)]
    done = runner(argv, capture_output=True, text=True, timeout=300)
    if done.returncode != 0 and 'manifest' in ((done.stdout or '') + (done.stderr or '')).lower():
        # A leftover event manifest from an earlier Sysmon: remove it by force, install once more.
        # Önceki Sysmon'dan kalan olay bildirimi: zorla kaldırılır, bir kez daha kurulur.
        runner([str(exe), '-u', 'force'], capture_output=True, text=True, timeout=300)
        done = runner([str(exe), '-accepteula', '-i', str(config)], capture_output=True, text=True, timeout=300)
    if done.returncode != 0:
        return {'ok': False, 'status': 'INSTALL_FAILED', 'code': done.returncode,
                'error': ((done.stderr or '') + ' ' + (done.stdout or '')).replace('\x00', '').strip()[-600:]}
    # Everything is recorded now: a bigger event log keeps events from being overwritten before they are read.
    # Best effort; a failure never fails the install. Her şey kaydedildiği için günlük büyütülür.
    try:
        runner(['wevtutil.exe', 'sl', CHANNEL, '/ms:%d' % LOG_SIZE], capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.SubprocessError):
        pass
    channel = runner(['wevtutil.exe', 'gl', CHANNEL], capture_output=True, text=True, timeout=60)
    if channel.returncode != 0:
        return {'ok': False, 'status': 'CHANNEL_MISSING', 'error': (channel.stderr or channel.stdout or '')[-300:]}
    import hashlib
    return {'ok': True, 'status': 'UPDATED' if present else 'INSTALLED', 'signature': signature,
            'binary': 'downloaded' if download_error is None else 'already_here',
            'config_sha256': hashlib.sha256(config.read_bytes()).hexdigest(),
            **({'download_error': download_error} if download_error else {})}


def uninstall(target_dir, runner=safe_run):
    exe = Path(target_dir) / EXE
    if not exe.exists():
        return {'ok': True, 'status': 'NOT_INSTALLED'}
    done = runner([str(exe), '-u', 'force'], capture_output=True, text=True, timeout=120)
    return {'ok': done.returncode == 0, 'status': 'REMOVED' if done.returncode == 0 else 'REMOVE_FAILED'}


def parse(xml_text):
    """One Sysmon event as {'id', 'record', field: value}.

    Rendered events never carry a DTD; any input with one is refused before
    parsing, so no entity can be expanded. İşlenmiş olaylarda DTD olmaz; olan
    girdi ayrıştırılmadan reddedilir, hiçbir varlık açılamaz.
    """
    if '<!DOCTYPE' in xml_text or '<!ENTITY' in xml_text:
        raise ValueError('event with a DTD refused')
    root = ET.fromstring(xml_text)
    system = root.find(NS + 'System')
    event = {'id': int(system.findtext(NS + 'EventID')), 'record': int(system.findtext(NS + 'EventRecordID'))}
    for data in root.iter(NS + 'Data'):
        event[data.get('Name')] = data.text
    return event


def pids_to_scan(event):
    """The processes an event points at, for an immediate memory scan."""
    keys = {1: ('ProcessId',), 7: ('ProcessId',), 8: ('TargetProcessId', 'SourceProcessId'),
            10: ('TargetProcessId', 'SourceProcessId'), 25: ('ProcessId',)}.get(event['id'], ())
    found = []
    for key in keys:
        try:
            found.append(int(event.get(key) or 0))
        except ValueError:
            continue
    return [pid for pid in found if pid > 4]


# A process id is reused by Windows, and Sysmon may even write a stale GUID for it. A process that is
# running under an id NOW but was created after the event cannot be the one the event is about.
# Süreç numarası yeniden kullanılır. Olaydan sonra oluşturulmuş süreç, olayın süreci olamaz.
IDENTITY_SLACK = 2.0          # seconds between Sysmon's clock reading and the kernel's creation time
EPOCH_1601 = 11644473600      # seconds from 1601-01-01 (FILETIME) to 1970-01-01


def event_filetime(event):
    """The event's UtcTime as a Windows FILETIME (100 ns since 1601), or None when it has none."""
    text = str(event.get('UtcTime') or '').strip()
    if not text:
        return None
    from datetime import datetime, timezone
    for pattern in ('%Y-%m-%d %H:%M:%S.%f', '%Y-%m-%d %H:%M:%S'):
        try:
            moment = datetime.strptime(text, pattern).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        return (int(moment.timestamp()) + EPOCH_1601) * 10 ** 7 + moment.microsecond * 10
    return None


def started_after(created, not_after):
    """True when a process created at ``created`` (FILETIME) began after ``not_after`` (FILETIME):
    another process now holds the id. Unknown times never say so. Zaman bilinmiyorsa False."""
    if created is None or not_after is None:
        return False
    return created > not_after + int(IDENTITY_SLACK * 10 ** 7)


# With everything recorded, image loads (7) and process accesses (10) come by the thousand: a process they
# name is memory scanned at most this often (seconds). New processes (1), remote threads (8) and tampering
# (25) are always scanned at once. Çok sık gelen 7 ve 10 olaylarında aynı süreç bu sıklıktan fazla taranmaz.
BUSY_EVENTS = (7, 10)
SCAN_COOLDOWN = 30.0


def add_targets(targets, event, skip=()):
    """Add the processes an event points at to ``targets`` {pid: latest event FILETIME or None}, except those
    in ``skip``. None means no time bound is known for that id."""
    stamp = event_filetime(event)
    for pid in pids_to_scan(event):
        if pid in skip:
            continue
        old = targets.get(pid, 0)
        targets[pid] = None if (stamp is None or old is None) else max(old, stamp)


def _stamp(xml_text):
    """The record's TimeCreated (SystemTime) text, or None."""
    node = ET.fromstring(xml_text).find(NS + 'System/' + NS + 'TimeCreated')
    return node.get('SystemTime') if node is not None else None


class EventReader:
    """New Sysmon events since the last record read (win32evtlog.EvtQuery)."""

    LOOKBACK = 60.0

    def __init__(self, evtlog=None, clock=None):
        if evtlog is None:
            import win32evtlog as evtlog
        import time
        self.clock = clock or time.time
        self.evtlog, self.last, self.created = evtlog, None, self.clock()
        self.last_stamp = None      # TimeCreated of record ``last``: tells a cleared or replaced log
        self.resets = 0             # times the log was found replaced and the cursor started again

    def read(self, limit=2000):
        log = self.evtlog
        if self.last is None:
            # The first read takes the events since a minute before the reader was made: the service's
            # start takes minutes and a program started meanwhile must still be seen (owner's proof
            # 2026-11-24). İlk okuma, okuyucudan bir dakika öncesine kadarki olayları da alır.
            query = log.EvtQuery(CHANNEL, log.EvtQueryChannelPath | log.EvtQueryReverseDirection, '*')
            newest = log.EvtNext(query, 1)
            if not newest:
                self.last = 0
                return []
            window = int((self.clock() - self.created + self.LOOKBACK) * 1000)
            query = log.EvtQuery(CHANNEL, log.EvtQueryChannelPath,
                                 '*[System[TimeCreated[timediff(@SystemTime) <= %d]]]' % max(window, 1000))
            newest_xml = log.EvtRender(newest[0], log.EvtRenderEventXml)
            self.last = parse(newest_xml)['record']
            self.last_stamp = _stamp(newest_xml)
            recent = []
            while len(recent) < limit:
                batch = log.EvtNext(query, 100)
                if not batch:
                    break
                recent.extend(parse(log.EvtRender(handle, log.EvtRenderEventXml)) for handle in batch)
            recent = [e for e in recent if e['record'] <= self.last]
            return recent
        if self._log_replaced():
            # Record numbers start again after the log is cleared or Sysmon is installed anew: a cursor kept
            # from the old log would hide every new event. Günlük silinince ya da Sysmon yeniden kurulunca
            # kayıt numaraları başa döner; eski imleç bütün yeni olayları gizlerdi.
            self.last, self.last_stamp = 0, None
            self.resets += 1
        query = log.EvtQuery(CHANNEL, log.EvtQueryChannelPath,
                             '*[System[EventRecordID > %d]]' % self.last)
        events = []
        while len(events) < limit:
            batch = log.EvtNext(query, 100)
            if not batch:
                break
            for handle in batch:
                text = log.EvtRender(handle, log.EvtRenderEventXml)
                event = parse(text)
                events.append(event)
                if event['record'] >= self.last:
                    self.last, self.last_stamp = event['record'], _stamp(text)
        return events

    def _log_replaced(self):
        """The record the cursor stands on is gone or is another record (same number, other time)."""
        if not self.last or self.last_stamp is None:
            return False
        log = self.evtlog
        found = log.EvtNext(log.EvtQuery(CHANNEL, log.EvtQueryChannelPath,
                                         '*[System[EventRecordID = %d]]' % self.last), 1)
        if not found:
            return True
        return _stamp(log.EvtRender(found[0], log.EvtRenderEventXml)) != self.last_stamp
