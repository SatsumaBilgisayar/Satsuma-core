"""What the Windows panel shows, read from the service's records (no network, no service call).

The panel (satsuma_win.panel) only reads: %ProgramData%\\Satsuma\\events.jsonl (the last
TAIL events), state.json, and the live state of the SatsumaCore and Sysmon64 services and of
the suricata process. Nothing here changes anything. Kept apart from the window so it can be
tested without a screen.

Windows panelinin gösterdikleri; hizmetin kayıtlarından okunur (ağ yok, hizmete çağrı yok).
Panel yalnızca okur: events.jsonl'in son TAIL olayı, state.json ve SatsumaCore, Sysmon64
hizmetleri ile suricata sürecinin canlı durumu. Burada hiçbir şey değiştirilmez.
"""
import collections
import json
import os
import time
from pathlib import Path

TAIL = 6000
LIST = 300

STOPPED = ('stopped', 'stop_failed')
PROBLEM_WORDS = ('fail', 'error', 'reject', 'not_applied', 'unreadable', 'changed', 'mismatch')
ALERT_KINDS = ('install_incomplete', 'satsuma_ended_without_stop', 'owner_password_refused', 'owner_password_missing', 'owner_password_set_refused', 'satsuma_unexpected_access', 'firmware_changed', 'firewall_block_disabled', 'satsuma_started_unapproved', 'satsuma_tampered', 'satsuma_unexpected_access', 'update_rolled_back', 'account_enabled_disabled_again', 'suricata_alert', 'mitm_proxy_set', 'mitm_written_back', 'cert_quarantined', 'cert_added',
               'firewall_block_restored', 'firewall_baseline_changed', 'otx_not_blocked', 'block_skipped')


def state_dir():
    return Path(os.environ.get('ProgramData', r'C:\ProgramData')) / 'Satsuma'


def tail_lines(path, count=TAIL, chunk=1 << 16):
    """The last ``count`` lines of a file without reading all of it."""
    try:
        with open(path, 'rb') as stream:
            stream.seek(0, os.SEEK_END)
            end = position = stream.tell()
            data = b''
            while position > 0 and data.count(b'\n') <= count:
                position = max(0, position - chunk)
                stream.seek(position)
                data = stream.read(end - position)
    except OSError:
        return []
    lines = data.split(b'\n')
    if position > 0:
        lines = lines[1:]
    return [line.decode('utf-8', 'replace') for line in lines if line.strip()][-count:]


def load_events(path, count=TAIL):
    events = []
    for line in tail_lines(path, count):
        try:
            event = json.loads(line)
        except ValueError:
            continue
        if isinstance(event, dict) and isinstance(event.get('kind'), str):
            events.append(event)
    return events


def load_state(path):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def when(value, now=None):
    try:
        stamp = float(value)
    except (TypeError, ValueError):
        return '-'
    now = time.time() if now is None else now
    fmt = '%H:%M:%S' if time.localtime(stamp)[:3] == time.localtime(now)[:3] else '%d.%m %H:%M'
    return time.strftime(fmt, time.localtime(stamp))


def leaf(path):
    return str(path or '').replace('/', '\\').rsplit('\\', 1)[-1]


def short(event, limit=240):
    body = {k: v for k, v in event.items() if k not in ('time', 'kind', 'regions', 'inspection', 'record')}
    text = json.dumps(body, ensure_ascii=False, default=str)[1:-1]
    return text if len(text) <= limit else text[:limit] + '…'


def is_problem(event):
    kind = event['kind']
    return (event.get('ok') is False or any(w in kind for w in PROBLEM_WORDS)) and kind != 'suricata_alert'


def live():
    """Services and Suricata now (Windows). Hizmetler ve Suricata'nın şimdiki durumu."""
    out = {'service': None, 'sysmon': None, 'suricata_pid': None}
    try:
        import psutil
    except ImportError:
        return out
    for key, name in (('service', 'SatsumaCore'), ('sysmon', 'Sysmon64')):
        try:
            out[key] = psutil.win_service_get(name).status()
        except Exception:  # not installed, or not Windows
            out[key] = None
    for process in psutil.process_iter(['name', 'pid']):
        if (process.info.get('name') or '').lower() == 'suricata.exe':
            out['suricata_pid'] = process.info['pid']
            break
    return out


def summary(events, state=None, now_live=None, now=None):
    """Everything the single page shows. Tek sayfanın gösterdiği her şey."""
    state = state or {}
    now_live = now_live or {}
    now = time.time() if now is None else now
    kinds = collections.Counter(e['kind'] for e in events)
    last = {}
    for e in events:
        last[e['kind']] = e

    blocks = [e for e in events if e['kind'] == 'blocked']
    stops = [e for e in events if e.get('outcome') in STOPPED]
    otx_blocks = [e for e in blocks if e.get('rule') == 'otx']
    suricata_alerts = [e for e in events if e['kind'] == 'suricata_alert']
    rule_findings = [e for e in events if e['kind'] == 'rule_finding']
    memory = [e for e in events if e['kind'] == 'memory_finding']

    problems = {}
    for e in events:
        if is_problem(e):
            row = problems.setdefault(e['kind'], {'kind': e['kind'], 'count': 0, 'first': e.get('time'), 'event': e})
            row['count'] += 1
            row['event'] = e
    for e in events:  # a later success clears an earlier failure of the same step
        if e.get('ok') is True and e['kind'] in problems and e.get('time', 0) >= problems[e['kind']]['event'].get('time', 0):
            problems.pop(e['kind'])

    sur_pid = now_live.get('suricata_pid')
    if sur_pid:  # Suricata runs now: its earlier install attempts are history, not a problem
        for kind in ('suricata_install', 'startup_suricata', 'suricata_start_failed'):
            problems.pop(kind, None)
    service = now_live.get('service')
    sysmon = now_live.get('sysmon')
    otx_key = last.get('otx_key')
    fw = (state.get('startup') or {}).get('firewall_auto') or (last.get('startup_firewall_auto') or {})
    updated = state.get('updated_at')

    day = now - 86400
    recent_mitm = sum(1 for e in events if e['kind'] == 'mitm_proxy_set' and (e.get('time') or 0) >= day)
    recent_certs = sum(1 for e in events if e['kind'] == 'cert_quarantined' and (e.get('time') or 0) >= day)

    def tile(name, text, level):
        return {'name': name, 'text': text, 'level': level}

    tiles = [
        tile('Hizmet', {'running': 'Çalışıyor', 'stopped': 'Durdu', None: 'Kurulu değil'}.get(service, str(service))
             + (f'\nson yazım {when(updated, now)}' if updated else ''),
             'ok' if service == 'running' and updated and now - float(updated) < 180 else 'bad'),
        tile('Sysmon', {'running': 'Çalışıyor', None: 'Yok'}.get(sysmon, str(sysmon)), 'ok' if sysmon == 'running' else 'bad'),
        tile('Suricata', (f'Çalışıyor (PID {sur_pid})' if sur_pid else 'Çalışmıyor')
             + f'\n{len(suricata_alerts)} uyarı', 'ok' if sur_pid else 'bad'),
        tile('OTX', (f'Açık · {len(otx_blocks)} engel' if otx_key and otx_key.get('ok') else 'Anahtar yok'),
             'ok' if otx_key and otx_key.get('ok') else 'warn'),
        tile('Güvenlik duvarı', str(fw.get('status') or '-') + f"\n{len(blocks)} engel", 'ok' if fw.get('ok') else 'warn'),
        tile('Durdurulan', f'{len(stops)} süreç', 'warn' if stops else 'ok'),
        tile('Kural bulgusu', f"{len(rule_findings)} · {sum(1 for e in rule_findings if e.get('outcome') in STOPPED)} durdurma",
             'warn' if any(e.get('classification') == 'suspicious' for e in rule_findings) else 'ok'),
        tile('Bellek', f"{len(memory)} bulgu", 'ok'),
        tile('Araya girme (24 sa)', f"{recent_mitm} proxy · {recent_certs} sertifika",
             'warn' if recent_mitm or recent_certs else 'ok'),
        tile('Sorun', f'{len(problems)} tür', 'bad' if problems else 'ok'),
    ]

    def rows(items, make):
        return [make(e) for e in sorted(items, key=lambda e: e.get('time', 0), reverse=True)[:LIST]]

    def block_row(e):
        otx = e.get('otx') or {}
        why = (f"{otx.get('pulse_count')} pulse · {otx.get('reason')}" if otx else
               f"bağlantı kesilen {e.get('connections_ended', 0)}")
        return {'time': when(e.get('time'), now), 'cols': (e.get('ip'), e.get('rule'), why), 'event': e}

    def stop_row(e):
        return {'time': when(e.get('time'), now),
                'cols': (leaf(e.get('image') or e.get('exe')), e.get('rule_id') or e.get('kind'),
                         e.get('rule') or '', e.get('outcome')), 'event': e}

    def alert_row(e):
        if e['kind'] == 'suricata_alert':
            text = f"{e.get('signature')} · {e.get('src')} → {e.get('dest')}:{e.get('dest_port')} ({e.get('action')})"
        elif e['kind'] == 'rule_finding':
            text = f"{e.get('rule_id')} {e.get('rule')} · {leaf(e.get('image'))} · {e.get('outcome')}"
        elif e['kind'].startswith('cert_'):
            text = f"{e.get('subject')} ({e.get('store')})"
        else:
            text = short(e, 160)
        return {'time': when(e.get('time'), now), 'cols': (e['kind'], text), 'event': e}

    alerts = [e for e in events if e['kind'] in ALERT_KINDS
              or (e['kind'] == 'rule_finding' and e.get('classification') == 'suspicious')]
    return {
        'tiles': tiles,
        'blocks': rows(blocks, block_row),
        'stops': rows(stops, stop_row),
        'alerts': rows(alerts, alert_row),
        'problems': [{'time': when(p['event'].get('time'), now),
                      'cols': (p['kind'], p['count'], short(p['event'], 200)), 'event': p['event']}
                     for p in sorted(problems.values(), key=lambda p: p['event'].get('time', 0), reverse=True)],
        'recent': [{'time': when(e.get('time'), now), 'cols': (e['kind'], short(e)), 'event': e}
                   for e in list(reversed(events))[:LIST]],
        'counts': dict(kinds),
        'events': len(events),
    }


def read_all(directory=None):
    directory = Path(directory or state_dir())
    events = merged_events(directory)
    return summary(events, load_state(directory / 'state.json'), live())


# ---------------------------------------------------------------------------------------------
# Plain Turkish for the Qt panel (Linux panel design): every record as a sentence, grouped feed,
# what waits for the owner, the protection layers, kept blocks and disabled devices.
# Qt paneli için düz Türkçe: her kayıt bir cümle, gruplanmış akış, sahibi bekleyenler, katmanlar.
# ---------------------------------------------------------------------------------------------

BLOCK_RULES = {'otx': 'OTX tehdit listesindeki adres', 'no_ptr_connection_flood': 'Adı olmayan adrese yoğun bağlantı',
               'subnet_distinct_ip_limit': 'Aynı ağdan çok sayıda farklı adres'}
KIND_TR = {
    'blocked': 'Adres engellendi', 'block_skipped': 'Korunan adres engellenmedi', 'block_failed': 'Engel yazılamadı',
    'memory_finding': 'Bellek bulgusu', 'rule_finding': 'Kural bulgusu', 'suricata_alert': 'Suricata uyarısı',
    'mitm_proxy_set': 'Sistem proxy\'si değiştirildi', 'mitm_written_back': 'Proxy ayarı geri alındı',
    'cert_added': 'Yeni kök sertifika', 'cert_quarantined': 'Sertifika karantinaya alındı',
    'device_disabled': 'Aygıt kapatıldı', 'device_not_allowed_kept': 'İzinsiz aygıt (Windows gerektiriyor)',
    'accounts_not_applied': 'Hesap kısıtı uygulanamadı',
    'account_enabled_disabled_again': 'Sahip dışında bir hesap açıldı, kapatıldı',
    'update_rolled_back': 'Güncelleme geri alındı, önceki sürüme dönüldü', 'satsuma_tampered': 'Satsuma dosyası değiştirilmiş', 'satsuma_unexpected_access': 'Satsuma beklenmeyen erişim istedi', 'installed': 'Satsuma kuruldu / güncellendi', 'satsuma_started_approved': 'Satsuma onaylı kurulumla başladı', 'satsuma_started_unapproved': 'Satsuma onaysız kurulumla başladı', 'satsuma_ended_without_stop': 'Satsuma durdurma kaydı olmadan sonlandı', 'install_incomplete': 'Kurulum yarım kaldı', 'owner_password_refused': 'Parolasız ya da yanlış parolalı istek reddedildi', 'owner_password_missing': 'Yönetici parolası doğrulayıcısı kayıp', 'owner_password_set_refused': 'Parola değişikliği reddedildi', 'owner_password_set': 'Yönetici parolası belirlendi', 'otx_key': 'OTX anahtarı kaydedildi',
    'otx_not_blocked': 'OTX\'te kayıtlı, engellenmedi', 'owner_request': 'İsteğin uygulandı',
    'stop_requested': 'Hizmet durdurma isteği', 'firewall_block_restored': 'Silinen engel geri yazıldı', 'firewall_block_disabled': 'Engel kuralı kapatılmış, geri açıldı', 'firmware_changed': 'BIOS / TPM değişti', 'memory_exempt_summary': 'Satsuma\'nın kendi programları (saatlik özet)', 'process_audit_off': 'Windows süreç denetimi kapalı', 'firmware_baseline_taken': 'BIOS / TPM taban çizgisi alındı', 'firmware_unreadable': 'BIOS / TPM okunamadı',
    'firewall_baseline_changed': 'Güvenlik duvarı ayarı geri yazıldı', 'suricata_install': 'Suricata kurulumu',
    'sysmon_install': 'Sysmon kurulumu', 'sysmon_available': 'Sysmon hazır',
}
STARTUP_TR = {'state_dir_lock': 'kayıt klasörü kilidi', 'machine_key': 'makine anahtarı', 'port_853': 'şifreli DNS portu',
              'dns_lock': 'DNS kilidi', 'inbound_lock': 'gelen trafik kilidi', 'browser_policy': 'tarayıcı ilkeleri',
              'hardening': 'sistem sertleştirme', 'accounts': 'hesap kısıtları', 'firewall_auto': 'güvenlik duvarı',
              'certificates': 'sertifika deposu', 'gateway': 'ağ geçidi kilidi', 'memory': 'bellek denetimi',
              'deepseek': 'DeepSeek kuralları', 'rules': 'kural motoru', 'sysmon': 'Sysmon', 'suricata': 'Suricata',
              'ram_v2_removed': 'eski bellek taraması temizliği'}
TRUSTED_ROOTS = ('c:\\windows\\', 'c:\\program files\\', 'c:\\program files (x86)\\')
CATEGORY_TR = {'pppoe_vpn_ipsec': 'VPN / PPPoE / IPsec', 'virtual_machine': 'Sanal makine', 'bluetooth': 'Bluetooth',
               'wwan': 'Mobil geniş bant', 'smart_card': 'Akıllı kart okuyucu', 'wireless': 'Kablosuz aktarıcı'}
OUTCOME_TR = {'stopped': 'Durduruldu', 'stop_failed': 'Durdurulamadı', 'recorded': 'Bildirildi', 'gone': 'Bildirildi',
              'exempt': 'Muaf'}


def kind_title(kind):
    if kind.startswith('startup_'):
        return 'Açılış: ' + STARTUP_TR.get(kind[8:], kind[8:])
    return KIND_TR.get(kind, kind.replace('_', ' '))


def folder_of(image):
    text = str(image or '')
    return text.rsplit('\\', 1)[0] if '\\' in text else ''


def user_folder(image):
    low = str(image or '').lower()
    return bool(low) and not low.startswith(TRUSTED_ROOTS)


def describe(e):
    """{title, subject, badge, level, what, did, rule, actions} for one record, in plain Turkish."""
    kind = e['kind']
    d = {'title': kind_title(kind), 'subject': '', 'badge': 'Bilgi', 'level': 'info', 'what': '', 'did': '',
         'rule': e.get('rule_id') or (e.get('rule') if kind == 'blocked' else '') or '', 'actions': []}
    if kind == 'blocked':
        otx = e.get('otx') or {}
        d.update(title=BLOCK_RULES.get(e.get('rule'), 'Adres engellendi'), subject=e.get('ip', ''), badge='Engellendi',
                 level='block', what=(f"OTX'te {otx.get('pulse_count')} kayıtta geçiyor: {otx.get('reason')}" if otx
                                      else 'Bu adrese kısa sürede alışılmadık sayıda bağlantı kuruldu.'),
                 did=f"Güvenlik duvarında iki yönde engellendi; {e.get('connections_ended', 0)} açık bağlantı kesildi.",
                 actions=[('unblock', e.get('ip'), 'Engeli kaldır')])
    elif kind in ('memory_finding', 'rule_finding'):
        outcome = e.get('outcome')
        subject = e.get('cmd') or e.get('details') or e.get('image') or ''
        d.update(title=e.get('rule') or d['title'], subject=subject, badge=OUTCOME_TR.get(outcome, 'Bildirildi'),
                 level='stop' if outcome in STOPPED else ('alert' if e.get('classification') == 'suspicious' else 'info'),
                 what=f"Program: {e.get('image') or '-'}",
                 did={'stopped': 'Program durduruldu.', 'stop_failed': 'Durdurulmak istendi ama durdurulamadı.',
                      'gone': 'Program Satsuma davranmadan kendiliğinden bitti.', 'exempt': 'Muaf olduğu için dokunulmadı.'}
                 .get(outcome, 'Kaydedildi; Satsuma bir işlem yapmadı.'))
        if outcome in STOPPED and kind == 'memory_finding' and user_folder(e.get('image')) \
                and not any(w in str(e.get('image')).lower() for w in ('\\temp\\', '\\downloads\\', '\\desktop\\')):
            d['actions'].append(('approve_location', folder_of(e.get('image')), 'Bu klasöre güven'))
    elif kind == 'suricata_alert':
        d.update(title=e.get('signature') or 'Suricata uyarısı', subject=f"{e.get('src')} → {e.get('dest')}:{e.get('dest_port')}",
                 badge='Engellendi' if e.get('action') == 'blocked' else 'Uyarı', level='alert',
                 what=f"Kategori: {e.get('category') or '-'} · protokol {e.get('proto') or '-'}",
                 did='Trafik kesildi.' if e.get('action') == 'blocked' else 'Trafik geçti; yalnızca bildirildi.',
                 rule=str(e.get('sid') or ''))
    elif kind == 'mitm_proxy_set':
        d.update(subject=', '.join(e.get('proxies') or []), badge='Geri alındı', level='stop',
                 what='Bir program Windows proxy ayarını değiştirdi; trafik o programdan geçebilirdi.',
                 did='Satsuma ayarı hemen geri aldı.')
    elif kind == 'cert_quarantined':
        d.update(subject=e.get('subject', ''), badge='Karantina', level='alert',
                 what=f"{e.get('store')} deposuna eklenen sertifika · {e.get('thumbprint')}",
                 did='Sertifika depodan alınıp karantinaya kondu.')
    elif kind == 'cert_added':
        d.update(subject=e.get('subject', ''), what=f"{e.get('store')} · {e.get('thumbprint')}")
    elif kind == 'device_disabled':
        d.update(title='Aygıt kapatıldı: ' + str(e.get('name') or ''), subject=e.get('id', ''), badge='Kapatıldı', level='stop',
                 what=f"Tür: {CATEGORY_TR.get(e.get('category'), e.get('category'))}", did='Aygıt devre dışı bırakıldı.',
                 actions=[('approve_device', e.get('id'), 'Aygıta izin ver')])
    elif kind == 'update_rolled_back':
        d.update(subject=str(e.get('consent') or ''), badge='Geri alındı', level='problem',
                 what='Neden: ' + str(e.get('reason') or '-') + ' · ' + str(e.get('consent') or ''),
                 did='Önceki sürüm geri kondu: ' + ', '.join(e.get('restored') or []))
    elif kind == 'firmware_changed':
        d.update(subject='; '.join(e.get('summary') or []) or str(e.get('reason') or ''), badge='Değişti', level='alert',
                 what='; '.join(e.get('summary') or []) or str(e.get('reason') or ''),
                 did='BIOS ya da TPM taban çizgisinden farklı. Güncellemeyi sen yapmadıysan ciddi bir bulgu. '
                     'Sen yaptıysan: --approve-firmware ve "onaylıyorum".')
    elif kind == 'firmware_baseline_taken':
        d.update(subject=f"BIOS {e.get('bios_version')} · TPM {e.get('tpm_maker')} {e.get('tpm_firmware')}",
                 what='İmzalı taban çizgisi alındı; bundan sonra her açılışta karşılaştırılır.')
    elif kind == 'firewall_block_disabled':
        rules = e.get('rules') or {}
        d.update(subject=str(e.get('ip') or ''), badge='Geri açıldı' if e.get('restored') else 'Açılamadı', level='alert',
                 what='; '.join(f"{k}: {v}" for k, v in rules.items()) if isinstance(rules, dict) else str(rules),
                 did=('Engel yeniden açıldı. Engeli yalnız sahip kaldırabilir (--unblock).' if e.get('restored')
                      else 'Engel geri açılamadı: ' + str(e.get('error') or '')))
    elif kind == 'satsuma_started_unapproved':
        d.update(subject=str(e.get('reason') or ''), badge='Onaysız', level='alert',
                 what='Neden: ' + str(e.get('reason') or '-') + ' · ' + str(e.get('consent') or ''),
                 did='Satsuma çalışıyor; bu sürüm "onaylıyorum" yazılarak kurulmadı. Kurulumu kendin yapmadıysan incele.')
    elif kind == 'satsuma_started_approved':
        d.update(subject=str(e.get('consent') or ''), badge='Onaylı',
                 what='Çalışan exe, "onaylıyorum" yazılarak kurulan sürümle aynı.')
    elif kind == 'installed':
        d.update(subject=str(e.get('consent') or ''), what='; '.join((e.get('changes') or [])[:6]))
    elif kind == 'owner_request':
        d.update(subject=str(e.get('ip') or e.get('folder') or e.get('id') or e.get('rule') or ''),
                 badge='Uygulandı' if e.get('ok') else 'Olmadı', level='info' if e.get('ok') else 'problem',
                 what=f"İstek: {e.get('action')}", did=str(e.get('error') or 'Hizmet isteği uyguladı.'))
    if is_problem(e) and d['level'] == 'info':
        d.update(badge='Sorun', level='problem', did=str(e.get('error') or e.get('status') or 'Başarısız'))
    if not d['subject']:
        d['subject'] = short(e, 120)
    return d


def friendly(subject):
    """A path or a command line as the owner reads it: program name and where it is. Teknik olmayan özet."""
    text = str(subject or '').strip()
    if not text:
        return ''
    import re
    match = re.match(r'^"?([a-zA-Z]:\\[^"]*?\.(?:exe|dll|sys|ps1|bat|cmd|msi|scr|com))\b', text, re.I)
    first = match.group(1) if match else text.split(' ')[0]
    if '\\' in first and len(first) > 3:
        name, folder = leaf(first), folder_of(first)
        low = folder.lower()
        where = ('Windows' if low.startswith('c:\\windows') else 'Program Files' if low.startswith('c:\\program files')
                 else 'Geçici klasör (Temp)' if '\\temp' in low else 'İndirilenler' if '\\downloads' in low
                 else 'Kullanıcı klasörü' if low.startswith('c:\\users') else folder)
        return f'{name} · {where}'
    return text if len(text) <= 70 else text[:70] + '…'


def feed(events, now=None):
    """Repeats folded into one row (count, first, last), newest first. Tekrarlar tek satırda."""
    groups = {}
    for e in events:
        d = describe(e)
        key = (e['kind'], d['title'], d['subject'], d['badge'])
        row = groups.get(key)
        if row is None:
            groups[key] = {'d': d, 'event': e, 'count': 1, 'first': e.get('time'), 'last': e.get('time')}
        else:
            row.update(count=row['count'] + 1, event=e, d=d, last=e.get('time'))
    return sorted(groups.values(), key=lambda r: r['last'] or 0, reverse=True)


def read_signed_rows(path):
    try:
        rows = json.loads(Path(path).read_text(encoding='utf-8')).get('rows')
        return rows if isinstance(rows, dict) else {}
    except (OSError, ValueError, AttributeError):
        return {}


BUILTIN_PREFIXES = ('SWD\\MSRRAS\\',)


def builtin_device(device_id):
    """Windows' own WAN Miniport drivers: present on every Windows, never a connection by themselves."""
    return str(device_id or '').upper().startswith(BUILTIN_PREFIXES)


def devices_now(directory):
    """The service's list of devices off by policy right now, or None before the first check."""
    try:
        rows = json.loads((Path(directory) / 'devices-now.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None
    return [r for r in rows if isinstance(r, dict) and r.get('id')] if isinstance(rows, list) else None


def absent_devices(directory, events, shown):
    """Devices Satsuma disabled that are not plugged in now (owner's approval 2026-11-25): the page says so.
    Satsuma'nın kapattığı ama şu an takılı olmayan aygıtlar."""
    try:
        ids = json.loads((Path(directory) / 'disabled-devices.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return []
    have = {d.get('id') for d in shown}
    names = {e.get('id'): e for e in events if e['kind'] == 'device_disabled' and e.get('id')}
    approved = {e.get('id') for e in events if e['kind'] == 'owner_request' and e.get('action') == 'approve_device' and e.get('ok')}
    return [{'id': i, 'name': (names.get(i) or {}).get('name') or i, 'category': (names.get(i) or {}).get('category'),
             'absent': True} for i in ids if isinstance(i, str) and i not in have and i not in approved]


def devices_off(events):
    """Devices Satsuma disabled and the owner has not allowed since. Kapatılıp izin verilmemiş aygıtlar."""
    found = {}
    for e in events:
        if e['kind'] == 'device_disabled' and e.get('id'):
            found[e['id']] = e
        elif e['kind'] == 'owner_request' and e.get('action') == 'approve_device' and e.get('ok'):
            found.pop(e.get('id'), None)
    return list(found.values())


def waiting(events, blocks, devices, live_now=None):
    """What the owner should decide or repair, with the request that does it. Sahibi bekleyenler."""
    items = []
    s = summary(events, {}, live_now or {})
    for p in s['problems']:
        e = p['event']
        items.append({'title': kind_title(e['kind']), 'text': f"{p['cols'][1]} kez · son {p['time']}", 'level': 'problem',
                      'action': None})
    otx = [ip for ip, row in blocks.items() if row.get('reason') == 'otx']
    if otx:
        items.append({'title': f'{len(otx)} adres OTX ile engelli',
                      'text': 'OTX ortak adresleri (GitHub, Google, Microsoft, Cloudflare) de işaretleyebilir. '
                              'Bir site açılmıyorsa hepsini kaldırabilirsin.', 'level': 'warn',
                      'action': ('unblock_rule', 'otx', 'Tüm OTX engellerini kaldır')})
    folders = collections.Counter(folder_of(e.get('image')) for e in events if e['kind'] == 'memory_finding'
                                  and e.get('outcome') in STOPPED and user_folder(e.get('image')))
    approved = {str(e.get('folder') or '').rstrip('\\').lower() for e in events
                if e['kind'] == 'owner_request' and e.get('action') == 'approve_location' and e.get('ok')}
    for folder, count in folders.most_common(5):
        if folder.lower() in approved or any(w in folder.lower() + '\\' for w in ('\\temp\\', '\\downloads\\', '\\desktop\\')):
            continue
        items.append({'title': f'{leaf(folder) or folder}: {count} süreç durduruldu',
                      'text': f'{folder} kullanıcı klasöründe. Tanıdığın bir programsa (tarayıcı gibi) bu klasöre güvenebilirsin; '
                              'dosyasız bellekten iş parçacığı yine durdurulur.', 'level': 'warn',
                      'action': ('approve_location', folder, 'Bu klasöre güven')})
    return items


def layers(events, live_now):
    last = {}
    for e in events:
        last[e['kind']] = e

    def ok(kind):
        e = last.get(kind)
        return None if e is None else e.get('ok') is not False

    sur = bool(live_now.get('suricata_pid'))
    otx_on = bool((last.get('otx_key') or {}).get('ok'))
    deep = (last.get('startup_deepseek') or {})
    return [
        ('Programlar ve bellek', ok('startup_memory'), 'Açık · otomatik durdurur' if ok('startup_memory') else 'Kapalı',
         'Yanlış yerden çalışan ya da dosyasız bellekten iş parçacığı açan program durdurulur.'),
        ('Ağ ve trafik denetimi', sur, 'Açık' if sur else 'Çalışmıyor', 'Suricata trafiği satır içinde (WinDivert) denetliyor.'),
        ('Güvenlik duvarı', ok('startup_firewall_auto'), 'Kilitli' if ok('startup_firewall_auto') else 'Sorun',
         'Gelen trafik kapalı; Satsuma\'nın engelleri imzalı listede tutulur.'),
        ('Tehdit istihbaratı', otx_on, 'Açık' if otx_on else 'Anahtar yok', 'Bağlanılan adresler OTX ile denetleniyor.'),
        ('Olay izleme', live_now.get('sysmon') == 'running', 'Açık' if live_now.get('sysmon') == 'running' else 'Kapalı',
         'Sysmon olayları kural motoruna gidiyor.'),
        ('Tarayıcı ve sertifikalar', ok('startup_browser_policy') and ok('startup_certificates'), 'Açık',
         'Tarayıcı ilkeleri kilitli; kök sertifika deposu izleniyor.'),
        ('DNS kilidi', ok('startup_dns_lock'), 'Açık' if ok('startup_dns_lock') else 'Sorun', 'DNS sunucuları sabit, şifreli DNS açık.'),
        ('DeepSeek kuralları', bool(deep.get('active')), f"{deep.get('active', 0)} etkin kural" if deep else 'Kapalı',
         'Saldırı türlerine göre otomatik çekilen kurallar.'),
    ]


IMPORTANT_TAIL = 20000  # yesterday's blocks and stops included (one-time backfill, 2026-11-25)


def merged_events(directory):
    """The last TAIL records and the last IMPORTANT_TAIL important ones (blocks, stops, critical),
    in time order without duplicates: routine records never push important ones out of the panel.
    Son kayıtlar ve son önemli kayıtlar birleştirilir; önemli olanlar paneli asla terk etmez."""
    recent = load_events(directory / 'events.jsonl')
    kept = load_events(directory / 'important.jsonl', IMPORTANT_TAIL)
    seen, merged = set(), []
    for event in sorted(recent + kept, key=lambda e: (float(e.get('time') or 0), e.get('kind', ''))):
        mark = json.dumps(event, sort_keys=True, default=str)
        if mark not in seen:
            seen.add(mark)
            merged.append(event)
    return merged


def read_panel(directory=None):
    directory = Path(directory or state_dir())
    events = merged_events(directory)
    now_live = live()
    blocks = read_signed_rows(directory / 'blocks.json')
    current = devices_now(directory)
    devices = current if current is not None else devices_off(events)
    devices = devices + absent_devices(directory, events, devices)
    base = summary(events, load_state(directory / 'state.json'), now_live)
    return {**base, 'feed': feed(events), 'blocks_kept': blocks, 'allowed': read_signed_rows(directory / 'allowed.json'),
            'devices': devices, 'waiting': waiting(events, blocks, devices, now_live), 'layers': layers(events, now_live),
            'live': now_live, 'raw': events}
