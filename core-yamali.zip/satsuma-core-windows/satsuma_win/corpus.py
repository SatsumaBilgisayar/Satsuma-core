"""Everyday Windows command lines and Satsuma's own commands: what a rule must not stop.

Used twice: by the tests of the bundled Windows rules and by the breadth check of every
DeepSeek rule (satsuma_win.ai_rules), the Windows counterpart of satsuma.ai_guard.CORPUS. A
stopping rule that matches any of Satsuma's own commands, or more than BREADTH_LIMIT of the
everyday ones, is refused. Satsuma's commands are built from the very functions the service
runs, so the list cannot drift from what the service really does.

Gündelik Windows komut satırları ve Satsuma'nın kendi komutları: bir kuralın durdurmaması
gerekenler. Paketli kuralların testleri ve her DeepSeek kuralının genişlik denetimi kullanır.
Satsuma'nın komutları hizmetin çalıştırdığı işlevlerin kendisinden kurulur.
"""
BREADTH_LIMIT = 0.02

EVERYDAY = (
    r'C:\Windows\Explorer.EXE',
    r'"C:\Program Files\Google\Chrome\Application\chrome.exe" --type=renderer --lang=tr --field-trial-handle=1234',
    r'"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --profile-directory=Default',
    r'"C:\Program Files\Mozilla Firefox\firefox.exe" -contentproc --channel=1234 -childID 3 -isForBrowser',
    r'C:\Windows\system32\svchost.exe -k netsvcs -p -s Schedule',
    r'C:\Windows\system32\svchost.exe -k LocalServiceNetworkRestricted -p',
    r'C:\Windows\System32\RuntimeBroker.exe -Embedding',
    r'C:\Windows\system32\conhost.exe 0xffffffff -ForceV1',
    r'"C:\Windows\system32\cmd.exe" /c dir C:\Users\ali\Documents',
    r'cmd.exe /c "echo hello"',
    r'"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"',
    r'powershell.exe -NoProfile -Command Get-ChildItem C:\Users\ali\Documents',
    r'powershell.exe Get-Process | Sort-Object CPU -Descending | Select-Object -First 10',
    r'pwsh.exe -NoLogo',
    r'"C:\Program Files\Microsoft VS Code\Code.exe" --type=utility --utility-sub-type=node.mojom.NodeService',
    r'"C:\Users\ali\AppData\Local\Programs\Microsoft VS Code\Code.exe" C:\Users\ali\proje',
    r'"C:\Users\ali\AppData\Local\Discord\app-1.0.9035\Discord.exe" --type=renderer',
    r'"C:\Users\ali\AppData\Roaming\Spotify\Spotify.exe" --autostart --minimized',
    r'"C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE" /n "C:\Users\ali\Documents\rapor.docx"',
    r'"C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE" "C:\Users\ali\Desktop\butce.xlsx"',
    r'"C:\Program Files\Notepad++\notepad++.exe" C:\Users\ali\notlar.txt',
    r'C:\Windows\system32\notepad.exe C:\Users\ali\Desktop\liste.txt',
    r'"C:\Program Files\7-Zip\7zFM.exe" C:\Users\ali\Downloads\arsiv.zip',
    r'"C:\Program Files\Git\cmd\git.exe" pull origin main',
    r'git.exe status',
    r'python.exe -m pip install --user requests',
    r'"C:\Users\ali\AppData\Local\Programs\Python\Python313\python.exe" manage.py runserver',
    r'node.exe C:\Users\ali\proje\node_modules\.bin\vite',
    r'npm.cmd install',
    r'"C:\Program Files\dotnet\dotnet.exe" build C:\Users\ali\proje\app.csproj',
    r'C:\Windows\system32\taskmgr.exe /7',
    r'C:\Windows\System32\mmc.exe C:\Windows\system32\devmgmt.msc',
    r'C:\Windows\system32\SearchIndexer.exe /Embedding',
    r'C:\Windows\System32\smartscreen.exe -Embedding',
    r'"C:\ProgramData\Microsoft\Windows Defender\Platform\4.18.24090.11-0\MsMpEng.exe"',
    r'"C:\Program Files\Windows Defender\MpCmdRun.exe" -SignatureUpdate',
    r'C:\Windows\system32\wuauclt.exe /UpdateDeploymentProvider UpdateDeploymentProvider.dll /ClassId 1234',
    r'C:\Windows\System32\msiexec.exe /i "C:\Users\ali\Downloads\setup.msi"',
    r'C:\Windows\servicing\TrustedInstaller.exe',
    r'C:\Windows\system32\DllHost.exe /Processid:{3EB3C877-1F16-487C-9050-104DBCD66683}',
    r'C:\Windows\system32\rundll32.exe C:\Windows\system32\shell32.dll,Control_RunDLL',
    r'rundll32.exe printui.dll,PrintUIEntry /il',
    r'C:\Windows\system32\regsvr32.exe /s "C:\Program Files\App\component.dll"',
    r'C:\Windows\system32\certutil.exe -hashfile C:\Users\ali\Downloads\setup.exe SHA256',
    r'certutil.exe -store My',
    r'C:\Windows\system32\schtasks.exe /query /fo LIST',
    r'schtasks.exe /run /tn "\Microsoft\Windows\Defrag\ScheduledDefrag"',
    r'C:\Windows\system32\sc.exe query wuauserv',
    r'net.exe use Z: \\nas\paylasim',
    r'net.exe start',
    r'ipconfig.exe /all',
    r'ping.exe -n 4 8.8.8.8',
    r'tracert.exe example.com',
    r'whoami.exe',
    r'systeminfo.exe',
    r'tasklist.exe /v',
    r'reg.exe query HKLM\Software\Microsoft\Windows\CurrentVersion',
    r'wmic.exe logicaldisk get size,freespace',
    r'bcdedit.exe /enum',
    r'vssadmin.exe list shadows',
    r'wevtutil.exe qe System /c:10 /f:text',
    r'"C:\Program Files\Steam\steam.exe" -silent',
    r'"C:\Program Files\VideoLAN\VLC\vlc.exe" C:\Users\ali\Videos\film.mp4',
    r'"C:\Program Files\TeamViewer\TeamViewer.exe"',
    r'"C:\Program Files (x86)\AnyDesk\AnyDesk.exe" --control',
    r'OneDrive.exe /background',
    r'"C:\Users\ali\AppData\Local\Microsoft\Teams\current\Teams.exe" --process-start-reason=autostart',
    r'curl.exe -O https://example.com/dosya.zip',
    r'winget.exe upgrade --all',
    r'C:\Windows\System32\SecurityHealthSystray.exe',
    r'C:\Windows\System32\ctfmon.exe',
    r'C:\Windows\system32\sihost.exe',
    r'C:\Windows\System32\dwm.exe',
    r'"C:\Windows\SystemApps\MicrosoftWindows.Client.CBS_cw5n1h2txyewy\SearchHost.exe" -ServerName:CortanaUI.AppX8z9r6jm96hw4bsbneegw0kyxx296wr9t.mca',
)


def satsuma_commands():
    """The command lines the Satsuma service itself runs, built from its own functions."""
    from . import accounts, devices, dns, firewall, gateway, inbound, protect, service, sysmon
    scripts = []
    builders = (
        lambda: firewall.block_script('203.0.113.9', 'no_ptr'),
        firewall.port_853_script, dns.lock_script, inbound.apply_script,
        lambda: inbound.CHECK_SCRIPT, lambda: accounts.ACCOUNTS_SCRIPT,
        lambda: devices.READ_SCRIPT, lambda: devices.disable_script(r'USB\VID_1234&PID_5678\0001'),
        lambda: devices.enable_script(r'USB\VID_1234&PID_5678\0001'),
        lambda: gateway.SETTINGS_SCRIPT, lambda: gateway.REMOVE_PROXY_SCRIPT,
        lambda: gateway.pin_script('192.168.1.1', 'aa-bb-cc-dd-ee-ff', '192.168.1.5'), lambda: gateway.UNPIN_SCRIPT,
        lambda: protect.INFRASTRUCTURE_SCRIPT,
        lambda: service.install_script(r'C:\Users\ali\Downloads\satsuma-core-windows.exe'), service.uninstall_script,
        lambda: sysmon.signature_script(r'C:\Program Files\Satsuma\Sysmon\Sysmon64.exe'),
    )
    for build in builders:
        try:
            scripts.append(build())
        except Exception:  # a builder that changed its arguments is skipped, the rest still count
            continue
    lines = [' '.join(firewall.POWERSHELL) + ' "' + firewall.UTF8_OUTPUT + script + '"' for script in scripts]
    lines += [
        r'secedit.exe /export /areas USER_RIGHTS /cfg C:\ProgramData\Satsuma\rights.inf',
        r'secedit.exe /configure /db C:\ProgramData\Satsuma\rights.sdb /cfg C:\ProgramData\Satsuma\rights.inf /areas USER_RIGHTS /quiet',
        r'icacls C:\ProgramData\Satsuma /inheritance:r /grant:r *S-1-5-18:(OI)(CI)F *S-1-5-32-544:(OI)(CI)F',
        r'sc.exe query Sysmon64',
        r'"C:\Program Files\Satsuma\Sysmon\Sysmon64.exe" -accepteula -c "C:\Program Files\Satsuma\Sysmon\satsuma-sysmon.xml"',
        r'wevtutil.exe gl Microsoft-Windows-Sysmon/Operational',
        r'"C:\Program Files\Satsuma\satsuma-core-windows.exe" --service',
    ]
    return lines


def _image(line):
    first = line.split('"')[1] if line.startswith('"') else line.split()[0]
    return first if '\\' in first else 'C:\\Windows\\System32\\' + first


def process_events(lines):
    """Sysmon process events (1) for command lines; the parent is the desktop."""
    return [{'id': 1, 'record': index, 'ProcessId': str(5000 + index), 'Image': _image(line), 'CommandLine': line,
             'ParentImage': 'C:\\Windows\\explorer.exe', 'ParentCommandLine': 'C:\\Windows\\Explorer.EXE',
             'ParentProcessId': '4000'} for index, line in enumerate(lines)]


CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
SVCHOST = 'C:\\Windows\\System32\\svchost.exe'
SPOTIFY = 'C:\\Users\\ali\\AppData\\Roaming\\Spotify\\Spotify.exe'
MSIEXEC = 'C:\\Windows\\System32\\msiexec.exe'


def everyday_events():
    """Everyday events of every Windows source, as Sysmon writes them; nothing here may be stopped."""
    events = process_events(EVERYDAY)
    for host in ('www.google.com', 'login.microsoftonline.com', 'github.com', 'pastebin.com', 'raw.githubusercontent.com',
                 'settings-win.data.microsoft.com', 'open.spotify.com', 'discord.com', 'www.youtube.com', 'tr.wikipedia.org'):
        events.append({'id': 22, 'record': 0, 'ProcessId': '6000', 'Image': CHROME, 'QueryName': host,
                       'QueryResults': '::ffff:142.250.1.1;'})
    events.append({'id': 22, 'record': 0, 'ProcessId': '6001', 'Image': SVCHOST, 'QueryName': 'ctldl.windowsupdate.com',
                   'QueryResults': ''})
    for image, port in ((CHROME, '443'), (SVCHOST, '443'), (SPOTIFY, '4070'), ('C:\\Windows\\System32\\certutil.exe', '80'),
                        ('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe', '443')):
        events.append({'id': 3, 'record': 0, 'ProcessId': '6002', 'Image': image, 'Initiated': 'true',
                       'DestinationIp': '20.190.1.1', 'DestinationPort': port, 'DestinationHostname': 'example.com'})
    for target, details, image in (
            ('HKU\\S-1-5-21-1\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\Spotify', SPOTIFY + ' /minimized', SPOTIFY),
            ('HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\\SecurityHealth',
             '%windir%\\system32\\SecurityHealthSystray.exe', MSIEXEC),
            ('HKLM\\System\\CurrentControlSet\\Services\\Steam Client Service\\ImagePath',
             '"C:\\Program Files (x86)\\Common Files\\Steam\\steamservice.exe" /RunAsService', MSIEXEC),
            ('HKU\\S-1-5-21-1_Classes\\CLSID\\{0358b920-0ac7-461f-98f4-58e32cd89148}\\InprocServer32\\(Default)',
             'C:\\Users\\ali\\AppData\\Local\\Microsoft\\OneDrive\\FileSyncShell64.dll', 'C:\\Users\\ali\\AppData\\Local\\Microsoft\\OneDrive\\OneDrive.exe'),
            ('HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\Shell', 'explorer.exe', SVCHOST)):
        events.append({'id': 13, 'record': 0, 'ProcessId': '6003', 'Image': image, 'EventType': 'SetValue',
                       'TargetObject': target, 'Details': details})
    for path, image in (('C:\\Users\\ali\\AppData\\Local\\Temp\\setup_1234\\setup.exe', MSIEXEC),
                        ('C:\\Users\\ali\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\Spotify.lnk', SPOTIFY),
                        ('C:\\Users\\ali\\AppData\\Local\\Temp\\chrome_installer.log', CHROME)):
        events.append({'id': 11, 'record': 0, 'ProcessId': '6004', 'Image': image, 'TargetFilename': path})
    events.append({'id': 7, 'record': 0, 'ProcessId': '6005', 'Image': MSIEXEC,
                   'ImageLoaded': 'C:\\Windows\\Temp\\MSI1234.tmp\\custom.dll', 'Signed': 'true', 'SignatureStatus': 'Valid'})
    events.append({'id': 10, 'record': 0, 'SourceProcessId': '6006', 'SourceImage': 'C:\\Windows\\System32\\taskmgr.exe',
                   'TargetProcessId': '700', 'TargetImage': 'C:\\Windows\\System32\\lsass.exe', 'GrantedAccess': '0x1000'})
    # Owner's approval 2026-11-25: Satsuma's own accesses and Defender's, from their real folders (Defender's
    # engine runs from ProgramData, not Program Files). No rule may stop these. Satsuma'nın ve Defender'ın erişimleri.
    satsuma = 'C:\\Program Files\\Satsuma\\satsuma-core-windows.exe'
    defender = 'C:\\ProgramData\\Microsoft\\Windows Defender\\Platform\\4.18.25010.11-0\\MsMpEng.exe'
    system = 'C:\\Windows\\System32\\'
    for source, target, access in ((satsuma, system + 'lsass.exe', '0x1010'), (satsuma, system + 'lsass.exe', '0x101c11'),
                                   (satsuma, system + 'winlogon.exe', '0x1410'), (satsuma, system + 'ROUTE.EXE', '0x1fffff'),
                                   (satsuma, system + 'ARP.EXE', '0x1fffff'),
                                   (defender, system + 'lsass.exe', '0x1010'), (defender, system + 'lsass.exe', '0x1410'),
                                   (defender, system + 'winlogon.exe', '0x1410'), (defender, system + 'services.exe', '0x1fffff'),
                                   (defender, system + 'csrss.exe', '0x1410'),
                                   (defender, 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', '0x1fffff')):
        events.append({'id': 10, 'record': 0, 'SourceProcessId': '6100', 'SourceImage': source, 'TargetProcessId': '700',
                       'TargetImage': target, 'GrantedAccess': access, 'CallTrace': ''})
    return events


def satsuma_events():
    """Satsuma's own commands as process events, as if started by someone else (never by the service)."""
    return process_events(satsuma_commands())
