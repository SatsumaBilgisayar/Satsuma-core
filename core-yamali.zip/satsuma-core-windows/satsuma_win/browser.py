"""Browser policies on Windows: Chrome, Edge, Brave, Chromium and Firefox locked to Satsuma's safe settings.

The Windows counterpart of satsuma.browser_policy (owner's request 2026-11-24: the Linux
browser protection, adapted). The settings are the Linux ones, taken from the shared code
itself, so the two products cannot drift apart:

* Chromium family (Chrome, Brave, Chromium): satsuma.browser_policy.chromium_policy(),
  written as enterprise policy values under HKLM\\SOFTWARE\\Policies (the place Windows
  browsers read; only administrators and SYSTEM can write it). A list becomes a subkey with
  numbered values, an object (ExtensionSettings) a JSON string, as Chrome reads them on
  Windows. Plus SSLErrorOverrideAllowed=0: a certificate error cannot be clicked through
  (the Firefox policy's DisableSecurityBypass.InvalidCertificate).
* Edge: the same, but its own names where Edge has them: SmartScreen on and not
  overridable for pages and downloads instead of Chrome's Safe Browsing names, and
  AutomaticHttpsDefault=2 beside HttpsOnlyMode.
* Firefox: satsuma.browser_policy.merged() (the Linux policies.json content) written to
  distribution\\policies.json of every Firefox installed in Program Files; a file there is
  backed up first and its unrelated keys are kept.

The service checks the policies every minute and writes back what someone changed;
every write is recorded. Before the first write the values found are saved
(browser-policy-backup.json) and --uninstall restores them. Each browser applies a
changed policy at its next start. Not yet tried on a real Windows machine with each
browser; a policy name a browser does not know is ignored by that browser.

Windows'ta tarayıcı ilkeleri: Chrome, Edge, Brave, Chromium ve Firefox Satsuma'nın güvenli
ayarlarına kilitlenir. Linux'taki satsuma.browser_policy'nin Windows karşılığı; ayarlar ortak
kodun kendisinden alınır. Chromium ailesi HKLM\\SOFTWARE\\Policies altına, Edge kendi
adlarıyla (SmartScreen), Firefox kurulum klasöründeki distribution\\policies.json dosyasına
yazılır. Hizmet ilkeleri dakikada bir denetler, değiştirileni geri yazar; ilk yazmadan önce
bulunan değerler saklanır, --uninstall onları geri yükler.
"""
import json
import os
import time
from pathlib import Path

BACKUP = 'browser-policy-backup.json'
CHROMIUM_KEYS = {
    'chrome': r'SOFTWARE\Policies\Google\Chrome',
    'brave': r'SOFTWARE\Policies\BraveSoftware\Brave',
    'chromium': r'SOFTWARE\Policies\Chromium',
    'edge': r'SOFTWARE\Policies\Microsoft\Edge',
}
REG_SZ, REG_DWORD = 1, 4
# Linux's Chromium list blocks the GNOME Shell connector; on Windows it does not exist.
# Linux listesi GNOME Shell bağlayıcısını engeller; Windows'ta yoktur.
LINUX_ONLY_EXTENSIONS = ('gphhapmejobijbbhgpjhcjognlahblep',)


def chromium_settings():
    from satsuma.browser_policy import chromium_policy
    policy = chromium_policy()
    settings = dict(policy.get('ExtensionSettings') or {})
    for extension in LINUX_ONLY_EXTENSIONS:
        settings.pop(extension, None)
    return {**policy, 'ExtensionSettings': settings, 'SSLErrorOverrideAllowed': False}


def edge_settings():
    policy = chromium_settings()
    for name in ('SafeBrowsingProtectionLevel', 'DisableSafeBrowsingProceedAnyway'):
        policy.pop(name, None)
    return {**policy, 'SmartScreenEnabled': True, 'PreventSmartScreenPromptOverride': True,
            'PreventSmartScreenPromptOverrideForFiles': True, 'AutomaticHttpsDefault': 2}


def desired():
    """{key path: {policy name: value}} for every Chromium-family browser."""
    chromium = chromium_settings()
    return {path: (edge_settings() if browser == 'edge' else chromium) for browser, path in CHROMIUM_KEYS.items()}


def registry_values(settings):
    """Policy values as Windows writes them: (values {name: (type, data)}, lists {name: [strings]})."""
    values, lists = {}, {}
    for name, value in sorted(settings.items()):
        if isinstance(value, bool):
            values[name] = (REG_DWORD, int(value))
        elif isinstance(value, int):
            values[name] = (REG_DWORD, value)
        elif isinstance(value, str):
            values[name] = (REG_SZ, value)
        elif isinstance(value, list):
            lists[name] = [str(item) for item in value]
        elif isinstance(value, dict):
            values[name] = (REG_SZ, json.dumps(value, sort_keys=True, separators=(',', ':')))
        else:
            raise ValueError('unsupported policy value: ' + name)
    return values, lists


class Registry:
    """HKLM through winreg, 64-bit view. Tests pass a fake with the same methods."""

    def __init__(self):
        import winreg
        self.winreg = winreg
        self.view = winreg.KEY_WOW64_64KEY

    def read(self, path):
        """{name: (type, data)} of one key, or None when it does not exist."""
        w = self.winreg
        try:
            key = w.OpenKey(w.HKEY_LOCAL_MACHINE, path, 0, w.KEY_READ | self.view)
        except FileNotFoundError:
            return None
        values, index = {}, 0
        with key:
            while True:
                try:
                    name, data, kind = w.EnumValue(key, index)
                except OSError:
                    break
                values[name] = (kind, data)
                index += 1
        return values

    def write(self, path, name, kind, data):
        w = self.winreg
        with w.CreateKeyEx(w.HKEY_LOCAL_MACHINE, path, 0, w.KEY_SET_VALUE | self.view) as key:
            w.SetValueEx(key, name, 0, kind, data)

    def subkeys(self, path):
        """Names of the subkeys of one key; [] when it does not exist."""
        w = self.winreg
        try:
            key = w.OpenKey(w.HKEY_LOCAL_MACHINE, path, 0, w.KEY_READ | self.view)
        except FileNotFoundError:
            return []
        names, index = [], 0
        with key:
            while True:
                try:
                    names.append(w.EnumKey(key, index))
                except OSError:
                    break
                index += 1
        return names

    def delete(self, path, name):
        w = self.winreg
        try:
            with w.OpenKey(w.HKEY_LOCAL_MACHINE, path, 0, w.KEY_SET_VALUE | self.view) as key:
                w.DeleteValue(key, name)
        except FileNotFoundError:
            pass


def firefox_dirs(environ=os.environ):
    roots = {environ.get('ProgramFiles', r'C:\Program Files'), environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)')}
    return sorted(Path(root) / 'Mozilla Firefox' for root in roots if (Path(root) / 'Mozilla Firefox' / 'firefox.exe').exists())


class BrowserPolicy:
    """Write, check every minute, write back, restore at uninstall. Yazar, dakikada bir denetler, geri yükler."""

    def __init__(self, state_dir, registry=None, firefox=firefox_dirs, clock=time.time):
        self.state_dir, self.clock = Path(state_dir), clock
        self.registry = registry if registry is not None else Registry()
        self.firefox = firefox

    # -- the backup of what was there before Satsuma -----------------------------------------
    def _backup_path(self):
        return self.state_dir / BACKUP

    def _save_backup(self):
        if self._backup_path().exists():
            return
        rows = {'saved_at': self.clock(), 'registry': {}}
        for path, settings in desired().items():
            values, lists = registry_values(settings)
            found = self.registry.read(path) or {}
            rows['registry'][path] = {name: list(found[name]) if name in found else None for name in values}
            for name in lists:
                rows['registry'][path + '\\' + name] = self.registry.read(path + '\\' + name)
                if rows['registry'][path + '\\' + name] is not None:
                    rows['registry'][path + '\\' + name] = {k: list(v) for k, v in rows['registry'][path + '\\' + name].items()}
        self.state_dir.mkdir(parents=True, exist_ok=True)
        temporary = self._backup_path().with_suffix('.tmp')
        temporary.write_text(json.dumps(rows, ensure_ascii=False), encoding='utf-8')
        os.replace(temporary, self._backup_path())

    # -- Chromium family -----------------------------------------------------------------------
    def _chromium(self, write):
        changed = []
        for path, settings in desired().items():
            values, lists = registry_values(settings)
            found = self.registry.read(path) or {}
            for name, (kind, data) in values.items():
                if tuple(found.get(name) or ()) != (kind, data):
                    changed.append(path + '\\' + name)
                    if write:
                        self.registry.write(path, name, kind, data)
            for name, items in lists.items():
                key = path + '\\' + name
                current = self.registry.read(key) or {}
                wanted = {str(index): (REG_SZ, item) for index, item in enumerate(items, 1)}
                if {k: tuple(v) for k, v in current.items()} != wanted:
                    changed.append(key)
                    if write:
                        for extra in set(current) - set(wanted):
                            self.registry.delete(key, extra)
                        for index, (kind, data) in wanted.items():
                            self.registry.write(key, index, kind, data)
        return changed

    # -- Firefox -------------------------------------------------------------------------------
    def _firefox(self, write):
        from satsuma.browser_policy import FIREFOX_PATH, merged
        changed = []
        for folder in self.firefox():
            path = Path(folder) / 'distribution' / 'policies.json'
            raw, old = None, None
            if path.exists():
                raw = path.read_bytes()
                try:
                    old = json.loads(raw)
                except ValueError:
                    old = None
            new = merged(FIREFOX_PATH, old if isinstance(old, dict) else None)
            if old == new:
                continue
            changed.append(str(path))
            if not write:
                continue
            path.parent.mkdir(parents=True, exist_ok=True)
            if raw is not None:
                stamp = time.strftime('%Y%m%d%H%M%S', time.gmtime(self.clock()))
                (path.parent / ('policies.json.satsuma-backup-' + stamp)).write_bytes(raw)
            temporary = path.with_suffix('.satsuma-tmp')
            temporary.write_text(json.dumps(new, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            os.replace(temporary, path)
        return changed

    def apply(self):
        """Write what differs; returns {'ok', 'written', 'requires_browser_restart'}."""
        self._save_backup()
        written = self._chromium(True) + self._firefox(True)
        left = self._chromium(False) + self._firefox(False)
        return {'ok': not left, 'status': 'LOCKED' if not left else 'NOT_WRITTEN', 'written': written,
                'left': left, 'requires_browser_restart': bool(written)}

    def status(self):
        left = self._chromium(False) + self._firefox(False)
        return {'ok': not left, 'differs': left}

    def restore(self):
        """--uninstall: put back the values found before Satsuma; remove what was not there."""
        try:
            rows = json.loads(self._backup_path().read_text(encoding='utf-8'))
        except (OSError, ValueError):
            return {'ok': True, 'status': 'NOTHING_TO_RESTORE'}
        for path, saved in (rows.get('registry') or {}).items():
            policy_path = next((p for p in desired() if path == p), None)
            if policy_path is not None:
                for name, value in (saved or {}).items():
                    if value is None:
                        self.registry.delete(path, name)
                    else:
                        self.registry.write(path, name, value[0], value[1])
            else:
                current = self.registry.read(path) or {}
                for name in current:
                    self.registry.delete(path, name)
                for name, value in (saved or {}).items():
                    self.registry.write(path, name, value[0], value[1])
        for folder in self.firefox():
            path = Path(folder) / 'distribution' / 'policies.json'
            backups = sorted(path.parent.glob('policies.json.satsuma-backup-*')) if path.parent.is_dir() else []
            if backups:
                os.replace(backups[0], path)
            elif path.exists():
                path.unlink()
        self._backup_path().unlink()
        return {'ok': True, 'status': 'RESTORED'}
