"""Owner requests from the panel or the command line, applied by the service (owner's request 2026-11-24).

An administrator (the panel, or ``--approve-location`` / ``--approve-device`` / ``--unblock``)
writes one small JSON file into %ProgramData%\\Satsuma\\requests, a folder only SYSTEM and
Administrators can write. Every minute the service takes at most MAX files, applies each one
signed with the machine key, deletes it and records the result ('owner_request'):

* approve_location {folder}: the folder becomes an expected program location (RAM-001 no
  longer stops its programs for RWX memory alone; a thread from fileless memory still is);
* approve_device {id}: the device stays enabled (a VPN adapter, say) and is enabled now;
* unblock {ip}: Satsuma's two firewall rules of the address go, the kept block is dropped and
  the address is never blocked again (signed allow list);
* unblock_rule {rule}: the same for every kept block of one rule (all OTX blocks, say);
* approve_firmware {digest}: the firmware values the owner saw and confirmed with "onaylıyorum"
  become the signed baseline (satsuma_win.firmware), and only if they are still the same.

Anything else, or a malformed file, is recorded as refused and deleted.

Since 2026-11-25 (owner's request) every request must carry a proof made with the Satsuma
administrator password (satsuma_win.owner_password); without it the request is refused and the
refusal is a critical record.

Panelden ya da komut satırından gelen sahip istekleri; hizmet uygular. Yönetici, yalnızca SYSTEM
ve Yöneticilerin yazabildiği requests klasörüne küçük bir JSON yazar; hizmet dakikada bir en çok
MAX isteği makine anahtarıyla imzalayıp uygular, siler ve sonucu kaydeder.
"""
import ipaddress
import json
import os
import time
import uuid
from pathlib import Path

FOLDER = 'requests'
MAX = 20
ACTIONS = ('approve_location', 'approve_device', 'unblock', 'unblock_rule', 'approve_firmware',
           'allow_rule_process', 'rule_mode')  # never the owner


class _Closed:
    """The gate when the password check could not start: every request is refused."""

    def check(self, body, what):
        return 'parola denetimi açılamadı'


CLOSED = _Closed()


def write(directory, action, password=None, **fields):
    """Hand one request to the service, signed with the Satsuma administrator password.
    Hizmete yönetici parolasıyla imzalı bir istek bırakır."""
    from . import owner_password
    if action not in ACTIONS:
        raise ValueError('unknown action: ' + str(action))
    body = {'action': action, **fields}
    if password is not None:
        body = owner_password.sign(directory, password, body)
    folder = Path(directory) / FOLDER
    folder.mkdir(parents=True, exist_ok=True)
    name = '%020d-%s.json' % (time.time_ns(), uuid.uuid4().hex[:8])  # sorted in the order written
    temporary = folder / (name + '.tmp')
    body.setdefault('at', time.time())
    temporary.write_text(json.dumps(body, ensure_ascii=False), encoding='utf-8')
    os.replace(temporary, folder / name)
    return name


def pending(directory):
    folder = Path(directory) / FOLDER
    try:
        return sorted(p for p in folder.iterdir() if p.suffix == '.json')[:MAX]
    except OSError:
        return []


def _ip(value):
    return str(ipaddress.ip_address(str(value).strip()))


class Applier:
    """Applies the requests; the guard gives it the steps it needs (testable without Windows)."""

    def __init__(self, directory, key, record, fw, unblock, approve_location, approve_device, enable_device,
                 approve_firmware=None, gate=None, allow_rule=None, rule_mode=None):
        self.gate = gate
        self.allow_rule, self.rule_mode = allow_rule, rule_mode
        self.dir, self.key, self.record, self.fw = Path(directory), key, record, fw
        self.approve_firmware = approve_firmware
        self.unblock, self.approve_location = unblock, approve_location
        self.approve_device, self.enable_device = approve_device, enable_device

    def one(self, request):
        action = request.get('action')
        if self.key is None:
            return {'ok': False, 'error': 'no_machine_key'}
        if action == 'approve_location':
            return {'ok': True, 'folder': self.approve_location(self.dir, str(request['folder']), self.key)}
        if action == 'approve_device':
            device = str(request['id'])
            self.approve_device(self.dir, device, self.key)
            self.enable_device(device)
            return {'ok': True, 'id': device}
        if action == 'unblock':
            ip = _ip(request['ip'])
            return {'ok': self._unblock(ip, request.get('reason') or 'owner'), 'ip': ip}
        if action == 'unblock_rule':
            rule = str(request['rule'])
            ips = sorted(ip for ip, row in self.fw.blocks().items() if row.get('reason') == rule)
            done = [ip for ip in ips if self._unblock(ip, 'owner_rule_' + rule)]
            return {'ok': len(done) == len(ips), 'rule': rule, 'unblocked': done, 'count': len(done)}
        if action == 'approve_firmware' and self.approve_firmware is not None:
            return self.approve_firmware(str(request['digest']))
        # Owner's request 2026-11-25 (panel, Durdurulanlar): allow one program (path + SHA-256) for one rule,
        # or turn a DeepSeek rule off / back on. Bir programa bir kural için izin; kuralı kapat / aç.
        if action == 'allow_rule_process' and self.allow_rule is not None:
            return self.allow_rule(str(request['rule_id']), str(request['image']))
        if action == 'rule_mode' and self.rule_mode is not None and request.get('mode') in ('disabled', 'enabled'):
            return self.rule_mode(str(request['rule_id']), request['mode'])
        return {'ok': False, 'error': 'unknown_action'}

    def _unblock(self, ip, why):
        removed = self.unblock(ip)
        if self.fw is not None:
            self.fw.forget(ip)
            self.fw.allow(ip, reason=why)
        return removed

    def run(self):
        events = []
        for path in pending(self.dir):
            try:
                request = json.loads(path.read_text(encoding='utf-8'))
                if not isinstance(request, dict):
                    raise ValueError('not an object')
                problem = self.gate.check(request, request.get('action')) if self.gate is not None else None
                result = {'ok': False, 'error': 'parola: ' + problem} if problem else self.one(request)
            except Exception as exc:  # a bad request is refused and recorded; the next one still runs
                request = request if isinstance(locals().get('request'), dict) else {}
                result = {'ok': False, 'error': type(exc).__name__ + ': ' + str(exc)[:200]}
            try:
                path.unlink()
            except OSError:
                pass
            events.append(self.record('owner_request', action=request.get('action'), **result))
        return events
