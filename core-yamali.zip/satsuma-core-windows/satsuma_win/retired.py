"""Removes what the retired ClamAV memory scan (RAM v2) left on a machine that had it installed.

RAM v2 is removed from the product (owner's decision 2026-11-24): its clamd
listened on 127.0.0.1:3311 without encryption or a check of who connected, so
any local program could reach it. An earlier version installed ClamAV to
%ProgramFiles%\\Satsuma\\ClamAV and its database to
%ProgramData%\\Satsuma\\clamav. At every service start, at --install and at
--uninstall a clamd.exe or freshclam.exe still running from that folder is
stopped and both folders are deleted; the result is recorded, a failure is
reported, never hidden. Nothing outside these two folders is touched; a
ClamAV the owner installed elsewhere stays as it is.

Kaldırılan ClamAV bellek taramasının (RAM v2) kurulu olduğu makinede
bıraktıklarını siler. RAM v2 üründen kaldırıldı (sahibinin kararı
2026-11-24): clamd'si 127.0.0.1:3311'de şifresiz ve bağlananı denetlemeden
dinliyordu; yerel her program ona ulaşabiliyordu. Önceki sürüm ClamAV'ı
%ProgramFiles%\\Satsuma\\ClamAV klasörüne, veritabanını
%ProgramData%\\Satsuma\\clamav klasörüne kurmuştu. Her hizmet açılışında,
--install ve --uninstall sırasında o klasörden hâlâ çalışan clamd.exe ya da
freshclam.exe durdurulur ve iki klasör silinir; sonuç kaydedilir,
başarısızlık gizlenmez. Bu iki klasörün dışındaki hiçbir şeye dokunulmaz;
sahibinin başka yere kurduğu ClamAV olduğu gibi kalır.
"""
import os
import shutil
from pathlib import Path

PORT = 3311
PROGRAMS = ('clamd.exe', 'freshclam.exe')


def engine_dir(environ=os.environ):
    return Path(environ.get('ProgramFiles', r'C:\Program Files')) / 'Satsuma' / 'ClamAV'


def data_dir(state_dir):
    return Path(state_dir) / 'clamav'


def _inside(path, folder):
    path, folder = str(path or '').lower().rstrip('\\/'), str(folder).lower().rstrip('\\/')
    return path.startswith(folder + '\\') or path.startswith(folder + '/')


def _processes():
    import psutil
    return psutil.process_iter(['pid', 'name', 'exe'])


def stop_leftovers(engine, processes=_processes):
    """Stop clamd/freshclam running from ``engine``; returns what was stopped and what could not be."""
    stopped, failed = [], []
    for process in processes():
        info = getattr(process, 'info', {}) or {}
        name, exe = (info.get('name') or '').lower(), info.get('exe') or ''
        if name not in PROGRAMS or not _inside(exe, engine):
            continue
        try:
            process.kill()
            process.wait(10)
            stopped.append({'pid': info.get('pid'), 'image': exe})
        except Exception as exc:  # reported; deletion is still tried
            failed.append({'pid': info.get('pid'), 'image': exe, 'error': type(exc).__name__ + ': ' + str(exc)[:200]})
    return stopped, failed


def remove(state_dir, environ=os.environ, processes=_processes):
    """Stop the leftover clamd and delete both RAM v2 folders. NOTHING_LEFT when there was nothing."""
    engine, data = engine_dir(environ), data_dir(state_dir)
    present = [str(p) for p in (engine, data) if p.exists()]
    stopped, failed = stop_leftovers(engine, processes)
    for folder in (engine, data):
        shutil.rmtree(folder, ignore_errors=True)
    left = [str(p) for p in (engine, data) if p.exists()]
    if left or failed:
        status = 'REMOVE_FAILED'
    elif present or stopped:
        status = 'REMOVED'
    else:
        status = 'NOTHING_LEFT'
    return {'ok': not left and not failed, 'status': status, 'removed': [p for p in present if p not in left],
            'left': left, 'stopped': stopped, 'stop_failed': failed}
