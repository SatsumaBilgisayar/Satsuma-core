"""Satsuma Core Windows panel in the Linux panel's design (owner's request 2026-11-24).

PyQt6 with the Linux panel's own style sheet (satsuma/dashboard_qt/style/theme.py, black and
orange): a sidebar, a top bar, and five pages. Durum (protected or not, what waits for the
owner with the button that settles it, the protection layers), Olanlar (every record in plain
Turkish, repeats folded, filters and a detail card with its actions), Güvenlik duvarı (kept
blocks, unblock, unblock all OTX, allowed addresses), Aygıtlar (devices Satsuma disabled; allow
one, a VPN adapter say) and Kayıtlar (raw records). Actions only write a request
(satsuma_win.owner_requests) that the service applies signed within a minute; the panel itself
changes nothing and opens no network port. Needs an administrator account.

Linux panelinin tasarımıyla Windows paneli: aynı siyah-turuncu stil sayfası; Durum, Olanlar,
Güvenlik duvarı, Aygıtlar, Kayıtlar. Düğmeler yalnızca istek yazar; hizmet bir dakika içinde
imzalayıp uygular. Panel ağ portu açmaz. Yönetici hesabı gerekir.
"""
import importlib.util
import json
import os
import sys
import time
from pathlib import Path

from . import owner_requests, panel_data

REFRESH_MS = 5000


def _linux_file(name, inside):
    base = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parents[2]))
    for path in (base / 'linux_theme' / name, base / 'satsuma' / 'dashboard_qt' / inside / name):
        if path.exists():
            return path
    raise FileNotFoundError('Linux panel ' + name)


def _linux_source(name, inside):
    """The Linux panel file's source: embedded in the exe at build time (owner's approval 2026-11-25, so the
    exe's digest covers it and nothing is read from the unpack folder), else the file in the source tree.
    Derlemede exe'ye gömülü kaynak; yoksa kaynak ağacındaki dosya."""
    try:
        from . import linux_theme_embedded
        return linux_theme_embedded.SOURCES[name]
    except (ImportError, KeyError):
        return _linux_file(name, inside).read_text(encoding='utf-8')


def linux_theme():
    """The Linux panel's theme.py (its package imports the Linux backend, so it is run on its own)."""
    if 'satsuma_linux_theme' in sys.modules:
        return sys.modules['satsuma_linux_theme']
    module = type(sys)('satsuma_linux_theme')
    exec(compile(_linux_source('theme.py', 'style'), 'theme.py', 'exec'), module.__dict__)
    sys.modules['satsuma_linux_theme'] = module
    return module


def linux_widgets():
    """The Linux panel's icons and shield artwork (security_widgets.py: Qt and the theme only)."""
    linux_theme()
    source = _linux_source('security_widgets.py', '.')
    source = source.replace('from .style.theme import Colors', 'from satsuma_linux_theme import Colors')
    module = type(sys)('satsuma_linux_widgets')
    exec(compile(source, 'security_widgets.py', 'exec'), module.__dict__)
    return module


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    from PyQt6 import QtCore, QtGui, QtWidgets
    Qt = QtCore.Qt
    theme = linux_theme()
    C = theme.Colors
    qss = theme.GLOBAL_QSS.replace('"Inter", "Noto Sans"', '"Segoe UI", "Inter", "Noto Sans"').replace(
        'FreeMono, "DejaVu Sans Mono"', 'Consolas, "Cascadia Mono", FreeMono, "DejaVu Sans Mono"')
    LEVEL = {'block': C.STATUS_OK, 'stop': C.STATUS_WARN, 'alert': C.STATUS_CRIT, 'problem': C.STATUS_CRIT,
             'info': C.TEXT_MUTED, 'warn': C.STATUS_WARN}
    directory = panel_data.state_dir()

    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv[:1])
    app.setStyleSheet(qss)
    app.setFont(QtGui.QFont('Segoe UI', 10))

    def label(text='', name=None, wrap=False):
        w = QtWidgets.QLabel(text)
        if name:
            w.setObjectName(name)
        w.setWordWrap(wrap)
        w.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        return w

    def frame(name, layout='v', margins=(16, 14, 16, 14), spacing=8):
        f = QtWidgets.QFrame()
        f.setObjectName(name)
        lay = QtWidgets.QVBoxLayout(f) if layout == 'v' else QtWidgets.QHBoxLayout(f)
        lay.setContentsMargins(*margins)
        lay.setSpacing(spacing)
        return f, lay

    def clear(layout):
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
            elif item.layout():
                clear(item.layout())

    def badge(text, level):
        colour = LEVEL.get(level, C.TEXT_MUTED)
        b = QtWidgets.QLabel(text)
        b.setAlignment(Qt.AlignmentFlag.AlignCenter)
        b.setFixedWidth(104)
        b.setStyleSheet(f'background:{colour}22;color:{colour};border-radius:8px;padding:10px 4px;font-weight:700;font-size:12px;')
        return b

    def dot(ok):
        d = QtWidgets.QLabel('●')
        d.setStyleSheet(f"color:{C.STATUS_OK if ok else (C.STATUS_WARN if ok is None else C.STATUS_CRIT)};font-size:14px;")
        return d

    window = QtWidgets.QMainWindow()
    window.setWindowTitle('Satsuma Core')
    window.resize(1420, 900)
    central = QtWidgets.QWidget()
    central.setObjectName('central')
    window.setCentralWidget(central)
    root = QtWidgets.QHBoxLayout(central)
    root.setContentsMargins(0, 0, 0, 0)
    root.setSpacing(0)

    # Sidebar ----------------------------------------------------------------------------
    side, side_lay = frame('mainSidebar', margins=(16, 22, 16, 16), spacing=6)
    side.setFixedWidth(236)
    brand = QtWidgets.QHBoxLayout()
    widgets = linux_widgets()
    shield = QtWidgets.QLabel()
    shield.setPixmap(widgets.icon('shield', C.ACCENT, 30).pixmap(QtCore.QSize(30, 30)))
    names = QtWidgets.QVBoxLayout()
    names.setSpacing(0)
    names.addWidget(label('SATSUMA', 'brandName'))
    names.addWidget(label('INTERNET SECURITY', 'brandSub'))
    brand.addWidget(shield)
    brand.addLayout(names)
    brand.addStretch()
    side_lay.addLayout(brand)
    side_lay.addSpacing(22)
    pages = QtWidgets.QStackedWidget()
    nav = []
    nav_group = QtWidgets.QButtonGroup(window)
    for index, (symbol, text) in enumerate((('home', 'Durum'), ('activity', 'Olanlar'), ('firewall', 'Güvenlik duvarı'),
                                            ('network', 'Aygıtlar'), ('logs', 'Kayıtlar'))):
        button = QtWidgets.QPushButton('  ' + text)
        button.setIcon(widgets.icon(symbol, C.TEXT_SECONDARY, 20))
        button.setIconSize(QtCore.QSize(20, 20))
        button.setObjectName('navPrimary')
        button.setCheckable(True)
        button.clicked.connect(lambda _c, i=index: pages.setCurrentIndex(i))
        nav_group.addButton(button)
        side_lay.addWidget(button)
        nav.append(button)
    nav[0].setChecked(True)
    side_lay.addStretch()
    service_line = label('', 'secondary', wrap=True)
    side_lay.addWidget(service_line)
    root.addWidget(side)

    # Top bar + pages ----------------------------------------------------------------------
    right = QtWidgets.QWidget()
    right_lay = QtWidgets.QVBoxLayout(right)
    right_lay.setContentsMargins(0, 0, 0, 0)
    right_lay.setSpacing(0)
    top, top_lay = frame('topBar', 'h', margins=(32, 12, 24, 12))
    top_title = label('Durum', 'topTitle')
    search = QtWidgets.QLineEdit()
    search.setObjectName('topSearch')
    search.setPlaceholderText('Ara: program, adres, kural (Olanlar)')
    search.setFixedWidth(340)
    search.addAction(widgets.icon('search', C.TEXT_MUTED, 16), QtWidgets.QLineEdit.ActionPosition.LeadingPosition)
    attention = QtWidgets.QPushButton()
    attention.setIcon(widgets.icon('bell', C.TEXT_SECONDARY, 18))
    attention.setObjectName('topAttention')
    attention.clicked.connect(lambda: (nav[0].click()))
    top_lay.addWidget(top_title)
    top_lay.addStretch()
    top_lay.addWidget(search)
    top_lay.addWidget(attention)
    right_lay.addWidget(top)
    banner = label('', wrap=True)
    banner.setStyleSheet(f'background:#3a2a0a;color:{C.STATUS_WARN};padding:10px 32px;')
    banner.hide()
    right_lay.addWidget(banner)
    right_lay.addWidget(pages, 1)
    root.addWidget(right, 1)
    status_bar = window.statusBar()

    def scroll_page(title, subtitle):
        area = QtWidgets.QScrollArea()
        area.setWidgetResizable(True)
        inner = QtWidgets.QWidget()
        inner.setObjectName('page')
        lay = QtWidgets.QVBoxLayout(inner)
        lay.setContentsMargins(32, 26, 32, 26)
        lay.setSpacing(12)
        lay.addWidget(label(title, 'pageTitle'))
        lay.addWidget(label(subtitle, 'pageSubtitle', wrap=True))
        area.setWidget(inner)
        pages.addWidget(area)
        return lay

    def plain_page(title, subtitle):
        inner = QtWidgets.QWidget()
        inner.setObjectName('page')
        lay = QtWidgets.QVBoxLayout(inner)
        lay.setContentsMargins(32, 26, 32, 20)
        lay.setSpacing(12)
        lay.addWidget(label(title, 'pageTitle'))
        lay.addWidget(label(subtitle, 'pageSubtitle', wrap=True))
        pages.addWidget(inner)
        return lay

    def send(action, value, text):
        if isinstance(value, dict):  # allow_rule_process / rule_mode carry several fields
            fields, shown = value, value.get('image') or value.get('rule_id')
        else:
            fields = {{'unblock': 'ip', 'approve_location': 'folder', 'approve_device': 'id',
                       'unblock_rule': 'rule'}[action]: value}
            shown = value
        ask = {'allow_rule_process': f"{shown}\n\nBu program, bu dosya değişmediği sürece {fields.get('rule_id')} "
                                     'kuralı yüzünden durdurulmasın mı? Öteki kurallar onu yine durdurur.',
               'rule_mode': f"{fields.get('rule_id')}\n\nBu kural "
                            + ('kapatılsın mı? Kural silinmez, buradan yeniden açılabilir.' if fields.get('mode') == 'disabled'
                               else 'yeniden açılsın mı?'),
               'unblock': f'{value} adresinin engeli kaldırılsın ve bir daha engellenmesin mi?',
               'unblock_rule': 'Tüm OTX engelleri kaldırılsın ve bu adresler bir daha OTX ile engellenmesin mi?',
               'approve_location': f'{value}\n\nBu klasördeki programlar yalnızca RWX bellek yüzünden durdurulmasın mı? '
                                   'Dosyasız bellekten iş parçacığı açan program yine durdurulur.',
               'approve_device': f'{value}\n\nBu aygıta izin verilip hemen açılsın mı?'}[action]
        reply = QtWidgets.QMessageBox.question(window, text, ask)
        if reply != QtWidgets.QMessageBox.StandardButton.Yes:
            return
        # Owner's request 2026-11-25: every request carries the Satsuma administrator password's proof.
        password, ok = QtWidgets.QInputDialog.getText(window, text, 'Satsuma yönetici parolası:',
                                                      QtWidgets.QLineEdit.EchoMode.Password)
        if not ok or not password:
            return
        try:
            owner_requests.write(directory, action, password=password, **fields)
            status_bar.showMessage('İstek hizmete gönderildi; bir dakika içinde uygulanır ve Olanlar\'da görünür.', 15000)
        except ValueError as exc:
            QtWidgets.QMessageBox.warning(window, 'Gönderilemedi', f'{exc}\nParolayı yönetici komut satırında --set-password ile belirleyin.')
        except OSError as exc:
            QtWidgets.QMessageBox.warning(window, 'Gönderilemedi', f'İstek yazılamadı: {exc}\nPanel yönetici olarak mı açık?')

    def action_button(action, primary=False):
        kind, value, text = action
        b = QtWidgets.QPushButton(text)
        if primary:
            b.setObjectName('primary')
        b.clicked.connect(lambda: send(kind, value, text))
        return b

    # Durum ----------------------------------------------------------------------------------
    durum = scroll_page('Durum', 'Bu bilgisayarın korunma durumu ve senden beklenenler.')
    hero, hero_lay = frame('hero', 'h', margins=(34, 30, 34, 30), spacing=30)
    hero_icon = widgets.ShieldArtwork()
    hero_text = QtWidgets.QVBoxLayout()
    hero_tag = QtWidgets.QLabel()
    hero_title = label('', 'heroTitle')
    hero_sub = label('', 'heroText', wrap=True)
    hero_time = label('', 'secondary')
    for w in (hero_tag, hero_title, hero_sub, hero_time):
        hero_text.addWidget(w)
    hero_text.addStretch()
    hero_lay.addWidget(hero_icon)
    hero_lay.addLayout(hero_text, 1)
    durum.addWidget(hero)
    durum.addSpacing(8)
    durum.addWidget(label('Seni bekleyenler', 'sectionTitle'))
    durum.addWidget(label('Kararını ya da onarım bekleyen konular; çözen düğme yanında.', 'secondary'))
    waiting_box = QtWidgets.QVBoxLayout()
    waiting_box.setSpacing(8)
    durum.addLayout(waiting_box)
    durum.addSpacing(8)
    durum.addWidget(label('Koruma katmanları', 'sectionTitle'))
    layer_grid = QtWidgets.QGridLayout()
    layer_grid.setSpacing(12)
    durum.addLayout(layer_grid)
    durum.addStretch()

    # Olanlar ---------------------------------------------------------------------------------
    olanlar = plain_page('Olanlar', "Satsuma'nın bulduğu ve yaptığı her şey. Aynı olay tekrar ettiğinde tek satırda sayılır.")
    chips = QtWidgets.QHBoxLayout()
    chip_group = QtWidgets.QButtonGroup(window)
    chip_state = {'filter': 'Tümü'}
    for name in ('Tümü', 'Durdurulan', 'Engellenen', 'Uyarı', 'Sorun', 'Bildirilen'):
        chip = QtWidgets.QPushButton(name)
        chip.setObjectName('chip')
        chip.setCheckable(True)
        chip.setChecked(name == 'Tümü')
        chip.clicked.connect(lambda _c, n=name: (chip_state.update(filter=n), fill_feed()))
        chip_group.addButton(chip)
        chips.addWidget(chip)
    chips.addStretch()
    olanlar.addLayout(chips)
    feed_count = label('', 'secondary')
    olanlar.addWidget(feed_count)
    split = QtWidgets.QSplitter()
    split.setObjectName('dataSplit')
    feed_list = QtWidgets.QListWidget()
    feed_list.setObjectName('feed')
    feed_list.setVerticalScrollMode(QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel)
    detail, detail_lay = frame('detailCard', margins=(22, 20, 22, 20), spacing=6)
    split.addWidget(feed_list)
    split.addWidget(detail)
    split.setSizes([760, 460])
    olanlar.addWidget(split, 1)

    # Güvenlik duvarı -------------------------------------------------------------------------
    fw_page = plain_page('Güvenlik duvarı', 'Satsuma\'nın koyduğu engeller (imzalı listede tutulur, silinirse geri yazılır) '
                                            've senin izin verdiğin adresler.')
    fw_buttons = QtWidgets.QHBoxLayout()
    unblock_selected = QtWidgets.QPushButton('Seçili engeli kaldır')
    unblock_selected.setObjectName('primary')
    unblock_otx = QtWidgets.QPushButton('Tüm OTX engellerini kaldır')
    fw_buttons.addWidget(unblock_selected)
    fw_buttons.addWidget(unblock_otx)
    fw_buttons.addStretch()
    fw_page.addLayout(fw_buttons)
    block_table = QtWidgets.QTableWidget(0, 4)
    block_table.setObjectName('dataTable')
    block_table.setHorizontalHeaderLabels(['Adres', 'Neden', 'Ayrıntı', 'Ne zamandan beri'])
    allowed_table = QtWidgets.QTableWidget(0, 3)
    allowed_table.setObjectName('dataTable')
    allowed_table.setHorizontalHeaderLabels(['İzin verilen adres', 'Neden', 'Ne zamandan beri'])
    for table in (block_table, allowed_table):
        table.verticalHeader().setVisible(False)
        table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        table.horizontalHeader().setStretchLastSection(True)
        table.setShowGrid(False)
    fw_page.addWidget(block_table, 3)
    fw_page.addWidget(label('İzin verdiklerin (bir daha engellenmez)', 'sectionTitle'))
    fw_page.addWidget(allowed_table, 1)

    def selected_ip():
        row = block_table.currentRow()
        return block_table.item(row, 0).text() if row >= 0 and block_table.item(row, 0) else None

    unblock_selected.clicked.connect(lambda: selected_ip() and send('unblock', selected_ip(), 'Engeli kaldır'))
    unblock_otx.clicked.connect(lambda: send('unblock_rule', 'otx', 'Tüm OTX engellerini kaldır'))

    # Aygıtlar --------------------------------------------------------------------------------
    dev_page = plain_page('Aygıtlar', 'Satsuma\'nın kapattığı aygıtlar (WAN Miniport VPN/PPPoE sürücüleri, sanal makine, '
                                      'Bluetooth...). Kullandığın birine izin verirsen açılır ve açık kalır.')
    dev_allow = QtWidgets.QPushButton('Seçili aygıta izin ver')
    dev_allow.setObjectName('primary')
    dev_bar = QtWidgets.QHBoxLayout()
    dev_bar.addWidget(dev_allow)
    dev_bar.addStretch()
    dev_page.addLayout(dev_bar)
    dev_table = QtWidgets.QTableWidget(0, 3)
    dev_table.setObjectName('dataTable')
    dev_table.setHorizontalHeaderLabels(['Aygıt', 'Tür', 'Kapatıldı'])
    dev_table.verticalHeader().setVisible(False)
    dev_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
    dev_table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
    dev_table.horizontalHeader().setStretchLastSection(True)
    dev_table.setShowGrid(False)
    dev_page.addWidget(dev_table, 1)
    dev_allow.clicked.connect(lambda: dev_table.currentRow() >= 0 and send(
        'approve_device', dev_table.item(dev_table.currentRow(), 0).data(Qt.ItemDataRole.UserRole), 'Aygıta izin ver'))

    # Kayıtlar --------------------------------------------------------------------------------
    rec_page = plain_page('Kayıtlar', 'Hizmetin yazdığı her kayıt (son 6000). Ayrıntı için satırı seçip Teknik ayrıntı\'ya bas.')
    rec_filter = QtWidgets.QLineEdit()
    rec_filter.setPlaceholderText('Süz: tür, program, adres...')
    rec_page.addWidget(rec_filter)
    rec_table = QtWidgets.QTableWidget(0, 3)
    rec_table.setObjectName('dataTable')
    rec_table.setHorizontalHeaderLabels(['Zaman', 'Ne oldu', 'Nerede'])
    rec_table.verticalHeader().setVisible(False)
    rec_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
    rec_table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
    rec_table.horizontalHeader().setStretchLastSection(True)
    rec_table.setShowGrid(False)
    rec_text = QtWidgets.QPlainTextEdit()
    rec_text.setObjectName('technical')
    rec_text.setReadOnly(True)
    rec_text.hide()
    rec_toggle = QtWidgets.QPushButton('Teknik ayrıntı')
    rec_toggle.clicked.connect(lambda: rec_text.setVisible(not rec_text.isVisible()))
    rec_page.addWidget(rec_table, 3)
    rec_page.addWidget(rec_toggle)
    rec_page.addWidget(rec_text, 1)

    state = {'data': None, 'feed': [], 'raw': []}

    def when(t):
        return panel_data.when(t)

    def show_detail(row):
        clear(detail_lay)
        if row is None:
            detail_lay.addWidget(label('Bir satır seç.', 'secondary'))
            detail_lay.addStretch()
            return
        d, e = row['d'], row['event']
        tags = QtWidgets.QHBoxLayout()
        tags.addWidget(badge(d['badge'], d['level']))
        if row['count'] > 1:
            tags.addWidget(label(f"{row['count']} kez", 'countBadge'))
        tags.addStretch()
        detail_lay.addLayout(tags)
        detail_lay.addWidget(label(d['title'], 'detailTitle', wrap=True))
        detail_lay.addWidget(label(panel_data.friendly(d['subject']), 'body', wrap=True))
        what = d['what'] if not str(d['what']).startswith('Program: ') else 'Program: ' + panel_data.friendly(str(d['what'])[9:])
        for name, value in (('NE OLDU', what), ('SATSUMA NE YAPTI', d['did']),
                            ('ZAMAN', f"İlk: {when(row['first'])}\nSon: {when(row['last'])}"), ('KURAL', d['rule'])):
            if value:
                detail_lay.addWidget(label(name, 'fieldLabel'))
                detail_lay.addWidget(label(str(value), 'body', wrap=True))
        if d['actions']:
            detail_lay.addWidget(label('NE YAPABİLİRSİN', 'fieldLabel'))
            for action in d['actions']:
                detail_lay.addWidget(action_button(action, primary=True))
        # Owner's request 2026-11-25: a stopped program can be allowed for this rule, or the DeepSeek rule turned
        # off, only with the Satsuma administrator password. Durdurulan için izin ver / kuralı durdur (parolayla).
        if e.get('kind') == 'rule_finding' and e.get('outcome') == 'stopped' and e.get('rule_id') and e.get('image'):
            if not d['actions']:
                detail_lay.addWidget(label('NE YAPABİLİRSİN', 'fieldLabel'))
            allow = QtWidgets.QPushButton('İzin ver (bu program, bu kural)')
            allow.setObjectName('primary')
            allow.clicked.connect(lambda _c=False, r=e['rule_id'], i=e['image']: send(
                'allow_rule_process', {'rule_id': r, 'image': i}, 'İzin ver'))
            detail_lay.addWidget(allow)
            if str(e['rule_id']).startswith('SATSUMA-AI-'):
                off = QtWidgets.QPushButton('Kuralı durdur')
                off.clicked.connect(lambda _c=False, r=e['rule_id']: send(
                    'rule_mode', {'rule_id': r, 'mode': 'disabled'}, 'Kuralı durdur'))
                detail_lay.addWidget(off)
        technical = QtWidgets.QPlainTextEdit(json.dumps(e, ensure_ascii=False, indent=2, default=str))
        technical.setObjectName('technical')
        technical.setReadOnly(True)
        technical.hide()
        toggle = QtWidgets.QPushButton('Teknik ayrıntı')
        toggle.clicked.connect(lambda: technical.setVisible(not technical.isVisible()))
        detail_lay.addWidget(toggle)
        detail_lay.addWidget(technical, 1)
        detail_lay.addStretch()

    def matches(row):
        f = chip_state['filter']
        level, b = row['d']['level'], row['d']['badge']
        if f == 'Durdurulan' and b not in ('Durduruldu', 'Durdurulamadı', 'Kapatıldı'):
            return False
        if f == 'Engellenen' and b != 'Engellendi':
            return False
        if f == 'Uyarı' and level != 'alert':
            return False
        if f == 'Sorun' and level != 'problem':
            return False
        if f == 'Bildirilen' and b != 'Bildirildi':
            return False
        q = search.text().strip().lower()
        return not q or q in json.dumps(row['event'], ensure_ascii=False, default=str).lower() or q in row['d']['title'].lower()

    def fill_feed():
        rows = [r for r in state['feed'] if matches(r)]
        selected = feed_list.currentRow()
        feed_list.clear()
        for row in rows[:400]:
            d = row['d']
            item = QtWidgets.QListWidgetItem()
            w, lay = frame('feedRow', 'h', margins=(10, 8, 14, 8), spacing=14)
            lay.addWidget(badge(d['badge'], d['level']))
            text = QtWidgets.QVBoxLayout()
            text.setSpacing(2)
            text.addWidget(label(d['title'], 'rowTitle'))
            sub = label(panel_data.friendly(d['subject']), 'secondary')
            text.addWidget(sub)
            lay.addLayout(text, 1)
            if row['count'] > 1:
                lay.addWidget(label(f"{row['count']} kez", 'countBadge'))
            lay.addWidget(label(when(row['last']), 'secondary'))
            item.setSizeHint(QtCore.QSize(10, 66))
            item.setData(Qt.ItemDataRole.UserRole, row)
            feed_list.addItem(item)
            feed_list.setItemWidget(item, w)
        counts = panel_data.collections.Counter(r['d']['badge'] for r in rows)
        feed_count.setText(f"{len(rows)} kayıt · {counts.get('Durduruldu', 0)} durdurma · {counts.get('Engellendi', 0)} engelleme · "
                           f"{counts.get('Bildirildi', 0)} yalnızca bildirim")
        if rows:
            feed_list.setCurrentRow(min(max(selected, 0), len(rows) - 1))

    feed_list.currentItemChanged.connect(lambda cur, _p: show_detail(cur.data(Qt.ItemDataRole.UserRole) if cur else None))
    search.textChanged.connect(lambda _t: (nav[1].click(), fill_feed()))

    def fill_table(table, rows):
        table.setRowCount(len(rows))
        for r, values in enumerate(rows):
            for c, value in enumerate(values):
                table.setItem(r, c, QtWidgets.QTableWidgetItem('' if value is None else str(value)))
        table.resizeColumnsToContents()

    def fill_records():
        q = rec_filter.text().strip().lower()
        rows = [e for e in reversed(state['raw']) if not q or q in json.dumps(e, ensure_ascii=False, default=str).lower()][:1500]
        state['rec_rows'] = rows
        fill_table(rec_table, [(when(e.get('time')), panel_data.describe(e)['title'], panel_data.friendly(panel_data.describe(e)['subject']))
                               for e in rows])

    rec_filter.textChanged.connect(lambda _t: fill_records())
    rec_table.currentCellChanged.connect(lambda row, *_: rec_text.setPlainText(
        json.dumps(state['rec_rows'][row], ensure_ascii=False, indent=2, default=str) if 0 <= row < len(state.get('rec_rows', [])) else ''))

    def refresh():
        try:
            data = panel_data.read_panel(directory)
        except Exception as exc:  # shown; the next refresh tries again
            status_bar.showMessage('Okunamadı: ' + type(exc).__name__ + ': ' + str(exc)[:200])
            return
        state.update(data=data, feed=data['feed'], raw=data['raw'])
        live = data['live']
        problems = [w for w in data['waiting'] if w['level'] == 'problem']
        stopped_layers = [l for l in data['layers'] if l[1] is False]
        good = live.get('service') == 'running' and not stopped_layers
        colour = C.STATUS_OK if good and not problems else (C.STATUS_WARN if good else C.STATUS_CRIT)
        hero_icon.set_tone('healthy' if good and not problems else ('warning' if good else 'critical'))
        hero_tag.setText('Korunuyor' if good else 'Dikkat')
        hero_tag.setStyleSheet(f'background:{colour}22;color:{colour};border-radius:6px;padding:3px 10px;font-weight:700;')
        hero_tag.setFixedWidth(hero_tag.sizeHint().width() + 8)
        hero_title.setText('Korunuyorsun' if good else ('Hizmet çalışmıyor' if live.get('service') != 'running'
                                                        else 'Bazı katmanlar kapalı'))
        hero_sub.setText('Tüm koruma katmanları açık.' if good and not stopped_layers else
                         'Kapalı: ' + ', '.join(l[0] for l in stopped_layers) if stopped_layers else 'Hizmeti yeniden başlat.')
        if good and problems:
            hero_sub.setText(f'Koruma açık; {len(problems)} konu kararını ya da onarım bekliyor.')
        updated = (data.get('counts') and data['raw'][-1].get('time')) if data['raw'] else None
        hero_time.setText(f"Son kayıt: {when(updated)} · {data['events']} olay")

        clear(waiting_box)
        if not data['waiting']:
            empty, lay = frame('empty')
            lay.addWidget(label('Bekleyen bir şey yok', 'rowTitle'))
            lay.addWidget(label('Senden bir karar ya da onarım beklenmiyor.', 'secondary'))
            waiting_box.addWidget(empty)
        for w in data['waiting']:
            row, lay = frame('actionRow', 'h', margins=(18, 14, 18, 14), spacing=14)
            lay.addWidget(dot(False if w['level'] == 'problem' else (None if w['level'] == 'warn' else True)))
            text = QtWidgets.QVBoxLayout()
            text.addWidget(label(w['title'], 'rowTitle'))
            text.addWidget(label(w['text'], 'secondary', wrap=True))
            lay.addLayout(text, 1)
            if w['action']:
                lay.addWidget(action_button(w['action'], primary=True))
            waiting_box.addWidget(row)
        clear(layer_grid)
        for i, (name, ok, value, text) in enumerate(data['layers']):
            tile, lay = frame('layerTile', margins=(16, 14, 16, 14), spacing=4)
            head = QtWidgets.QHBoxLayout()
            head.addWidget(label(name, 'rowTitle'))
            head.addStretch()
            head.addWidget(dot(ok))
            lay.addLayout(head)
            v = label(value)
            v.setStyleSheet(f"color:{C.STATUS_OK if ok else (C.STATUS_WARN if ok is None else C.STATUS_CRIT)};font-weight:700;")
            lay.addWidget(v)
            lay.addWidget(label(text, 'secondary', wrap=True))
            layer_grid.addWidget(tile, i // 3, i % 3)

        fill_feed()
        blocks = sorted(data['blocks_kept'].items(), key=lambda kv: kv[1].get('since', 0), reverse=True)
        fill_table(block_table, [(ip, panel_data.BLOCK_RULES.get(row.get('reason'), 'Satsuma kuralı'),
                                  (f"OTX'te {(row.get('otx') or {}).get('pulse_count')} kayıt" if row.get('otx') else ''),
                                  when(row.get('since'))) for ip, row in blocks])
        fill_table(allowed_table, [(ip, 'Senin izninle' if str(row.get('reason', '')).startswith('owner') else 'İzinli',
                                    when(row.get('since'))) for ip, row in data['allowed'].items()])
        real = list(data['devices'])  # every device Satsuma disabled, WAN Miniports included (owner's request)
        fill_table(dev_table, [(e.get('name'), panel_data.CATEGORY_TR.get(e.get('category'), e.get('category')), ('kapalı tutuluyor, şu an takılı değil' if e.get('absent') else when(e.get('time'))))
                               for e in real])
        for r, e in enumerate(real):
            dev_table.item(r, 0).setData(Qt.ItemDataRole.UserRole, e.get('id'))
        if pages.currentIndex() == 4 and not rec_filter.text():
            fill_records()
        elif not state.get('rec_rows'):
            fill_records()
        attention.setText(f" {len(data['waiting'])}" if data['waiting'] else '')
        banner.setVisible(bool(problems))
        banner.setText(f"{len(problems)} sağlık sorunu var — ayrıntılar Durum sayfasında." if problems else '')
        service_line.setText(('● Hizmet çalışıyor' if live.get('service') == 'running' else '● Hizmet: ' + str(live.get('service')))
                             + f"\nSuricata {'açık' if live.get('suricata_pid') else 'kapalı'} · Sysmon {live.get('sysmon') or '-'}")
        service_line.setStyleSheet(f"color:{C.STATUS_OK if live.get('service') == 'running' else C.STATUS_CRIT};")
        status_bar.showMessage(f"Son yenileme {time.strftime('%H:%M:%S')} · {directory} · yalnızca okur; düğmeler hizmete istek bırakır", 0)

    def page_changed(index):
        top_title.setText(('Durum', 'Olanlar', 'Güvenlik duvarı', 'Aygıtlar', 'Kayıtlar')[index])
        if index == 4:
            fill_records()

    pages.currentChanged.connect(page_changed)
    timer = QtCore.QTimer(window)
    timer.timeout.connect(refresh)
    timer.start(REFRESH_MS)
    QtCore.QTimer.singleShot(50, refresh)
    QtGui.QShortcut(QtGui.QKeySequence('Ctrl+F'), window, activated=lambda: search.setFocus())
    for i in range(5):
        QtGui.QShortcut(QtGui.QKeySequence(f'Ctrl+{i + 1}'), window, activated=lambda i=i: nav[i].click())
    window.show()
    if '--smoke' in argv:  # CI: draw every page once with the real data, then close
        for i in range(5):
            QtCore.QTimer.singleShot(400 + 300 * i, lambda i=i: nav[i].click())
        if '--shot' in argv:
            out = argv[argv.index('--shot') + 1]
            for i in range(5):
                QtCore.QTimer.singleShot(550 + 300 * i, lambda i=i: window.grab().save(f'{out}-{i}.png'))
        QtCore.QTimer.singleShot(2600, app.quit)
    return app.exec()
