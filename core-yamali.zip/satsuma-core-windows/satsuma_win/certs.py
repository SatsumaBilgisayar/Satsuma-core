"""Certificate store watch: a root or trusted publisher nobody approved is quarantined (owner's decision 2026-11-24).

A certificate added to the trusted roots lets whoever holds its key read and change every
TLS connection of this machine (man in the middle); one added to the trusted publishers lets
his code run as trusted. The stores are read as Windows keeps them, in the registry (the
physical stores, not the merged view, so Microsoft's automatic root updates are not mistaken
for an attack):

* strict: Root and TrustedPublisher of the machine, of Group Policy and of the enterprise,
  and Root and TrustedPublisher of every signed-in user. At the first start (installation)
  what is there is the baseline, signed with the machine key. A certificate added later that
  is neither in the baseline nor approved by the owner is exported to
  %ProgramData%\\Satsuma\\cert-quarantine and removed from the store, and recorded.
* recorded only: AuthRoot (Microsoft's automatically updated roots) and CA (intermediates);
  an addition is recorded with its subject, nothing is removed.
* Disallowed: a certificate taken out of it is recorded.

The owner approves a certificate with ``--cert-approve <thumbprint>`` (administrator
command line); a quarantined one is put back. Every approval is signed with the machine key.

Sertifika deposu bekçisi: kimsenin onaylamadığı kök ya da güvenilen yayıncı karantinaya
alınır (sahibinin kararı 2026-11-24). Depolar kayıt defterindeki fiziksel halleriyle okunur;
Microsoft'un otomatik kök güncellemeleri saldırı sanılmaz. Root ve TrustedPublisher (makine,
grup ilkesi, kuruluş, oturum açmış her kullanıcı): ilk açılıştaki içerik makine anahtarıyla
imzalı taban çizgisidir; sonradan eklenen, onaylanmamış sertifika dışa aktarılıp depodan
silinir ve kaydedilir. AuthRoot ve CA eklemeleri yalnızca kaydedilir. Sahip
``--cert-approve`` ile onaylar; karantinadaki geri konur.
"""
import base64
import json
import os
import re
import struct
import time
from pathlib import Path

BASE = 'cert-baseline.json'
APPROVED = 'cert-approved.json'
QUARANTINE = 'cert-quarantine'
REQUESTS = 'cert-requests'
THUMB = re.compile(r'^[0-9A-F]{40}$')
MACHINE = {
    'Root': r'SOFTWARE\Microsoft\SystemCertificates\Root\Certificates',
    'TrustedPublisher': r'SOFTWARE\Microsoft\SystemCertificates\TrustedPublisher\Certificates',
    'PolicyRoot': r'SOFTWARE\Policies\Microsoft\SystemCertificates\Root\Certificates',
    'PolicyTrustedPublisher': r'SOFTWARE\Policies\Microsoft\SystemCertificates\TrustedPublisher\Certificates',
    'EnterpriseRoot': r'SOFTWARE\Microsoft\EnterpriseCertificates\Root\Certificates',
    'EnterpriseTrustedPublisher': r'SOFTWARE\Microsoft\EnterpriseCertificates\TrustedPublisher\Certificates',
}
RECORD_ONLY = {
    'AuthRoot': r'SOFTWARE\Microsoft\SystemCertificates\AuthRoot\Certificates',
    'CA': r'SOFTWARE\Microsoft\SystemCertificates\CA\Certificates',
}
DISALLOWED = r'SOFTWARE\Microsoft\SystemCertificates\Disallowed\Certificates'
USER = {'UserRoot': r'Software\Microsoft\SystemCertificates\Root\Certificates',
        'UserTrustedPublisher': r'Software\Microsoft\SystemCertificates\TrustedPublisher\Certificates'}
USER_SID = re.compile(r'^S-1-5-21-[\d-]+$')
CERT_PROP_ID = 32


def der_from_blob(blob):
    """The certificate inside a registry store's Blob value (a list of property id, flags, length, data)."""
    offset = 0
    while offset + 12 <= len(blob):
        prop, _, length = struct.unpack_from('<III', blob, offset)
        data = blob[offset + 12:offset + 12 + length]
        if prop == CERT_PROP_ID:
            return bytes(data)
        offset += 12 + length
    return None


def describe(blob):
    """Subject, issuer and expiry for the record; never raises. Kayıt için konu, veren, bitiş."""
    try:
        from cryptography import x509
        cert = x509.load_der_x509_certificate(der_from_blob(blob) or b'')
        return {'subject': cert.subject.rfc4514_string()[:300], 'issuer': cert.issuer.rfc4514_string()[:300],
                'not_after': cert.not_valid_after_utc.isoformat() if hasattr(cert, 'not_valid_after_utc')
                else cert.not_valid_after.isoformat()}
    except Exception:  # an unreadable blob is still quarantined; only its description is missing
        return {'subject': None}


class UserRegistry:
    """HKEY_USERS through winreg: the signed-in users' certificate stores."""

    def __init__(self):
        import winreg
        self.winreg = winreg

    def sids(self):
        w, names, index = self.winreg, [], 0
        with w.OpenKey(w.HKEY_USERS, '') as key:
            while True:
                try:
                    names.append(w.EnumKey(key, index))
                except OSError:
                    break
                index += 1
        return [n for n in names if USER_SID.match(n)]

    def _key(self, path, access=None):
        w = self.winreg
        return w.OpenKey(w.HKEY_USERS, path, 0, access or w.KEY_READ)

    def subkeys(self, path):
        try:
            key = self._key(path)
        except FileNotFoundError:
            return []
        names, index = [], 0
        with key:
            while True:
                try:
                    names.append(self.winreg.EnumKey(key, index))
                except OSError:
                    break
                index += 1
        return names

    def blob(self, path):
        try:
            with self._key(path) as key:
                return bytes(self.winreg.QueryValueEx(key, 'Blob')[0])
        except (FileNotFoundError, OSError):
            return b''

    def delete_key(self, path):
        self.winreg.DeleteKey(self.winreg.HKEY_USERS, path)

    def restore(self, path, blob):
        w = self.winreg
        with w.CreateKeyEx(w.HKEY_USERS, path, 0, w.KEY_SET_VALUE) as key:
            w.SetValueEx(key, 'Blob', 0, w.REG_BINARY, blob)


class MachineRegistry(UserRegistry):
    """HKEY_LOCAL_MACHINE, 64-bit view, with the same methods."""

    def __init__(self):
        import winreg
        self.winreg = winreg

    def sids(self):
        return []

    def _key(self, path, access=None):
        w = self.winreg
        return w.OpenKey(w.HKEY_LOCAL_MACHINE, path, 0, (access or w.KEY_READ) | w.KEY_WOW64_64KEY)

    def delete_key(self, path):
        w = self.winreg
        w.DeleteKeyEx(w.HKEY_LOCAL_MACHINE, path, w.KEY_WOW64_64KEY, 0)

    def restore(self, path, blob):
        w = self.winreg
        with w.CreateKeyEx(w.HKEY_LOCAL_MACHINE, path, 0, w.KEY_SET_VALUE | w.KEY_WOW64_64KEY) as key:
            w.SetValueEx(key, 'Blob', 0, w.REG_BINARY, blob)


def write_request(state_dir, thumbprint):
    folder = Path(state_dir) / REQUESTS
    folder.mkdir(parents=True, exist_ok=True)
    name = '%d.json' % time.time_ns()
    (folder / (name + '.tmp')).write_text(json.dumps({'approve': thumbprint.upper()}), encoding='utf-8')
    os.replace(folder / (name + '.tmp'), folder / name)
    return name


class CertWatch:
    def __init__(self, state_dir, key, record, machine=None, users=None, clock=time.time):
        self.dir, self.key, self.record, self.clock = Path(state_dir), key, record, clock
        self.machine = machine if machine is not None else MachineRegistry()
        self.users = users if users is not None else UserRegistry()
        self.baseline, self.counts = None, {'quarantined': 0, 'quarantine_failed': 0, 'recorded': 0}

    # stores
    def stores(self):
        """{store name: (registry, key path, strict)} for the machine and every signed-in user."""
        rows = {name: (self.machine, path, True) for name, path in MACHINE.items()}
        rows.update({name: (self.machine, path, False) for name, path in RECORD_ONLY.items()})
        for sid in self.users.sids():
            for name, path in USER.items():
                rows[sid + ':' + name] = (self.users, sid + '\\' + path, True)
        return rows

    def snapshot(self):
        found = {}
        for name, (registry, path, _) in self.stores().items():
            found[name] = sorted(t.upper() for t in registry.subkeys(path) if THUMB.match(t.upper()))
        found['Disallowed'] = sorted(t.upper() for t in self.machine.subkeys(DISALLOWED) if THUMB.match(t.upper()))
        return found

    # signed files
    def _signed_read(self, name):
        try:
            data = json.loads((self.dir / name).read_text(encoding='utf-8'))
            body = data['body']
            if self.key is not None and self.key.verify(json.dumps(body, sort_keys=True).encode(), data['signature']):
                return body
        except (OSError, ValueError, KeyError, TypeError):
            pass
        return None

    def _signed_write(self, name, body):
        self.dir.mkdir(parents=True, exist_ok=True)
        text = json.dumps({'body': body, 'signature': self.key.sign(json.dumps(body, sort_keys=True).encode())})
        (self.dir / (name + '.tmp')).write_text(text, encoding='utf-8')
        os.replace(self.dir / (name + '.tmp'), self.dir / name)

    def approved(self):
        return set((self._signed_read(APPROVED) or {}).get('thumbprints') or [])

    def start(self):
        """Load the signed baseline; at the first start (installation) take it. İlk açılışta taban çizgisi alınır."""
        if self.key is None:
            return {'ok': False, 'status': 'NO_MACHINE_KEY'}
        self.baseline = self._signed_read(BASE)
        if self.baseline is None:
            if (self.dir / BASE).exists():
                # A baseline whose signature fails was changed by hand: kept aside, never trusted.
                os.replace(self.dir / BASE, self.dir / ('rejected-' + time.strftime('%Y%m%d%H%M%S') + '-' + BASE))
                self.record('cert_baseline_rejected')
            self.baseline = {'taken_at': self.clock(), 'stores': self.snapshot()}
            self._signed_write(BASE, self.baseline)
            return {'ok': True, 'status': 'BASELINE_TAKEN', 'counts': {k: len(v) for k, v in self.baseline['stores'].items()}}
        return {'ok': True, 'status': 'LOADED', 'counts': {k: len(v) for k, v in self.baseline['stores'].items()}}

    def _known(self, store):
        base = self.baseline['stores']
        if ':' in store:
            # A user who signs in later had no baseline: a user store counts the machine's as known.
            # Sonradan oturum açan kullanıcının taban çizgisi yoktur; makinenin kökleri bilinir sayılır.
            kind = store.split(':', 1)[1].replace('User', '')
            return set(base.get(store) or []) | set(base.get(kind) or [])
        return set(base.get(store) or [])

    def process_requests(self):
        folder = self.dir / REQUESTS
        events = []
        for path in sorted(folder.glob('*.json')) if folder.is_dir() else []:
            try:
                thumb = str(json.loads(path.read_text(encoding='utf-8')).get('approve', '')).upper()
            except (OSError, ValueError):
                thumb = ''
            path.unlink(missing_ok=True)
            if not THUMB.match(thumb) or self.key is None:
                continue
            rows = sorted(self.approved() | {thumb})
            self._signed_write(APPROVED, {'thumbprints': rows})
            events.append(self.record('cert_approved', thumbprint=thumb, restored=self._unquarantine(thumb)))
        return events

    def _unquarantine(self, thumb):
        restored = []
        folder = self.dir / QUARANTINE
        for path in sorted(folder.glob('*-' + thumb + '.json')) if folder.is_dir() else []:
            try:
                row = json.loads(path.read_text(encoding='utf-8'))
                registry = self.users if row['hive'] == 'HKU' else self.machine
                registry.restore(row['key'], base64.b64decode(row['blob']))
                path.unlink()
                restored.append(row['store'])
            except (OSError, ValueError, KeyError):
                continue
        return restored

    def check(self):
        """Once a minute: quarantine what is new in a strict store, record what is new elsewhere."""
        if self.baseline is None:
            return []
        events = self.process_requests()
        approved = self.approved()
        now = self.snapshot()
        stores = self.stores()
        for store, thumbs in now.items():
            if store == 'Disallowed':
                gone = sorted(set(self.baseline['stores'].get('Disallowed') or []) - set(thumbs))
                for thumb in gone:
                    events.append(self.record('cert_disallowed_removed', thumbprint=thumb))
                if gone:
                    self.baseline['stores']['Disallowed'] = thumbs
                    self._signed_write(BASE, self.baseline)
                continue
            registry, path, strict = stores[store]
            for thumb in sorted(set(thumbs) - self._known(store) - approved):
                key = path + '\\' + thumb
                blob = registry.blob(key)
                info = describe(blob)
                if not strict:
                    self.counts['recorded'] += 1
                    events.append(self.record('cert_added', store=store, thumbprint=thumb, **info))
                    self.baseline['stores'].setdefault(store, []).append(thumb)
                    self._signed_write(BASE, self.baseline)
                    continue
                try:
                    folder = self.dir / QUARANTINE
                    folder.mkdir(parents=True, exist_ok=True)
                    (folder / (store.replace(':', '_') + '-' + thumb + '.json')).write_text(json.dumps(
                        {'store': store, 'hive': 'HKU' if ':' in store else 'HKLM', 'key': key,
                         'blob': base64.b64encode(blob).decode(), 'quarantined_at': self.clock(), **info}), encoding='utf-8')
                    registry.delete_key(key)
                    self.counts['quarantined'] += 1
                    events.append(self.record('cert_quarantined', store=store, thumbprint=thumb, **info))
                except OSError as exc:
                    self.counts['quarantine_failed'] += 1
                    events.append(self.record('cert_quarantine_failed', store=store, thumbprint=thumb,
                                              error=str(exc)[:200], **info))
        return events
