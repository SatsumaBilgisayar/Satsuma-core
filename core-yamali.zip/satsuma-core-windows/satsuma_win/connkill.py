"""Ends the open TCP connections to an address Satsuma just blocked (the Linux connection_kill on Windows).

A firewall rule stops new connections only; one already open keeps running. After every
block (PTR rule, subnet limit, OTX) every established IPv4 TCP connection to that address is
deleted with SetTcpEntry (MIB_TCP_STATE_DELETE_TCB), the documented way to reset a connection;
every result is recorded. Protected addresses are never blocked, so never reach here.

Satsuma'nın engellediği adrese açık TCP bağlantılarını sonlandırır (Linux connection_kill'in
Windows karşılığı). Güvenlik duvarı kuralı yalnızca yeni bağlantıyı durdurur; her engelden sonra
o adrese kurulu her IPv4 TCP bağlantısı SetTcpEntry ile silinir ve sonuç kaydedilir.
"""
import ipaddress
import struct

DELETE_TCB = 12


def _row(conn):
    import ctypes
    from ctypes import wintypes

    class MIB_TCPROW(ctypes.Structure):
        _fields_ = [('dwState', wintypes.DWORD), ('dwLocalAddr', wintypes.DWORD), ('dwLocalPort', wintypes.DWORD),
                    ('dwRemoteAddr', wintypes.DWORD), ('dwRemotePort', wintypes.DWORD)]
    pack = lambda ip: struct.unpack('<I', ipaddress.IPv4Address(ip).packed)[0]
    port = lambda p: struct.unpack('<H', struct.pack('>H', p))[0]  # network byte order in the low word
    return MIB_TCPROW(DELETE_TCB, pack(conn['local_ip']), port(conn['local_port']),
                      pack(conn['remote_ip']), port(conn['remote_port']))


def set_tcp_entry(conn):
    import ctypes
    row = _row(conn)
    code = ctypes.windll.iphlpapi.SetTcpEntry(ctypes.byref(row))
    if code != 0:
        raise OSError(code, 'SetTcpEntry')


def established(ip, connections=None):
    """Open IPv4 TCP connections to ``ip`` as {local_ip, local_port, remote_ip, remote_port, pid}."""
    if connections is None:
        import psutil
        connections = psutil.net_connections(kind='tcp4')
    rows = []
    for c in connections:
        if getattr(c, 'status', '') != 'ESTABLISHED' or not c.raddr or c.raddr[0] != ip:
            continue
        rows.append({'local_ip': c.laddr[0], 'local_port': c.laddr[1], 'remote_ip': c.raddr[0],
                     'remote_port': c.raddr[1], 'pid': c.pid})
    return rows


def kill(ip, connections=None, delete=set_tcp_entry):
    """Reset every established connection to ``ip``; returns {'ended': [...], 'failed': [...]}."""
    if ipaddress.ip_address(ip).version != 4:
        return {'ended': [], 'failed': [], 'note': 'ipv6_off'}
    ended, failed = [], []
    for conn in established(ip, connections):
        try:
            delete(conn)
            ended.append(conn)
        except OSError as exc:
            failed.append({**conn, 'error': str(exc)[:120]})
    return {'ended': ended, 'failed': failed}
