"""DeepSeek rules on Windows: fetched automatically, checked, signed with the machine key, stopping within limits.

The Windows counterpart of the Linux DeepSeek chain (satsuma.deepseek_client, ai_rule_package,
ai_guard, rule_signing). Owner's decisions 2026-11-24: rules come from DeepSeek; for every
attack type of ATTACK_TYPES at least TARGET_PER_TYPE (10) rules are fetched automatically;
a rule that passes every local check is activated without waiting for an approval and may
stop processes, within the limits below.

* Key: given once by the owner from an administrator command line (``--deepseek-key``),
  handed to the service through the requests folder (SYSTEM and Administrators only) and
  kept encrypted with Windows DPAPI for the SYSTEM account; it never appears in a record.
  Giving the key is the consent to the automatic requests; ``--deepseek-off`` removes it.
* Requests: only the service talks to DeepSeek, over the same pinned HTTPS client as Linux
  (satsuma.deepseek_client._http_post: one endpoint, no redirect, bounded answer). One
  request at a time, in a background thread, at most one every AUTO_EVERY seconds and
  DAILY_LIMIT a day; a type refused three times in a row waits REFUSAL_WAIT, an error waits
  ERROR_WAIT, a quota answer QUOTA_WAIT, a rejected key waits for a new key.
* Checks (all of them, every rule): the shared schema and the Windows engine
  (satsuma_win.rules.compile_rule); an id of its own (SATSUMA-AI-WIN-...), no repeat of
  an existing rule; only record/evidence/correlation_request actions; a stopping
  classification; at most 16 patterns of 512 characters per matcher, each regex linear
  (the Linux probe of satsuma.ai_guard, in a child process with a hard timeout); every
  positive test event the model wrote must match and every negative must not, through the
  Windows engine itself; and no match at all on Satsuma's own commands or on the everyday
  events of satsuma_win.corpus. A refused rule is recorded with its reasons and its type
  is asked again with those reasons (as Linux does).
* Activation: the rule, its checks and the time are signed with the machine key
  (satsuma_win.machine_key, Ed25519, DPAPI); the engine loads only rules whose signature
  verifies, so a rule file written by hand is never loaded.
* Stops: a DeepSeek rule never stops Windows' own system processes, the desktop,
  Defender, Sysmon or Satsuma; a process rule must still match the live command line of
  the same program right before the stop; at most STOP_LIMIT stops per rule in
  STOP_WINDOW, then the rule only records for STOP_COOLDOWN. The owner can set a rule to
  report only, disable it or remove it (administrator command line).

Windows'ta DeepSeek kuralları: otomatik çekilir, denetlenir, makine anahtarıyla imzalanır,
sınırlar içinde durdurur. Sahibinin kararları 2026-11-24: kurallar DeepSeek'ten gelir; her
saldırı türü için en az 10 kural otomatik çekilir; her yerel denetimden geçen kural onay
beklemeden devreye girer ve süreç durdurabilir. Anahtar yönetici komut satırından bir kez
verilir, hizmete istek klasörüyle ulaşır ve SYSTEM için DPAPI ile şifrelenir; kayda asla
girmez. DeepSeek ile yalnızca hizmet konuşur, Linux'la aynı sabitlenmiş HTTPS istemcisiyle.
Denetimler: ortak şema ve Windows motoru, kendi kimliği, tekrar yok, yalnızca güvenli
eylemler, durduran sınıf, doğrusal regex, modelin yazdığı olumlu/olumsuz deneme olayları
Windows motorunda sınanır, Satsuma'nın kendi komutlarıyla ve gündelik olaylarla hiç
eşleşmez. Geçen kural makine anahtarıyla imzalanır; imzası tutmayan kural yüklenmez.
Durdurma: Windows sistem süreçleri, masaüstü, Defender, Sysmon ve Satsuma asla; süreç
kuralı durdurmadan hemen önce canlı komut satırında yeniden eşleşmeli; kural başına on
dakikada en çok 5 durdurma, sonra bir saat yalnızca kayıt.
"""
import hashlib
import json
import os
import re
import secrets
import subprocess
import sys
import threading
import time
from pathlib import Path

from . import corpus
from .rules import MAX_TEXT, SOURCES, RuleError, compile_rule, matches, view

AI_PREFIX = 'SATSUMA-AI-WIN-'
ID_PATTERN = re.compile(r'SATSUMA-AI-WIN-[A-Z0-9][A-Z0-9-]{0,59}\Z')
TARGET_PER_TYPE = 10
# Owner's request 2026-11-25: up to MAX_PER_TYPE per type; past the target a type gets at most
# AFTER_TARGET_PER_DAY requests a day, so one type never takes the whole daily limit.
MAX_PER_TYPE = 50
AFTER_TARGET_PER_DAY = 5
AUTO_EVERY = 90.0
DAILY_LIMIT = 400
REFUSALS_BEFORE_WAIT = 3
REFUSAL_WAIT = 1800.0
ERROR_WAIT = 600.0
QUOTA_WAIT = 3600.0
STOP_LIMIT = 5
STOP_WINDOW = 600.0
STOP_COOLDOWN = 3600.0
MAX_PACKAGE_BYTES = 32768
MAX_PATTERNS = 16
MAX_PATTERN_LENGTH = 512
MAX_TEST_EVENTS = 12
SAFE_ACTIONS = frozenset({'record', 'evidence', 'correlation_request'})
STOPPING = ('suspicious', 'likely')
REGEX_KEYS = ('cmd_regex', 'cmd_regex_cs', 'cmd_not_regex', 'exe_regex', 'exe_not_regex', 'parent_exe_regex',
              'target_regex', 'details_regex')
LINEAR_TIMEOUT = 2.0
# The one-file exe unpacks itself before the probe runs (seconds on Windows); the probe measures
# only the search's own CPU time, so the hard cap is longer there. Tek dosyalık exe önce açılır.
FROZEN_LINEAR_TIMEOUT = 20.0
# Never stopped by a DeepSeek rule (an alarm instead): Windows itself, the desktop, the
# security programs, Satsuma. Bir DeepSeek kuralının asla durdurmadığı süreçler.
PROTECTED_NAMES = frozenset((
    'smss.exe', 'csrss.exe', 'wininit.exe', 'winlogon.exe', 'services.exe', 'lsass.exe', 'lsaiso.exe', 'lsm.exe',
    'svchost.exe', 'fontdrvhost.exe', 'dwm.exe', 'explorer.exe', 'sihost.exe', 'ctfmon.exe', 'taskhostw.exe',
    'runtimebroker.exe', 'searchhost.exe', 'startmenuexperiencehost.exe', 'shellexperiencehost.exe',
    'msmpeng.exe', 'nissrv.exe', 'mpdefendercoreservice.exe', 'securityhealthservice.exe',
    'sysmon64.exe', 'sysmon.exe', 'satsuma-core-windows.exe', 'trustedinstaller.exe', 'tiworker.exe', 'msiexec.exe',
    'wuauclt.exe', 'conhost.exe', 'spoolsv.exe', 'audiodg.exe'))
# The names count only from Windows' own folders: an explorer.exe in Temp is stopped like any program.
# Adlar yalnızca Windows'un kendi klasörlerinden sayılır: Temp'teki explorer.exe her program gibi durdurulur.
WINDOWS_FOLDERS = re.compile(r'^[a-z]:\\windows\\((system32|syswow64|servicing)\\)?[^\\]+$|'
                             r'^[a-z]:\\windows\\systemapps\\', re.IGNORECASE)
PROTECTED_FOLDERS = re.compile(r'^[a-z]:\\program files\\(windows defender|satsuma)\\|'
                               r'^[a-z]:\\programdata\\microsoft\\windows defender\\', re.IGNORECASE)

# Windows attack types: ATT&CK techniques, the variants to ask for, the sources that see them.
# Windows saldırı türleri: ATT&CK teknikleri, istenecek çeşitler, onları gören kaynaklar.
ATTACK_TYPES = {
    'reverse_shell': {'mitre': ['T1059.001', 'T1059.003', 'T1095'], 'sources': ['win_proc', 'win_network'],
                      'variants': ['PowerShell TCPClient', 'netcat/ncat -e', 'socat', 'powercat', 'ConPtyShell',
                                   'msfvenom payload exe', 'Nishang Invoke-PowerShellTcp', 'python -c socket']},
    'privilege_escalation': {'mitre': ['T1548.002', 'T1134', 'T1068', 'T1574.011'], 'sources': ['win_proc', 'win_registry'],
                             'variants': ['UAC bypass fodhelper/computerdefaults/sdclt', 'token impersonation (PrintSpoofer, JuicyPotato, GodPotato)',
                                          'service binPath change', 'AlwaysInstallElevated', 'cmstp UAC bypass', 'SeDebugPrivilege abuse']},
    'credential_access': {'mitre': ['T1003.001', 'T1003.002', 'T1003.003', 'T1555', 'T1552.001', 'T1558.003'],
                          'sources': ['win_proc', 'win_process_access', 'win_registry', 'win_file'],
                          'variants': ['LSASS dump with rundll32/comsvcs, procdump, Task Manager', 'reg save SAM/SYSTEM', 'ntdsutil/vssadmin NTDS copy',
                                       'Mimikatz/LaZagne/Rubeus', 'Kerberoasting', 'browser password store copy', 'unattend.xml/GPP password search']},
    'persistence': {'mitre': ['T1547.001', 'T1053.005', 'T1543.003', 'T1546.003', 'T1546.012', 'T1547.004', 'T1546.015'],
                    'sources': ['win_registry', 'win_proc', 'win_file'],
                    'variants': ['Run/RunOnce key', 'scheduled task', 'new service', 'WMI subscription', 'IFEO debugger',
                                 'Winlogon Userinit/Shell', 'COM hijack', 'Startup folder', 'BITS job', 'Office add-in']},
    'defense_evasion': {'mitre': ['T1562.001', 'T1070.001', 'T1218', 'T1027', 'T1112', 'T1564.001', 'T1222.001'],
                        'sources': ['win_proc', 'win_registry'],
                        'variants': ['Defender tampering', 'event log clearing', 'firewall off', 'AMSI bypass', 'hidden attributes (attrib +h +s)',
                                     'timestomping', 'ETW patching', 'icacls/takeown on security files']},
    'discovery': {'mitre': ['T1087', 'T1018', 'T1069', 'T1082', 'T1016', 'T1046'], 'sources': ['win_proc'],
                  'variants': ['AdFind', 'SharpHound', 'net view /all', 'nltest', 'port scan with PowerShell', 'Seatbelt/WinPEAS']},
    'malware_download': {'mitre': ['T1105', 'T1204.002', 'T1197'], 'sources': ['win_proc', 'win_network', 'win_file'],
                         'variants': ['certutil -urlcache', 'bitsadmin', 'PowerShell Invoke-WebRequest to Temp then run', 'curl.exe to Public',
                                      'msiexec /i http', 'esentutl copy from UNC', 'expand/extrac32 from remote']},
    'command_and_control': {'mitre': ['T1071.001', 'T1572', 'T1090', 'T1102', 'T1573'], 'sources': ['win_proc', 'win_network', 'win_dns'],
                            'variants': ['ngrok/chisel/frp tunnel', 'Cobalt Strike named pipe or beacon', 'DNS tunneling (iodine, dnscat2)',
                                         'Telegram/Discord bot C2', 'plink reverse tunnel', 'SSH -R port forward']},
    'exfiltration': {'mitre': ['T1048', 'T1567.002', 'T1041', 'T1560.001'], 'sources': ['win_proc', 'win_dns', 'win_network'],
                     'variants': ['rclone to cloud storage', 'curl upload to transfer.sh/file.io', 'PowerShell Invoke-RestMethod -InFile',
                                  '7z/rar archive with password before upload', 'MEGAcmd']},
    'lateral_movement': {'mitre': ['T1021.001', 'T1021.002', 'T1021.006', 'T1047', 'T1569.002'], 'sources': ['win_proc', 'win_registry'],
                         'variants': ['PsExec/PAExec', 'wmic /node process call create', 'WinRM Enter-PSSession/winrs', 'RDP enabled by registry',
                                      'Impacket smbexec/atexec service', 'schtasks /s remote']},
    'cryptomining': {'mitre': ['T1496'], 'sources': ['win_proc', 'win_dns', 'win_network'],
                     'variants': ['xmrig arguments', 'stratum URL', 'mining pool DNS', 'nicehash/nanominer', 'miner as service']},
    'ransomware_impact': {'mitre': ['T1490', 'T1486', 'T1489', 'T1485'], 'sources': ['win_proc', 'win_file'],
                          'variants': ['vssadmin/wmic shadow delete', 'bcdedit recovery off', 'wbadmin delete', 'stopping backup and SQL services',
                                       'ransom note files', 'cipher /w', 'mass file renaming tools']},
    'collection': {'mitre': ['T1113', 'T1115', 'T1056.001', 'T1560', 'T1005', 'T1114'], 'sources': ['win_proc'],
                   'variants': ['screenshot via PowerShell', 'clipboard dump', 'keylogger tool', 'Outlook PST copy', 'archiving Documents with password']},
    'lolbin_proxy_execution': {'mitre': ['T1218.005', 'T1218.010', 'T1218.011', 'T1218.003', 'T1127.001', 'T1216'],
                               'sources': ['win_proc', 'win_network'],
                               'variants': ['mshta', 'regsvr32 /i', 'rundll32 javascript', 'cmstp /s', 'msbuild inline task', 'installutil /u',
                                            'odbcconf /a', 'pcalua -a', 'forfiles /c', 'SyncAppvPublishingServer']},
    'office_macro_execution': {'mitre': ['T1204.002', 'T1566.001', 'T1137'], 'sources': ['win_proc', 'win_file'],
                               'variants': ['Word/Excel spawning PowerShell', 'Outlook spawning script', 'Office writing exe to Temp',
                                            'OneNote launching hta', 'Excel 4.0 macro rundll32']},
    'script_obfuscation': {'mitre': ['T1027', 'T1059.001', 'T1059.005', 'T1140'], 'sources': ['win_proc'],
                           'variants': ['PowerShell char-join/format obfuscation', 'Invoke-Obfuscation patterns', 'FromBase64String + IEX',
                                        'wscript with encoded jse/vbe', 'cmd caret/variable obfuscation', 'Compression.GzipStream payload']},
    'process_injection': {'mitre': ['T1055', 'T1055.001', 'T1055.012', 'T1055.002'],
                          'sources': ['win_remote_thread', 'win_process_access', 'win_tamper', 'win_image'],
                          'variants': ['CreateRemoteThread from user folder', 'process hollowing', 'PROCESS_ALL_ACCESS to browser',
                                       'unsigned DLL from Temp', 'injection into explorer from Temp']},
    'web_shell': {'mitre': ['T1505.003', 'T1190'], 'sources': ['win_proc', 'win_file'],
                  'variants': ['w3wp.exe spawning cmd/powershell', 'aspx written to inetpub', 'php-cgi spawning shell', 'tomcat java spawning cmd']},
    'remote_access_tool': {'mitre': ['T1219'], 'sources': ['win_proc', 'win_dns', 'win_registry'],
                           'variants': ['AnyDesk silent install with password', 'ScreenConnect/ConnectWise client', 'Atera/Splashtop agent from Temp',
                                        'TeamViewer unattended setup with arguments', 'RustDesk with custom server', 'NetSupport client32']},
    'supply_chain': {'mitre': ['T1195.002', 'T1059.006', 'T1059.007'], 'sources': ['win_proc'],
                     'variants': ['npm install script spawning PowerShell', 'pip install running cmd', 'node -e downloading', 'python -c urllib + exec']},
    # Owner's request 2026-11-25: 30 more types (50 in all). Sahibin isteği: 30 yeni tür.
    'browser_credential_theft': {'mitre': ['T1555.003', 'T1539'], 'sources': ['win_file', 'win_proc'],
                                 'variants': ['infostealer reading Chrome/Edge Login Data, Cookies, Local State',
                                              'Firefox logins.json/key4.db copy', 'DPAPI master key theft']},
    'sam_lsa_secrets_dump': {'mitre': ['T1003.002', 'T1003.004'], 'sources': ['win_proc', 'win_file'],
                             'variants': ['reg save HKLM\\SAM/SECURITY/SYSTEM', 'copy SAM from a shadow copy',
                                          'secretsdump-style hive dump to Temp']},
    'byovd_vulnerable_driver': {'mitre': ['T1068', 'T1014'], 'sources': ['win_proc', 'win_file', 'win_registry'],
                                'variants': ['sc create type= kernel from Temp', 'dropping a known vulnerable .sys',
                                             'Services key with ImagePath to a user folder .sys']},
    'amsi_etw_tampering': {'mitre': ['T1562.001', 'T1562.006'], 'sources': ['win_proc', 'win_registry'],
                           'variants': ['AmsiUtils amsiInitFailed', 'ETW provider disable via registry/logman',
                                        'PowerShell ScriptBlockLogging turned off']},
    'event_log_clearing': {'mitre': ['T1070.001'], 'sources': ['win_proc'],
                           'variants': ['wevtutil cl', 'Clear-EventLog / Remove-EventLog', 'stopping the EventLog service']},
    'account_manipulation': {'mitre': ['T1136.001', 'T1098'], 'sources': ['win_proc', 'win_registry'],
                             'variants': ['net user /add', 'net localgroup administrators /add',
                                          'hidden account via SpecialAccounts\\UserList']},
    'rdp_abuse': {'mitre': ['T1021.001', 'T1563.002'], 'sources': ['win_proc', 'win_registry'],
                  'variants': ['fDenyTSConnections 0', 'tscon session hijack', 'RDP port change in the registry']},
    'initial_access_container': {'mitre': ['T1566.001', 'T1553.005'], 'sources': ['win_proc', 'win_file'],
                                 'variants': ['exe or lnk started from a mounted ISO/IMG/VHD', 'mshta running a downloaded .hta',
                                              'lnk in Downloads starting powershell']},
    'dll_hijack_sideload': {'mitre': ['T1574.001', 'T1574.002', 'T1546.015'], 'sources': ['win_image', 'win_registry'],
                            'variants': ['signed exe loading an unsigned DLL next to it in a user folder',
                                         'COM InprocServer32 hijack in HKCU']},
    'wmi_persistence': {'mitre': ['T1546.003'], 'sources': ['win_proc'],
                        'variants': ['__EventFilter + CommandLineEventConsumer via powershell/wmic',
                                     'mofcomp of a persistence MOF']},
    'input_screen_capture': {'mitre': ['T1056.001', 'T1113'], 'sources': ['win_proc', 'win_file'],
                             'variants': ['GetAsyncKeyState keylogger script', 'screenshot tool writing to Temp',
                                          'CopyFromScreen in powershell']},
    'archive_staging': {'mitre': ['T1560.001'], 'sources': ['win_proc'],
                        'variants': ['7z/rar with password of a user folder', 'Compress-Archive of Documents to Temp']},
    'defender_tampering': {'mitre': ['T1562.001'], 'sources': ['win_proc', 'win_registry'],
                           'variants': ['Set-MpPreference -DisableRealtimeMonitoring', 'Add-MpPreference -ExclusionPath',
                                        'Defender policy keys DisableAntiSpyware']},
    'firewall_tampering': {'mitre': ['T1562.004'], 'sources': ['win_proc'],
                           'variants': ['netsh advfirewall set allprofiles state off', 'netsh firewall add allowedprogram',
                                        'New-NetFirewallRule allowing a Temp program']},
    'recovery_inhibit': {'mitre': ['T1490'], 'sources': ['win_proc'],
                         'variants': ['bcdedit /set recoveryenabled no', 'wbadmin delete catalog', 'reagentc /disable']},
    'powershell_downgrade': {'mitre': ['T1562.010'], 'sources': ['win_proc'],
                             'variants': ['powershell -version 2', 'powershell -v 2 -nop']},
    'indicator_removal_files': {'mitre': ['T1070.004', 'T1070.006'], 'sources': ['win_proc'],
                                'variants': ['sdelete', 'cipher /w', 'timestomp via powershell LastWriteTime']},
    'alternate_data_stream': {'mitre': ['T1564.004'], 'sources': ['win_proc', 'win_file'],
                              'variants': ['type payload > file:stream', 'wscript running file:stream.js',
                                           'Set-Content -Stream']},
    'accessibility_backdoor': {'mitre': ['T1546.008', 'T1546.012'], 'sources': ['win_proc', 'win_registry'],
                               'variants': ['replacing sethc/utilman/osk', 'IFEO Debugger on accessibility tools']},
    'bits_job_persistence': {'mitre': ['T1197'], 'sources': ['win_proc'],
                             'variants': ['bitsadmin /SetNotifyCmdLine', 'Start-BitsTransfer to Temp then run']},
    'remote_service_execution': {'mitre': ['T1569.002', 'T1021.002'], 'sources': ['win_proc'],
                                 'variants': ['PsExec', 'sc \\\\host create', 'wmic /node process call create']},
    'credential_tool_cmdline': {'mitre': ['T1003', 'T1558'], 'sources': ['win_proc'],
                                'variants': ['mimikatz sekurlsa::logonpasswords', 'lsadump::sam', 'Rubeus kerberoast']},
    'tunneling_tools': {'mitre': ['T1572', 'T1090'], 'sources': ['win_proc', 'win_dns'],
                        'variants': ['ngrok', 'chisel', 'frp', 'cloudflared tunnel from a user folder']},
    'tor_anonymizer': {'mitre': ['T1090.003'], 'sources': ['win_proc', 'win_dns'],
                       'variants': ['tor.exe outside Tor Browser', 'obfs4 bridge', '.onion lookups']},
    'messaging_exfil': {'mitre': ['T1567'], 'sources': ['win_proc', 'win_dns'],
                        'variants': ['Discord webhook upload', 'Telegram bot API sendDocument', 'paste site upload']},
    'crypto_wallet_theft': {'mitre': ['T1005'], 'sources': ['win_file', 'win_proc'],
                            'variants': ['copying Exodus/Electrum wallet files', 'MetaMask extension storage read by a foreign process']},
    'browser_extension_install': {'mitre': ['T1176'], 'sources': ['win_registry'],
                                  'variants': ['ExtensionInstallForcelist policy', 'Firefox ExtensionSettings policy']},
    'print_spooler_abuse': {'mitre': ['T1068'], 'sources': ['win_image', 'win_file'],
                            'variants': ['spoolsv loading a DLL from spool\\drivers\\color', 'PrintNightmare style driver add']},
    'script_user_execution': {'mitre': ['T1059.005', 'T1059.007'], 'sources': ['win_proc'],
                              'variants': ['wscript/cscript running .js/.vbs/.wsf from Downloads or Temp']},
    'scheduled_task_hidden': {'mitre': ['T1053.005'], 'sources': ['win_proc', 'win_registry'],
                              'variants': ['schtasks /create /xml from Temp', 'task with the SD value removed']},
}

FIELDS_HELP = (
    'Sources and the Sysmon fields each test event uses: win_proc = Sysmon 1 (Image, CommandLine, ParentImage, '
    'ParentCommandLine); win_image = 7 (Image, ImageLoaded, Signed, SignatureStatus); win_remote_thread = 8 (SourceImage, '
    'TargetImage); win_process_access = 10 (SourceImage, TargetImage, GrantedAccess); win_tamper = 25 (Image, Type); '
    'win_network = 3 (Image, Initiated "true", DestinationIp, DestinationPort, DestinationHostname); win_file = 11 (Image, '
    'TargetFilename); win_registry = 12/13/14 (Image, EventType SetValue|CreateKey|DeleteKey|DeleteValue, TargetObject like '
    'HKLM\\SOFTWARE\\..., Details like "DWORD (0x00000001)" or a string); win_dns = 22 (Image, QueryName, QueryResults). '
    'Matchers in base_match and the field they read: cmd_contains / cmd_not_contains / cmd_regex / cmd_regex_cs / '
    'cmd_not_regex -> CommandLine; exe_contains / exe_regex / exe_not_regex -> Image (SourceImage for 8 and 10); '
    'parent_contains -> ParentCommandLine; parent_exe_regex -> ParentImage; file_path / file_path_not (glob, * matches '
    'anything including backslash) -> TargetFilename or ImageLoaded; target_contains / target_regex -> TargetImage, '
    '"ip:port host" of a connection, QueryName or the registry TargetObject; details_regex -> GrantedAccess, Type, '
    'registry Details, QueryResults, or "signed=true|false;status=..." for image loads; operation -> start (win_proc), '
    'outbound|inbound (win_network), create (win_file), SetValue|CreateKey|DeleteKey|DeleteValue|RenameKey (win_registry). '
    'Use only matchers whose field the source has. cmd_contains is a case-insensitive substring of the command line '
    'with white space runs collapsed; regexes are Python re, case-insensitive except cmd_regex_cs, searched anywhere; '
    'keep them linear: no nested quantifiers, bound repeats like .{0,200}. All keys of base_match must match (AND); '
    'the values of one key are alternatives (OR); *_not keys must match none. Windows paths use backslashes; in a '
    'regex a literal backslash is \\\\. ')


class AiError(Exception):
    pass


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def is_ai(rule_id):
    return str(rule_id or '').startswith(AI_PREFIX)


# -- regex safety (the Linux probe, Windows-ready) ------------------------------------------
_linear_cache = {}


def probe_command():
    """The child that runs the Linux regex probe: the exe itself when frozen (--regex-probe)."""
    if getattr(sys, 'frozen', False):
        return [sys.executable, '--regex-probe']
    from satsuma.ai_guard import _PROBE
    return [sys.executable, '-I', '-S', '-c', _PROBE]


def regex_probe_main(stdin=None, stdout=None):
    """--regex-probe: the Linux probe (satsuma.ai_guard._PROBE) inside the frozen exe."""
    from satsuma.ai_guard import _PROBE
    stdin, stdout = stdin or sys.stdin, stdout or sys.stdout
    spec = json.loads(stdin.read())
    compiled = re.compile(spec['pattern'], spec['flags'])
    for unit in spec['units']:
        for size in (256, 4096, spec['size']):
            body = (unit * (size // len(unit) + 1))[:size]
            for text in (body, body + '!', body + '\n!'):
                started = time.thread_time()
                compiled.search(text)
                if time.thread_time() - started > spec['limit']:
                    stdout.write('0\n')
                    return 0
    assert _PROBE  # the same probe the Linux product runs; aynı Linux denemesi
    stdout.write('1\n')
    return 0


def linear(pattern, flags=re.IGNORECASE, runner=None):
    """True when the pattern runs in bounded time on long input (child process, hard timeout).

    The Linux probe on the longest text the Windows engine ever matches (MAX_TEXT, 8192).
    Linux denemesi, Windows motorunun eşlediği en uzun metinle (8192) yapılır.
    """
    from satsuma.ai_guard import LINEAR_SECONDS, _own_words
    key = (pattern, flags)
    if key in _linear_cache:
        return _linear_cache[key]
    try:
        re.compile(pattern, flags)
    except re.error:
        return False
    spec = json.dumps({'pattern': pattern, 'flags': flags, 'units': _own_words(pattern)[:60],
                       'size': MAX_TEXT, 'limit': LINEAR_SECONDS})
    run = runner or subprocess.run
    try:
        timeout = FROZEN_LINEAR_TIMEOUT if getattr(sys, 'frozen', False) else LINEAR_TIMEOUT
        done = run(probe_command(), input=spec, capture_output=True, text=True, timeout=timeout,
                   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        verdict = done.returncode == 0 and done.stdout.strip() == '1'
    except (subprocess.TimeoutExpired, OSError):
        verdict = False
    if len(_linear_cache) > 4096:
        _linear_cache.clear()
    _linear_cache[key] = verdict
    return verdict


# -- the checks --------------------------------------------------------------------------------
def _test_events(package):
    cases = package.get('test_cases')
    if not isinstance(cases, dict):
        raise AiError('test_cases_missing')
    out = {}
    for kind in ('positive', 'negative'):
        events = cases.get(kind)
        if not isinstance(events, list) or not 2 <= len(events) <= MAX_TEST_EVENTS:
            raise AiError('test_cases_%s_need_2_to_%d' % (kind, MAX_TEST_EVENTS))
        rows = []
        for event in events:
            if not isinstance(event, dict) or type(event.get('id')) is not int or event['id'] not in SOURCES:
                raise AiError('test_event_needs_a_sysmon_id')
            if any(not isinstance(k, str) or not isinstance(v, (str, int)) for k, v in event.items()):
                raise AiError('test_event_fields_must_be_text')
            rows.append({k: (v if k == 'id' else str(v)) for k, v in event.items()})
        out[kind] = rows
    return out


def check(package, existing=(), linear_check=linear):
    """Every local check of one DeepSeek package; returns (errors, compiled detection or None)."""
    errors = []
    try:
        if len(canonical(package)) > MAX_PACKAGE_BYTES:
            return ['package_too_large'], None
    except (TypeError, ValueError):
        return ['invalid_json_data'], None
    if not isinstance(package, dict) or not isinstance(package.get('detection'), dict):
        return ['detection_missing'], None
    rule = package['detection']
    rule_id = str(rule.get('id') or '')
    if not ID_PATTERN.match(rule_id):
        errors.append('rule_id_must_be_SATSUMA-AI-WIN-...')
    existing = list(existing)
    if rule_id in {r.get('id') for r in existing}:
        errors.append('rule_id_taken')
    if any((r.get('base_match') or {}) == (rule.get('base_match') or {}) for r in existing):
        errors.append('same_base_match_as_an_existing_rule')
    actions = rule.get('actions')
    if not isinstance(actions, list) or not actions or any(a not in SAFE_ACTIONS for a in actions):
        errors.append('actions_must_be_record_evidence_correlation_request')
    if rule.get('classification') not in STOPPING:
        errors.append('classification_must_stop_suspicious_or_likely')
    for key in ('scoring', 'threshold', 'base_score'):
        if key in rule:
            errors.append('no_' + key)
    try:
        compiled = compile_rule(rule)
    except (RuleError, TypeError, AttributeError, KeyError) as exc:
        return errors + ['engine: ' + str(exc)[:200]], None
    match = rule['base_match']
    for key in REGEX_KEYS:
        if key not in match:
            continue
        patterns = match[key] if isinstance(match[key], list) else [match[key]]
        if len(patterns) > MAX_PATTERNS:
            errors.append('too_many_patterns:' + key)
        for pattern in patterns[:MAX_PATTERNS]:
            text = str(pattern)
            if len(text) > MAX_PATTERN_LENGTH:
                errors.append('pattern_too_long:' + key)
            elif not linear_check(text, 0 if key == 'cmd_regex_cs' else re.IGNORECASE):
                errors.append('regex_not_linear:%s:%s' % (key, text[:60]))
    if errors:
        return errors, None
    try:
        cases = _test_events(package)
    except AiError as exc:
        return [str(exc)], None
    for kind, events in cases.items():
        for index, event in enumerate(events):
            row = view(event)
            hit = row is not None and matches(compiled, row)
            if hit != (kind == 'positive'):
                errors.append('test_%s_%d_%s' % (kind, index, 'missed' if kind == 'positive' else 'matched'))
    for event in corpus.satsuma_events():
        if matches(compiled, view(event)):
            errors.append('matches_satsuma_own_command:' + event['CommandLine'][:60])
            break
    everyday = [e for e in corpus.everyday_events() if matches(compiled, view(e))]
    if everyday:
        sample = everyday[0]
        errors.append('matches_everyday_event:%s' % (sample.get('CommandLine') or sample.get('QueryName')
                                                    or sample.get('TargetObject') or sample.get('Image'))[:80])
    return errors[:30], (None if errors else compiled)


# -- DeepSeek ----------------------------------------------------------------------------------
def prompt(attack_type, existing=(), feedback=None):
    spec = ATTACK_TYPES[attack_type]
    text = ('Write ONE new Satsuma detection rule for WINDOWS (Sysmon telemetry) for the attack type '
            f'"{attack_type}" (MITRE {", ".join(spec["mitre"])}). Known variants: {"; ".join(spec["variants"])}. '
            f'Prefer the sources {", ".join(spec["sources"])}. One rule covers ONE variant, precisely enough that '
            'ordinary Windows use, browsers, installers, Windows Update, Defender and developer tools never match. '
            'Return JSON: {"rule_id": same as detection.id, "attack_type": "' + attack_type + '", "detection": RULE, '
            '"test_cases": {"positive": [2..6 Sysmon events the rule must match], "negative": [2..6 look-alike '
            'benign Sysmon events it must not match]}, "response_proposal": {"requested_action": "process_kill"}}. '
            'RULE is a mapping with exactly: id ("SATSUMA-AI-WIN-" + short upper-case words and digits joined by -), '
            'name (Turkish, short), severity (medium|high|critical), classification (suspicious or likely), '
            'confidence (low|medium|high), mitre {tactic, technique}, base_match, actions [record, evidence, '
            'correlation_request], schema_version 1, implementation_status CURRENT_TELEMETRY, requires '
            '["sysmon.<event id>"], proof_level PUBLIC_RESEARCH or IN_THE_WILD_CONFIRMED, false_positives [Turkish '
            'text]. No scoring, threshold or base_score. Each test event is an object with "id" (the Sysmon event id, '
            'a number) and Sysmon field names with string values; synthetic data only, never real host data. '
            + FIELDS_HELP)
    if existing:
        lines = ['* %s %s' % (r.get('id'), json.dumps(r.get('base_match'), ensure_ascii=False)[:260])
                 for r in list(existing)[:40]]
        text += ('These rules already exist; write a variant none of them catches and use a new id:\n'
                 + '\n'.join(lines) + '\n')
    if feedback:
        text += ('Your previous reply was refused by Satsuma\'s local checks; correct it: '
                 + '; '.join(str(f)[:120] for f in feedback[:10]) + '\n')
    return text


def ask(api_key, text, temperature=0.4, http=None):
    """One request through the Linux DeepSeek client; returns the JSON object the model wrote."""
    from satsuma.deepseek_client import DEFAULT_ENDPOINT, DEFAULT_MODEL, DeepSeekError, _http_post
    if len(text.encode()) > 32768:
        raise AiError('prompt_too_large')
    payload = {'model': DEFAULT_MODEL, 'messages': [
        {'role': 'system', 'content': 'Return only JSON data. Never execute commands or request secrets.'},
        {'role': 'user', 'content': text}], 'temperature': temperature, 'max_tokens': 2048,
        'response_format': {'type': 'json_object'}}
    try:
        response = (http or _http_post)(DEFAULT_ENDPOINT, payload, api_key, 45)
    except DeepSeekError as exc:
        raise AiError(str(exc)) from None
    try:
        content = response['choices'][0]['message']['content']
        if not isinstance(content, str) or api_key in content:
            raise AiError('unsafe_or_unexpected_response')
        result = json.loads(content)
    except (KeyError, IndexError, TypeError, ValueError):
        raise AiError('unexpected_response') from None
    if not isinstance(result, dict):
        raise AiError('unexpected_response')
    return result


# -- the store and the service side --------------------------------------------------------------
def deepseek_dir(state_dir):
    return Path(state_dir) / 'deepseek'


def duplicate_of(package, existing):
    """The id of an existing rule (bundled or DeepSeek) that already catches every attack event of the new one
    (owner's approval 2026-11-25: twins are refused). Yeni kuralın bütün saldırı olaylarını yakalayan mevcut kural."""
    detection = package.get('detection') or {}
    source = (detection.get('base_match') or {}).get('source')
    rows = [view(dict(e, record=0)) for e in ((package.get('test_cases') or {}).get('positive') or []) if isinstance(e, dict)]
    rows = [r for r in rows if r is not None]
    if not rows:
        return None
    for other in existing:
        if not isinstance(other, dict) or (other.get('base_match') or {}).get('source') != source \
                or other.get('id') == detection.get('id'):
            continue
        try:
            compiled = compile_rule(other)
        except (RuleError, ValueError, KeyError, TypeError):
            continue
        if all(matches(compiled, r) for r in rows):
            return str(other.get('id'))
    return None


def write_request(state_dir, kind, password=None, **fields):
    """Administrator command line -> service. Only SYSTEM and Administrators can write this folder.
    Signed with the Satsuma administrator password (satsuma_win.owner_password) since 2026-11-25."""
    body = {'type': kind, **fields}
    if password is not None:
        from . import owner_password
        body = owner_password.sign(state_dir, password, body)
    folder = deepseek_dir(state_dir) / 'requests'
    folder.mkdir(parents=True, exist_ok=True)
    name = '%d-%s.json' % (time.time_ns(), secrets.token_hex(4))
    temporary = folder / (name + '.tmp')
    temporary.write_text(json.dumps(body), encoding='utf-8')
    os.replace(temporary, folder / name)
    return name


def _dpapi_protect(data):
    import win32crypt
    return win32crypt.CryptProtectData(data, 'Satsuma DeepSeek key', None, None, None, 0x1)


def _dpapi_unprotect(data):
    import win32crypt
    return win32crypt.CryptUnprotectData(data, None, None, None, 0x1)[1]


class AiRules:
    """The service side: requests, the DeepSeek key, automatic fetching, signed activation, stop limits."""

    def __init__(self, state_dir, key, record, clock=time.time, monotonic=time.monotonic, http=None,
                 protect=_dpapi_protect, unprotect=_dpapi_unprotect, threads=True, linear_check=linear,
                 existing=lambda: (), live=None):
        self.dir = deepseek_dir(state_dir)
        self.key, self.record, self.clock, self.monotonic = key, record, clock, monotonic
        self.http, self.protect, self.unprotect = http, protect, unprotect
        self.threads, self.linear_check, self.existing = threads, linear_check, existing
        self.live = live or live_process
        self.worker, self.result, self.next_at = None, None, 0.0
        self.stops, self.tripped, self.load_errors = {}, {}, []
        self.state = self._load_state()

    # files
    def _path(self, *parts):
        return self.dir.joinpath(*parts)

    def _load_state(self):
        try:
            state = json.loads(self._path('state.json').read_text(encoding='utf-8'))
            if isinstance(state, dict):
                return state
        except (OSError, ValueError):
            pass
        return {'types': {}, 'day': None, 'requests_today': 0, 'wait_until': 0, 'last_error': None}

    def _save_state(self):
        try:
            self.dir.mkdir(parents=True, exist_ok=True)
            temporary = self._path('state.json.tmp')
            temporary.write_text(json.dumps(self.state, ensure_ascii=False, sort_keys=True), encoding='utf-8')
            os.replace(temporary, self._path('state.json'))
        except OSError:
            pass

    def api_key(self):
        try:
            raw = self.unprotect(self._path('key.dpapi').read_bytes())
            key = raw.decode('ascii').strip()
        except (OSError, ValueError, UnicodeError):
            return None
        except Exception:  # DPAPI of another account: unusable, the owner gives it again
            return None
        return key if 16 <= len(key) <= 4096 and all(33 <= ord(c) <= 126 for c in key) else None

    # owner overrides, signed by the machine key
    def overrides(self):
        try:
            data = json.loads(self._path('overrides.json').read_text(encoding='utf-8'))
            rows = data['rows']
            if self.key is not None and isinstance(rows, dict) and self.key.verify(canonical(rows), data['signature']):
                return {k: v for k, v in rows.items() if v in ('report', 'disabled')}
        except (OSError, ValueError, KeyError, TypeError):
            pass
        return {}

    def set_override(self, rule_id, mode):
        """report / disabled / enabled for one DeepSeek rule, signed by the machine key."""
        rows = self.overrides()
        if mode == 'enabled':
            rows.pop(rule_id, None)
        else:
            rows[rule_id] = mode
        self._save_overrides(rows)

    def _save_overrides(self, rows):
        self.dir.mkdir(parents=True, exist_ok=True)
        temporary = self._path('overrides.json.tmp')
        temporary.write_text(json.dumps({'rows': rows, 'signature': self.key.sign(canonical(rows))}), encoding='utf-8')
        os.replace(temporary, self._path('overrides.json'))

    # active rules
    def _active_files(self):
        folder = self._path('active')
        return sorted(folder.glob('*.json')) if folder.is_dir() else []

    def _read_active(self, path):
        envelope = json.loads(path.read_text(encoding='utf-8'))
        body = {'package': envelope['package'], 'approval': envelope['approval']}
        if self.key is None or not self.key.verify(canonical(body), envelope['signature']):
            raise AiError('signature_does_not_verify')
        if envelope['approval'].get('package_sha256') != digest(envelope['package']):
            raise AiError('package_digest_mismatch')
        return envelope

    def active_rules(self):
        """(file name, detection) for every signed, not disabled DeepSeek rule; others are reported."""
        rows, errors, disabled = [], [], self.overrides()
        for path in self._active_files():
            try:
                envelope = self._read_active(path)
            except (OSError, ValueError, KeyError, TypeError, AiError) as exc:
                errors.append({'file': path.name, 'error': str(exc)[:200]})
                continue
            detection = envelope['package']['detection']
            if disabled.get(detection.get('id')) == 'disabled':
                continue
            # Owner's approval 2026-11-25: a rule already active that matches an everyday event (Satsuma's or
            # Defender's own access among them) is turned off, never deleted. Gündelik olaya uyan kural kapatılır.
            everyday = self._everyday_match(detection)
            if everyday and self.key is not None:
                self.set_override(str(detection.get('id')), 'disabled')
                self.record('deepseek_rule_disabled_by_check', rule_id=detection.get('id'), matched=everyday[:120])
                continue
            rows.append((path.name, detection))
        self.load_errors = errors
        return rows

    def _everyday_match(self, detection):
        try:
            compiled = compile_rule(detection)
        except (RuleError, ValueError, KeyError, TypeError):
            return None
        for event in corpus.everyday_events():
            row = view(event)
            if row is not None and matches(compiled, row):
                return str(event.get('CommandLine') or event.get('QueryName') or event.get('TargetObject')
                           or (str(event.get('SourceImage')) + ' -> ' + str(event.get('TargetImage'))) or event.get('Image'))
        return None

    def counts_by_type(self):
        counts = {kind: 0 for kind in ATTACK_TYPES}
        for path in self._active_files():
            try:
                kind = self._read_active(path)['package'].get('attack_type')
            except (OSError, ValueError, KeyError, TypeError, AiError):
                continue
            if kind in counts:
                counts[kind] += 1
        return counts

    def activate(self, package, compiled):
        """Sign with the machine key and put the rule live. İmzalar ve devreye alır."""
        approval = {'origin': 'automatic', 'validated_at': self.clock(), 'package_sha256': digest(package),
                    'checks': ['shared_schema', 'windows_engine', 'linear_regex', 'model_test_events',
                               'satsuma_commands', 'everyday_events']}
        body = {'package': package, 'approval': approval}
        folder = self._path('active')
        folder.mkdir(parents=True, exist_ok=True)
        name = package['detection']['id'] + '.json'
        temporary = folder / (name + '.tmp')
        temporary.write_text(json.dumps({**body, 'signature': self.key.sign(canonical(body))}, ensure_ascii=False),
                             encoding='utf-8')
        os.replace(temporary, folder / name)
        return name

    def remove(self, rule_id):
        path = self._path('active', str(rule_id) + '.json')
        if ID_PATTERN.match(str(rule_id)) and path.exists():
            path.unlink()
            return True
        return False

    # requests from the administrator command line
    def process_requests(self):
        folder, changed = self._path('requests'), False
        for path in sorted(folder.glob('*.json')) if folder.is_dir() else []:
            try:
                request = json.loads(path.read_text(encoding='utf-8'))
            except (OSError, ValueError):
                request = {'type': 'unreadable'}
            try:
                path.unlink()
            except OSError:
                pass
            kind = request.get('type')
            gate = getattr(self, 'gate', None)
            problem = gate.check(request, 'deepseek_' + str(kind)) if gate is not None else None
            if problem:
                self.record('deepseek_request_refused', ok=False, type=kind, reason='parola: ' + problem)
                continue
            if kind == 'set_key':
                key = str(request.get('key') or '').strip()
                if not (16 <= len(key) <= 4096 and all(33 <= ord(c) <= 126 for c in key)):
                    self.record('deepseek_key', ok=False, status='INVALID_KEY')
                    continue
                self.dir.mkdir(parents=True, exist_ok=True)
                temporary = self._path('key.dpapi.tmp')
                temporary.write_bytes(self.protect(key.encode('ascii')))
                os.replace(temporary, self._path('key.dpapi'))
                self.state.update(wait_until=0, last_error=None)
                self.next_at = 0.0
                self.record('deepseek_key', ok=True, status='SAVED')
            elif kind == 'clear_key':
                try:
                    self._path('key.dpapi').unlink()
                except OSError:
                    pass
                self.record('deepseek_key', ok=True, status='REMOVED')
            elif kind == 'fetch_now':
                self.state['wait_until'], self.next_at = 0, 0.0
                for row in self.state['types'].values():
                    row['wait_until'] = 0
                self.record('deepseek_fetch_now', ok=True)
            elif kind == 'override' and request.get('mode') in ('report', 'disabled', 'enabled') and self.key is not None:
                rule_id = str(request.get('rule_id'))
                self.set_override(rule_id, request['mode'])
                changed = True
                self.record('deepseek_rule_override', rule_id=rule_id, mode=request['mode'])
            elif kind == 'remove':
                done = self.remove(request.get('rule_id'))
                changed = changed or done
                self.record('deepseek_rule_removed', rule_id=str(request.get('rule_id')), ok=done)
            else:
                self.record('deepseek_request_refused', type=str(kind)[:40])
        self._save_state()
        return changed

    # automatic fetching
    def _next_type(self, counts, now):
        ready = [k for k in ATTACK_TYPES if now >= (self.state['types'].get(k) or {}).get('wait_until', 0)]
        candidates = [(counts[k], k) for k in ready if counts[k] < TARGET_PER_TYPE]
        if not candidates:
            day = time.strftime('%Y-%m-%d', time.gmtime(now))

            def today(k):
                row = self.state['types'].get(k) or {}
                return row.get('today', 0) if row.get('day') == day else 0
            candidates = [(counts[k], k) for k in ready if counts[k] < MAX_PER_TYPE and today(k) < AFTER_TARGET_PER_DAY]
        return min(candidates)[1] if candidates else None

    def _fetch(self, api_key, attack_type, existing, feedback):
        try:
            package = ask(api_key, prompt(attack_type, existing, feedback), 0.7 if feedback else 0.4, self.http)
            package['attack_type'] = attack_type
            errors, compiled = check(package, existing, self.linear_check)
            if not errors:
                twin = duplicate_of(package, existing)
                if twin:
                    errors, compiled = ['duplicate_of:' + twin], None
            return {'type': attack_type, 'package': package, 'errors': errors, 'compiled': compiled}
        except AiError as exc:
            return {'type': attack_type, 'error': str(exc)}
        except Exception as exc:  # the service keeps running; the type waits
            return {'type': attack_type, 'error': type(exc).__name__ + ': ' + str(exc)[:200]}

    def _finish(self, result):
        """Handle one finished request in the service thread. True when a rule went live."""
        now, kind = self.clock(), result['type']
        row = self.state['types'].setdefault(kind, {'refusals': 0, 'wait_until': 0, 'feedback': []})
        if 'error' in result:
            error = result['error']
            wait = QUOTA_WAIT if error == 'quota_exceeded' else ERROR_WAIT
            if error == 'authentication_failed':
                wait = 10 ** 9            # until the owner gives a new key; yeni anahtara kadar
            self.state.update(wait_until=now + wait, last_error=error)
            self.record('deepseek_request_failed', attack_type=kind, error=error[:200])
            return False
        package, errors = result['package'], result['errors']
        rule_id = str((package.get('detection') or {}).get('id') or '')[:80]
        if errors:
            row['refusals'] = row.get('refusals', 0) + 1
            row['feedback'] = errors[:10]
            if row['refusals'] >= REFUSALS_BEFORE_WAIT:
                row.update(refusals=0, wait_until=now + REFUSAL_WAIT)
            self.record('deepseek_rule_refused', attack_type=kind, rule_id=rule_id, reasons=errors[:10])
            try:
                self.dir.mkdir(parents=True, exist_ok=True)
                with open(self._path('refused.jsonl'), 'a', encoding='utf-8') as stream:
                    stream.write(json.dumps({'time': now, 'attack_type': kind, 'reasons': errors[:10],
                                             'package_sha256': digest(package)}, ensure_ascii=False) + '\n')
            except (OSError, TypeError, ValueError):
                pass
            return False
        if self.key is None:
            return False
        name = self.activate(package, result['compiled'])
        row.update(refusals=0, feedback=[])
        self.state['last_error'] = None
        self.record('deepseek_rule_activated', attack_type=kind, rule_id=rule_id, file=name,
                    rule=package['detection'].get('name'), base_match=package['detection'].get('base_match'))
        return True

    def tick(self):
        """Once per poll: requests, a finished fetch, the next fetch. True when the rules changed."""
        changed = self.process_requests()
        if self.worker is not None and not self.worker.is_alive():
            self.worker = None
        if self.result is not None:
            result, self.result = self.result, None
            changed = self._finish(result) or changed
            self._save_state()
        if self.worker is not None or self.key is None:
            return changed
        now, mono = self.clock(), self.monotonic()
        if mono < self.next_at or now < self.state.get('wait_until', 0):
            return changed
        day = time.strftime('%Y-%m-%d', time.gmtime(now))
        if self.state.get('day') != day:
            self.state.update(day=day, requests_today=0)
        if self.state['requests_today'] >= DAILY_LIMIT:
            return changed
        api_key = self.api_key()
        if api_key is None:
            return changed
        counts = self.counts_by_type()
        kind = self._next_type(counts, now)
        if kind is None:
            return changed
        self.next_at = mono + AUTO_EVERY
        self.state['requests_today'] += 1
        row = self.state['types'].setdefault(kind, {})
        if row.get('day') != day:
            row.update(day=day, today=0)
        row['today'] = row.get('today', 0) + 1
        self._save_state()
        existing = list(self.existing()) + [d for _, d in self.active_rules()]
        feedback = (self.state['types'].get(kind) or {}).get('feedback')

        def work():
            self.result = self._fetch(api_key, kind, existing, feedback)
        if self.threads:
            self.worker = threading.Thread(target=work, name='satsuma-deepseek', daemon=True)
            self.worker.start()
        else:
            work()
            changed = self.tick() or changed
        return changed

    # stops
    def stop_block(self, finding, compiled=None):
        """Why this DeepSeek finding may not stop its process, or None. Neden durduramaz ya da None."""
        rule_id = str(finding.get('rule_id') or '')
        if not is_ai(rule_id):
            return None
        mode = self.overrides().get(rule_id)
        if mode:
            return 'ai_rule_owner_' + mode
        image = str(finding.get('image') or '')
        name = image.replace('/', '\\').rsplit('\\', 1)[-1].lower()
        if (name in PROTECTED_NAMES and WINDOWS_FOLDERS.match(image)) or PROTECTED_FOLDERS.match(image):
            return 'ai_rule_protected_target'
        now = self.monotonic()
        tripped = self.tripped.get(rule_id)
        if tripped is not None and now - tripped < STOP_COOLDOWN:
            return 'ai_rule_stop_limit'
        history = [t for t in self.stops.get(rule_id, []) if now - t < STOP_WINDOW]
        self.stops[rule_id] = history
        if len(history) >= STOP_LIMIT:
            # A rule that stops this much is more likely wrong (or planted) than an attack this large.
            self.tripped[rule_id] = now
            self.record('deepseek_rule_stop_limit', rule_id=rule_id, stops=len(history))
            return 'ai_rule_stop_limit'
        if finding.get('source') == 'win_proc' and compiled is not None:
            live = self.live(finding.get('pid'))
            if live is None or live.get('Image', '').lower() != image.lower():
                return 'ai_rule_process_changed'
            event = {'id': 1, 'record': finding.get('record'), 'ProcessId': str(finding.get('pid')), **live}
            if not matches(compiled, view(event)):
                return 'ai_rule_live_command_does_not_match'
        return None

    def count_stop(self, finding):
        if is_ai(finding.get('rule_id')):
            self.stops.setdefault(str(finding['rule_id']), []).append(self.monotonic())

    def status(self):
        counts = self.counts_by_type()
        return {'key': self.api_key() is not None, 'active': sum(counts.values()), 'by_type': counts,
                'target_per_type': TARGET_PER_TYPE, 'requests_today': self.state.get('requests_today', 0),
                'last_error': self.state.get('last_error'), 'load_errors': self.load_errors[:10],
                'overrides': self.overrides()}


def live_process(pid):
    """The live image and command line of ``pid`` (psutil); None when it is gone."""
    try:
        import psutil
        process = psutil.Process(int(pid))
        return {'Image': process.exe(), 'CommandLine': ' '.join(process.cmdline())}
    except Exception:  # gone or unreadable: no stop on a guess
        return None
