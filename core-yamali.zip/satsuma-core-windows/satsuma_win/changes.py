"""What each build changes in Satsuma's behaviour, shown on the install screen (owner's rule 2026-11-24).

The install screen compared only rules, device policy and exe digests, so a change in behaviour showed
as "exe değişiyor" and the owner could not see what he was approving. Every behaviour change is now
one numbered entry here; the manifest keeps the numbers that were installed, and an update lists
every entry since then, however many builds were skipped. Entries are never renumbered or removed.
Her davranış değişikliği burada numaralı bir maddedir; güncelleme, kurulu sürümden bu yana gelen
bütün maddeleri listeler. Maddeler yeniden numaralanmaz, silinmez.
"""

CHANGES = (
    (1, 'Tek yetkili hesap ilk kurulumda elle yazılır; güncellemede sahip hesabı değişir ya da bozulursa '
        'kurulum önceki sürüme geri döner ve kritik kayıt açılır.'),
    (2, 'Güncelleme önceki kurulumla karşılaştırılır, farklar listelenir; "onaylıyorum" yazılmadan kurulmaz.'),
    (3, "Sahip dışındaki bütün yerel hesaplar kapalı tutulur; biri açılırsa yeniden kapatılır ve kritik kayıt düşer."),
    (4, "Sysmon: Satsuma'nın başka süreçlere erişimi okuma ve durdurma ile sınırlı; fazlası kritik kayıt açar."),
    (5, "Satsuma kendi exe'lerini 5 dakikada bir imzalı özetlerle denetler; değişiklik kritik kayıt açar."),
    (6, 'WAN Miniport aygıtlarından yalnız IP (IPv4) açık; IPv6, Network Monitor, PPPoE, IKEv2, L2TP, PPTP, '
        'SSTP ve GRE kapalı.'),
    (7, 'CDN ve paylaşılan ağ muafiyeti yok: OTX ile işaretlenen adres hangi ağda olursa olsun engellenir.'),
    (8, 'Satsuma her açılışta "onaylıyorum" yazılarak mı kurulduğunu imzalı kayıtla denetler; onaysız '
        'kurulum, kurulum aracı atlanması ya da değişmiş exe kritik kayıt açar.'),
    (9, 'Kapatılan ya da Allow\'a çevrilen Satsuma engel kuralı dakikada bir bulunur, geri açılır ve kritik '
        'kayıt düşer; engeli yalnız sahip (--unblock) kaldırır.'),
    (10, "Satsuma kendi başlattığı araçların (arp, powershell…) tam erişim kaydını hizmet yöneticisi ve "
         "başlattıkları listesiyle doğrular; doğrulanamayan erişim kritik kalır."),
    (11, 'Yeniden başlatmada önceki Satsuma örneğinin başlattığı araçlar ve exe paket açıcısının Satsuma\'yı '
         'başlatması da doğrulanır (imzalı olmayan ama yalnız SYSTEM ve yöneticilerin yazabildiği listeyle).'),
    (12, 'Onay ekranı, kurulu sürümden bu yana gelen bütün davranış değişikliklerini numaralı listeler.'),
    (13, 'BIOS sürümü/tarihi, anakart, Güvenli Önyükleme, TPM üreticisi ve firmware sürümü ile PCR0/PCR7 '
         'ölçümleri kurulumda imzalanır; her açılışta ve saatte bir karşılaştırılır, fark kritik kayıt açar. '
         'Taban çizgisini yalnız sahip --approve-firmware ve "onaylıyorum" ile yeniler.'),
    (14, "#10 ve #11'in yerine: Satsuma'nın kendi başlattığı süreçler PID ile değil; Sysmon süreç kimliği "
         "(GUID), onaylı exe özeti, diskteki dosyanın özeti, hizmet yöneticisi ve Windows'un kendi 4688 "
         "kaydıyla birlikte doğrulanır. Satsuma bunun için Windows'un süreç oluşturma denetimini açık tutar. "
         "Paneli de kapsar; biri tutmazsa kritik kayıt kalır."),
    (15, "Satsuma'nın kendi PowerShell'i ve paneli için bellek kaydı, dosyasız bellekten iş parçacığı yoksa "
         "saatte bir özet olur; iş parçacığı varsa hemen kritik kayıt açılır."),
    (16, 'Engelleme, durdurma, kritik ve yüksek önemli kayıtlar ayrıca important.jsonl\'de tutulur; '
         'panel bunları her zaman gösterir.'),
    (17, 'Aygıtlar sayfası kayıtlardan değil, hizmetin her denetimde yazdığı güncel listeden (devices-now.json) '
         'gelir: politikayla şu an kapalı her aygıt ve ne zamandan beri kapalı olduğu görünür.'),
    (18, "Sysmon indirmesi başarısız olsa da yeni yapılandırma, bilgisayardaki Microsoft imzalı Sysmon ile "
         "yüklenir; kurulum çıktısı yapılandırmanın özetini ve Sysmon'un indirildiğini mi yoksa var olanın mı "
         "kullanıldığını yazar."),
    (19, 'Bir kez: events.jsonl\'deki eski engelleme, durdurma ve kritik kayıtların hepsi important.jsonl\'e '
         'aktarılır; panel dünden bu yana olan önemli olayları da gösterir.'),
    (20, 'Satsuma yönetici parolası (Linux tasarımı): engel kaldırma, klasör/aygıt/firmware onayı ve bütün '
         'DeepSeek komutları parolayla imzalı gelmezse hizmet uygulamaz ve kritik kayıt açar; 5 yanlış parola '
         '5 dakika kilit. Parola ilk kurulumda (ya da hiç yoksa bu güncellemede) belirlenir, --set-password ile '
         'değiştirilir; parolanın kendisi hiçbir yerde saklanmaz.'),
    (21, 'Satsuma durdurma kaydı olmadan sonlanırsa (Görev Yöneticisi, çökme) bir sonraki açılışta kritik '
         '"satsuma_ended_without_stop" kaydı açılır; bilgisayar kapanıp açıldıysa yalnızca bilgi kaydı düşer.'),
    (22, "LSASS'a her erişim (Mimikatz tipi 0x1010/0x1410 dahil) Sysmon'a kaydedilir ve WIN-060'a ulaşır; Satsuma ve "
         "Sysmon muafiyetleri yalnız tam yolla tanımlıdır, hiçbiri LSASS hedefini kapsamaz."),
    (23, "Kullanıcı klasörleri ve ProgramData'dan yüklenen imzasız DLL'ler kaydedilir (WIN-030, yalnız kayıt)."),
    (24, "Kurulum yarım kalırsa (bazı exe'ler kopyalanamadıysa) tek bir kritik 'Kurulum yarım kaldı' kaydı düşer; "
         "aynı bütünlük durumu beş dakikada bir tekrar kaydedilmez."),
    (25, "Windows'ta yalnız uygulanan bellek kuralları yüklenir (RAM-001/004/008/009); Linux'a özgü 002/003/005 yüklenmez."),
    (26, "Eski Suricata klasörleri çalışan motor başladıktan sonra silinir; kilitli olan sonraki açılışta silinir."),
    (27, "Aygıtlar sayfası, kapatılmış ama şu an takılı olmayan aygıtları da gösterir; panelin Linux teması exe'ye gömülüdür."),
    (28, "Panelde durdurulan her kural bulgusu için 'İzin ver' (yalnız o program dosyası, yalnız o kural; dosya "
         "değişirse izin düşer) ve 'Kuralı durdur' (DeepSeek kuralı silinmeden kapanır); ikisi de yönetici parolası ister."),
    (29, "DeepSeek kuralları Satsuma'nın ve Defender'ın gerçek erişimleriyle sınanır; devredekilerden uyan kapatılır. "
         "Mevcut bir kuralın ikizi reddedilir."),
    (30, "DeepSeek 50 saldırı türü tanır; tür başına en az 10, en çok 50 kural; 10'dan sonra türe günde en çok 5 istek."),
    (31, "Hizmet durdurulurken yarıda kalan PowerShell adımları hata olarak kaydedilmez."),
    (32, "PTR kuralı (sahibin C seçimi): PTR'siz uca yoğun bağlantı, bağlantıyı açan programlardan biri imzasız, "
         "yazılabilir klasörden ya da tanınmıyorsa eskisi gibi engellenir; hepsi Windows/Program Files/Defender "
         "klasöründen imzalı programsa yalnız kaydedilir. OTX, ortak CDN önyüzlerini ve Defender/Windows Update "
         "bağlantılarını engellemez, kaydeder."),
)


def ids():
    return [number for number, _ in CHANGES]


def since(installed):
    """Lines for every change the installed build lacks. Kurulu sürümde olmayan değişiklikler."""
    if installed is None:
        return (['Önceki kurulumda değişiklik listesi yok; bu sürümün getirdiği davranışlar:']
                + [f'  #{n} {text}' for n, text in CHANGES])
    have = set(installed)
    return [f'Yeni davranış #{n}: {text}' for n, text in CHANGES if n not in have]
