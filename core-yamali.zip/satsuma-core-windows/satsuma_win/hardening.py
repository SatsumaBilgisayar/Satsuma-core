"""Windows hardening: closes the man-in-the-middle paths and tightens .NET and PowerShell (owner's decision 2026-11-24).

Each setting is written, checked every minute and written back when something changed it;
before the first write the values found are saved (hardening-backup.json) and --uninstall
puts them back. Every write is recorded.

Man in the middle (the Windows counterparts of Linux ipv6_off, mitm_watch and dns_encrypted):

* IPv6 off, three layers as on Linux: DisabledComponents=0xFF (after a restart Windows keeps
  no IPv6 at all, tunnels included), IPv6 unbound from every adapter now, and the Teredo,
  6to4 and ISATAP tunnels off now. A forged IPv6 router or DHCPv6 answer (mitm6) then
  reaches nothing.
* LLMNR (EnableMulticast=0), mDNS (EnableMDNS=0) and NetBIOS over TCP/IP (NetbiosOptions=2
  on every interface, NodeType=2): a name nobody could resolve is no longer answered by
  whoever shouts first on the local network (Responder).
* WPAD: automatic proxy discovery off (WinHttp DisableWpad=1); the proxy settings themselves
  are already removed by satsuma_win.gateway.
* DNS over HTTPS to the locked OpenDNS servers (dns.opendns.com, the template Linux's
  satsuma.dns_encrypted uses), required by policy
  (DoHPolicy=3, no fallback to plain UDP), so nobody on the way reads or forges a DNS answer.
* TCP/IP: no source routing, no ICMP redirects, no router discovery.

.NET Framework: every .NET 2.0/4.x program uses the system TLS versions and strong crypto
(SchUseStrongCrypto=1, SystemDefaultTlsVersions=1, 32 and 64 bit), so it cannot be talked
down to SSL 3 or TLS 1.0 by a man in the middle.

PowerShell: script block and module logging on (Windows PowerShell and PowerShell 7);
satsuma_win.pslog reads the logged scripts and puts them through the Windows rules;
execution policy AllSigned for Windows PowerShell by policy; the PowerShell 2.0 engine
(no AMSI, no logging) removed, checked once a day.

Some settings act after a restart (DisabledComponents, EnableMDNS, NodeType); this is
recorded, not hidden. Not yet tried on a real Windows machine.

Windows sıkılaştırması: ortadaki adam yollarını kapatır, .NET ve PowerShell'i sıkılaştırır
(sahibinin kararı 2026-11-24). Her ayar yazılır, dakikada bir denetlenir, değiştirilirse geri
yazılır; ilk yazmadan önce bulunan değerler saklanır, --uninstall geri yükler. IPv6 üç katmanda
kapanır; LLMNR, mDNS, NetBIOS ve WPAD kapanır; DNS OpenDNS'e DoH ile zorunlu gider; kaynak
yönlendirme, ICMP yönlendirme ve yönlendirici keşfi kapanır. .NET güçlü şifrelemeye ve sistem
TLS sürümlerine zorlanır. PowerShell'de betik bloğu ve modül günlüğü açılır, Windows
PowerShell için AllSigned, PowerShell 2.0 motoru kaldırılır.
"""
import json
import os
import time
from pathlib import Path

from .browser import REG_DWORD, REG_SZ, Registry
from .dns import SERVERS
from .firewall import FirewallError, run_powershell, safe_run

BACKUP = 'hardening-backup.json'
# The Linux encrypted resolver itself (satsuma.dns_encrypted): OpenDNS, port 443, dns.opendns.com.
# Linux'un şifreli çözümleyicisinin aynısı.
from satsuma.dns_encrypted import HOSTNAME as DOH_HOST, PATH as DOH_PATH  # noqa: E402
DOH_TEMPLATE = 'https://' + DOH_HOST + DOH_PATH
TCPIP = r'SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'
TCPIP6 = r'SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters'
DNSCACHE = r'SYSTEM\CurrentControlSet\Services\Dnscache\Parameters'
DNS_POLICY = r'SOFTWARE\Policies\Microsoft\Windows NT\DNSClient'
NETBT = r'SYSTEM\CurrentControlSet\Services\NetBT\Parameters'
PS_POLICY = r'SOFTWARE\Policies\Microsoft\Windows\PowerShell'
PS7_POLICY = r'SOFTWARE\Policies\Microsoft\PowerShellCore'
REBOOT_NAMES = {(TCPIP6, 'DisabledComponents'), (DNSCACHE, 'EnableMDNS'), (NETBT, 'NodeType')}
PS2_EVERY = 24 * 3600.0


def _dotnet():
    rows = []
    for root in (r'SOFTWARE\Microsoft\.NETFramework', r'SOFTWARE\WOW6432Node\Microsoft\.NETFramework'):
        for version in ('v4.0.30319', 'v2.0.50727'):
            rows += [('dotnet_tls', root + '\\' + version, 'SchUseStrongCrypto', REG_DWORD, 1),
                     ('dotnet_tls', root + '\\' + version, 'SystemDefaultTlsVersions', REG_DWORD, 1)]
    return rows


def static_settings():
    """(group, key, name, type, value) for every fixed registry setting."""
    return [
        ('ipv6', TCPIP6, 'DisabledComponents', REG_DWORD, 0xFF),
        ('llmnr', DNS_POLICY, 'EnableMulticast', REG_DWORD, 0),
        ('mdns', DNSCACHE, 'EnableMDNS', REG_DWORD, 0),
        ('netbios', NETBT, 'NodeType', REG_DWORD, 2),
        ('wpad', r'SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\WinHttp', 'DisableWpad', REG_DWORD, 1),
        ('doh', DNSCACHE, 'EnableAutoDoh', REG_DWORD, 2),
        ('doh', DNS_POLICY, 'DoHPolicy', REG_DWORD, 3),
        ('tcpip', TCPIP, 'DisableIPSourceRouting', REG_DWORD, 2),
        ('tcpip', TCPIP, 'EnableICMPRedirect', REG_DWORD, 0),
        ('tcpip', TCPIP, 'PerformRouterDiscovery', REG_DWORD, 0),
        ('tcpip', TCPIP6, 'DisableIPSourceRouting', REG_DWORD, 2),
        *_dotnet(),
        ('powershell', PS_POLICY + r'\ScriptBlockLogging', 'EnableScriptBlockLogging', REG_DWORD, 1),
        ('powershell', PS_POLICY + r'\ModuleLogging', 'EnableModuleLogging', REG_DWORD, 1),
        ('powershell', PS_POLICY + r'\ModuleLogging\ModuleNames', '*', REG_SZ, '*'),
        ('powershell', PS_POLICY, 'EnableScripts', REG_DWORD, 1),
        ('powershell', PS_POLICY, 'ExecutionPolicy', REG_SZ, 'AllSigned'),
        ('powershell', PS7_POLICY + r'\ScriptBlockLogging', 'EnableScriptBlockLogging', REG_DWORD, 1),
        ('powershell', PS7_POLICY + r'\ModuleLogging', 'EnableModuleLogging', REG_DWORD, 1),
        ('powershell', PS7_POLICY + r'\ModuleLogging\ModuleNames', '*', REG_SZ, '*'),
    ]


def settings(registry):
    """The fixed settings plus NetbiosOptions=2 on every interface Windows has now."""
    rows = list(static_settings())
    for name in sorted(registry.subkeys(NETBT + r'\Interfaces')):
        if name.lower().startswith('tcpip_'):
            rows.append(('netbios', NETBT + '\\Interfaces\\' + name, 'NetbiosOptions', REG_DWORD, 2))
    return rows


def _quote(value):
    return "'" + str(value).replace("'", "''") + "'"


def status_script():
    servers = ','.join(_quote(s) for s in SERVERS)
    return ("$b = @(Get-NetAdapterBinding -ComponentID ms_tcpip6 -ErrorAction SilentlyContinue | Where-Object { $_.Enabled }); "
            "$doh = @(); if (Get-Command Get-DnsClientDohServerAddress -ErrorAction SilentlyContinue) { "
            f"$doh = @(Get-DnsClientDohServerAddress -ErrorAction SilentlyContinue | Where-Object {{ @({servers}) -contains $_.ServerAddress }} | "
            "ForEach-Object { @{server=[string]$_.ServerAddress; template=[string]$_.DohTemplate; fallback=[bool]$_.AllowFallbackToUdp; auto=[bool]$_.AutoUpgrade} }) }; "
            "$teredo = try { [string](Get-NetTeredoConfiguration -ErrorAction Stop).Type } catch { '' }; "
            "@{ipv6_bindings=@($b | ForEach-Object { [string]$_.Name }); doh=$doh; "
            "doh_supported=[bool](Get-Command Add-DnsClientDohServerAddress -ErrorAction SilentlyContinue); teredo=$teredo} "
            "| ConvertTo-Json -Compress -Depth 4")


def apply_script():
    parts = ["Disable-NetAdapterBinding -Name '*' -ComponentID ms_tcpip6 -Confirm:$false -ErrorAction SilentlyContinue",
             "Set-NetTeredoConfiguration -Type Disabled -ErrorAction SilentlyContinue",
             "Set-Net6to4Configuration -State Disabled -ErrorAction SilentlyContinue",
             "Set-NetIsatapConfiguration -State Disabled -ErrorAction SilentlyContinue",
             "& netsh.exe interface ipv4 set global icmpredirects=disabled sourceroutingbehavior=drop | Out-Null",
             "& netsh.exe interface ipv6 set global icmpredirects=disabled sourceroutingbehavior=drop | Out-Null"]
    for server in SERVERS:
        q = _quote(server)
        parts.append("if (Get-Command Add-DnsClientDohServerAddress -ErrorAction SilentlyContinue) { "
                     f"if (Get-DnsClientDohServerAddress -ServerAddress {q} -ErrorAction SilentlyContinue) {{ "
                     f"Set-DnsClientDohServerAddress -ServerAddress {q} -DohTemplate {_quote(DOH_TEMPLATE)} "
                     "-AllowFallbackToUdp $false -AutoUpgrade $true -ErrorAction SilentlyContinue | Out-Null } else { "
                     f"Add-DnsClientDohServerAddress -ServerAddress {q} -DohTemplate {_quote(DOH_TEMPLATE)} "
                     "-AllowFallbackToUdp $false -AutoUpgrade $true -ErrorAction SilentlyContinue | Out-Null } }")
    return '; '.join(parts) + '; ' + status_script()


def restore_script(bindings, doh_added):
    parts = ["Set-NetTeredoConfiguration -Type Default -ErrorAction SilentlyContinue",
             "Set-Net6to4Configuration -State Default -ErrorAction SilentlyContinue",
             "Set-NetIsatapConfiguration -State Default -ErrorAction SilentlyContinue"]
    for name in bindings:
        parts.append(f"Enable-NetAdapterBinding -Name {_quote(name)} -ComponentID ms_tcpip6 -ErrorAction SilentlyContinue")
    for server in doh_added:
        parts.append(f"Remove-DnsClientDohServerAddress -ServerAddress {_quote(server)} -ErrorAction SilentlyContinue")
    return '; '.join(parts) + "; 'ok'"


PS2_SCRIPT = ("$f = @(Get-WindowsOptionalFeature -Online -FeatureName MicrosoftWindowsPowerShellV2Root,MicrosoftWindowsPowerShellV2 "
              "-ErrorAction SilentlyContinue | Where-Object { $_.State -eq 'Enabled' }); "
              "foreach ($x in $f) { Disable-WindowsOptionalFeature -Online -FeatureName $x.FeatureName -NoRestart "
              "-ErrorAction SilentlyContinue | Out-Null }; "
              "$left = @(Get-WindowsOptionalFeature -Online -FeatureName MicrosoftWindowsPowerShellV2Root "
              "-ErrorAction SilentlyContinue | Where-Object { $_.State -eq 'Enabled' }); "
              "@{removed=@($f | ForEach-Object { [string]$_.FeatureName }); still_enabled=($left.Count -gt 0)} | ConvertTo-Json -Compress")


def _doh_ok(row):
    return (row.get('template') == DOH_TEMPLATE and row.get('fallback') is False)


class Hardening:
    """Write, check every minute, write back, restore at uninstall. Yazar, denetler, geri yazar, geri yükler."""

    def __init__(self, state_dir, registry=None, runner=safe_run, clock=time.time):
        self.state_dir, self.runner, self.clock = Path(state_dir), runner, clock
        self.registry = registry if registry is not None else Registry()
        self.ps2_at = None

    def _backup_path(self):
        return self.state_dir / BACKUP

    def _live(self):
        try:
            return json.loads(run_powershell(status_script(), self.runner, timeout=120) or '{}')
        except (FirewallError, ValueError, OSError) as exc:
            return {'error': str(exc)[:300]}

    def _save_backup(self, rows, live):
        if self._backup_path().exists():
            return
        saved = {}
        for _, key, name, _, _ in rows:
            found = (self.registry.read(key) or {}).get(name)
            saved.setdefault(key, {})[name] = list(found) if found else None
        backup = {'saved_at': self.clock(), 'registry': saved,
                  'ipv6_bindings': live.get('ipv6_bindings') or [],
                  'doh_before': [r.get('server') for r in live.get('doh') or []]}
        self.state_dir.mkdir(parents=True, exist_ok=True)
        temporary = self._backup_path().with_suffix('.tmp')
        temporary.write_text(json.dumps(backup, ensure_ascii=False), encoding='utf-8')
        os.replace(temporary, self._backup_path())

    def _registry_differs(self, rows):
        return [(group, key, name, kind, value) for group, key, name, kind, value in rows
                if tuple((self.registry.read(key) or {}).get(name) or ()) != (kind, value)]

    def _live_differs(self, live):
        wrong = []
        if live.get('error'):
            wrong.append('live_unreadable')
        if live.get('ipv6_bindings'):
            wrong.append('ipv6_bound:' + ','.join(live['ipv6_bindings'][:5]))
        if live.get('doh_supported'):
            good = {r.get('server') for r in live.get('doh') or [] if _doh_ok(r)}
            wrong += ['doh_missing:' + s for s in SERVERS if s not in good]
        if live.get('teredo') and live['teredo'].lower() != 'disabled':
            wrong.append('teredo:' + live['teredo'])
        return wrong

    def status(self):
        rows = settings(self.registry)
        differs = ['%s\\%s' % (key, name) for _, key, name, _, _ in self._registry_differs(rows)]
        return {'ok': not differs and not self._live_differs(self._live()), 'differs': differs,
                'live': self._live_differs(self._live())}

    def apply(self):
        """Write what differs; run the live commands; report what still differs and what waits for a restart."""
        rows = settings(self.registry)
        live = self._live()
        self._save_backup(rows, live)
        written, failed = [], []
        for group, key, name, kind, value in self._registry_differs(rows):
            try:
                self.registry.write(key, name, kind, value)
                written.append({'group': group, 'value': key + '\\' + name})
            except OSError as exc:
                failed.append({'group': group, 'value': key + '\\' + name, 'error': str(exc)[:120]})
        try:
            after = json.loads(run_powershell(apply_script(), self.runner, timeout=180) or '{}')
        except (FirewallError, ValueError, OSError) as exc:
            after = {'error': str(exc)[:300]}
        left_registry = ['%s\\%s' % (k, n) for _, k, n, _, _ in self._registry_differs(rows)]
        left_live = self._live_differs(after)
        reboot = sorted({w['value'] for w in written if any(w['value'] == k + '\\' + n for k, n in REBOOT_NAMES)})
        return {'ok': not left_registry and not left_live and not failed, 'status': 'LOCKED' if not left_registry and not left_live else 'NOT_ALL_WRITTEN',
                'written': written, 'failed': failed, 'left': left_registry + left_live,
                'doh_supported': bool(after.get('doh_supported')), 'restart_needed_for': reboot}

    def check_ps2(self, force=False):
        """Remove the PowerShell 2.0 engine once a day (DISM is slow). PowerShell 2.0'ı günde bir kaldırır."""
        now = self.clock()
        if not force and self.ps2_at is not None and now - self.ps2_at < PS2_EVERY:
            return None
        self.ps2_at = now
        try:
            result = json.loads(run_powershell(PS2_SCRIPT, self.runner, timeout=600) or '{}')
        except (FirewallError, ValueError, OSError) as exc:
            return {'ok': False, 'error': str(exc)[:300]}
        return {'ok': not result.get('still_enabled'), **result}

    def restore(self):
        """--uninstall: the values found before Satsuma, IPv6 bound again, Satsuma's DoH entries removed."""
        try:
            backup = json.loads(self._backup_path().read_text(encoding='utf-8'))
        except (OSError, ValueError):
            return {'ok': True, 'status': 'NOTHING_TO_RESTORE'}
        for key, values in (backup.get('registry') or {}).items():
            for name, value in values.items():
                try:
                    if value is None:
                        self.registry.delete(key, name)
                    else:
                        self.registry.write(key, name, value[0], value[1])
                except OSError:
                    continue
        added = [s for s in SERVERS if s not in (backup.get('doh_before') or [])]
        try:
            run_powershell(restore_script(backup.get('ipv6_bindings') or [], added), self.runner, timeout=180)
        except (FirewallError, OSError) as exc:
            return {'ok': False, 'status': 'PARTLY_RESTORED', 'error': str(exc)[:300]}
        self._backup_path().unlink()
        return {'ok': True, 'status': 'RESTORED', 'restart_needed': True}
