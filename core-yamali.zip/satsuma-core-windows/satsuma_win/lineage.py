"""Satsuma's own process launches, confirmed by two independent logs (owner's rule 2026-11-25).

Windows hands a full-access handle (0x1FFFFF) to every process a program starts, and Sysmon
records it. The earlier check (satsuma_win.own_children) trusted process ids, which Windows
reuses and which a parent-process spoof can fake. The owner asked for one check for every case
(the service's tools, the service's own unpacker, the panel's unpacker), checked by Sysmon and by
Windows itself. A full-access record is Satsuma's own launch only if all of this holds:

1. The source is Satsuma: its Sysmon process GUID belongs to a Satsuma instance confirmed at its
   start (image in Program Files\\Satsuma, SHA-256 equal to the installed file on disk and to a
   build in the signed install record, and the Windows service manager naming it), or it is this
   very process and the service manager says so.
2. The source created the target: the target's Sysmon creation record names the source's GUID
   as its parent. GUIDs are never reused before a reboot; a parent spoof shows as a mismatch
   between the access record (the real creator) and the creation record (the claimed parent).
   Exception, seen on real machines (CI and owner's machine 2026-11-25): when a process id was just
   reused, Sysmon may write a STALE GUID in the access record (for the target, or for the source).
   Then the identity falls back to process id + program + moment (_target) or to the creation's
   parent id (judge); that weaker identity is backed only by condition 3, so it is never the first line.
3. Windows agrees: the Security log's own record of the creation (event 4688, written by
   Windows, not Sysmon) has the same new process, the same image and the source as creator.
4. Time: the access is within a few seconds of the target's creation.
5. Kind: the target is the same approved Satsuma exe (one-file unpacking) or a program in
   C:\\Windows\\System32, SysWOW64, C:\\Windows\\Sysmon64.exe or Program Files\\Satsuma.

Anything else stays a critical satsuma_unexpected_access record naming the condition that
failed. A record whose target creation has not been seen yet waits up to WAIT seconds.

Satsuma'nın kendi süreç başlatması iki bağımsız kayıtla doğrulanır: Sysmon süreç kimliği (GUID),
onaylı exe özeti, diskteki dosya ve Windows'un kendi 4688 kaydı. Biri tutmazsa kritik kayıt kalır.
Numara yeniden kullanılınca Sysmon bayat GUID yazabilir; o durumda kimlik numara + program + an olur,
bu daha zayıftır ve yalnızca 4688 kaydıyla desteklenir.
"""
import hashlib
import json
import os
import re
import time
from collections import OrderedDict
from datetime import datetime, timezone
from pathlib import Path

FULL = '0x1fffff'
WAIT = 15.0          # seconds an access waits for its target's creation record
NEAR = 10.0          # seconds between creation and access
# The creating process's own access may carry a Sysmon time a few milliseconds before the creation
# record's (CI 2026-11-24: every build after the 0 <= condition was red). Başlatan sürecin erişimi,
# başlatma kaydından birkaç milisaniye önce görünebilir.
EARLY = 1.0
# The rights of Satsuma's memory scan and hold: synchronize, query (limited), suspend/resume, VM read,
# terminate (CI 2026-11-25: 0x101c11 on LSASS). Nothing that writes memory or creates threads.
OWN_READ_MASK = 0x100000 | 0x1000 | 0x800 | 0x400 | 0x10 | 0x1


def _own_read(granted):
    try:
        value = int(str(granted), 16)
    except ValueError:
        return False
    return value != 0 and value & ~OWN_READ_MASK == 0
KEEP = 900.0         # seconds a creation record is kept
LIMIT = 20000
STATE = 'lineage.json'
AUDIT_PROCESS_CREATION = '{0CCE922B-69AE-11D9-BED3-505054503030}'
SERVICE_NAME = 'SatsumaCore'
SERVICE_EVERY = 60  # seconds the service manager's answer is reused
_service = {'at': None, 'pid': None}


def _lower(value):
    return str(value or '').strip().lower()


def program_files():
    return _lower(os.environ.get('ProgramFiles', r'C:\Program Files'))


def windows_dir():
    return _lower(os.environ.get('SystemRoot', r'C:\Windows'))


def satsuma_dir():
    return program_files() + '\\satsuma\\'


# Programs that run code from their arguments. Satsuma never starts these through a folder rule: a launch of
# one is Satsuma's own only when it is PowerShell with Satsuma's exact command-line prefix (see allowed_target).
# Argümanından kod çalıştıran programlar klasör kuralıyla kabul edilmez; yalnız Satsuma'nın kendi PowerShell
# komut satırı öneki kabul edilir (owner's research 2026-11-26: System32 as a whole was exempt).
NEVER_TARGETS = frozenset({
    'cmd.exe', 'pwsh.exe', 'wscript.exe', 'cscript.exe', 'mshta.exe', 'rundll32.exe', 'regsvr32.exe',
    'certutil.exe', 'bitsadmin.exe', 'wmic.exe', 'installutil.exe', 'regasm.exe', 'regsvcs.exe',
    'odbcconf.exe', 'msbuild.exe', 'forfiles.exe', 'pcalua.exe', 'schtasks.exe', 'at.exe'})
POWERSHELL_LINE = re.compile(
    r'^\s*"?(?:[a-z]:\\[^"]*\\)?powershell\.exe"?\s+-noprofile\s+-noninteractive\s+-executionpolicy\s+bypass'
    r'\s+-command\s', re.IGNORECASE)
ENCODED = re.compile(r'\s-e(?:nc(?:odedcommand)?|c)?\s', re.IGNORECASE)
START_SLACK = 5.0    # seconds an event may precede this process's own start (clock readings differ)


def allowed_target(image, cmdline=None):
    """True when a full-access launch of ``image`` can be Satsuma's own tool.

    Folder rule as before, minus the interpreters in NEVER_TARGETS; PowerShell only with Satsuma's own
    command-line prefix (firewall.POWERSHELL) and no encoded command. An unknown command line is not accepted.
    """
    image = _lower(image)
    win = windows_dir()
    name = image.rsplit('\\', 1)[-1]
    if name in NEVER_TARGETS:
        return False
    if name == 'powershell.exe':
        line = str(cmdline or '')
        return (image.startswith(win + '\\system32\\') and bool(POWERSHELL_LINE.match(line))
                and not ENCODED.search(' ' + line + ' '))
    return (image.startswith(win + '\\system32\\') or image.startswith(win + '\\syswow64\\')
            or image == win + '\\sysmon64.exe' or image.startswith(satsuma_dir()))


def sha256_of(hashes):
    match = re.search(r'SHA256=([0-9A-Fa-f]{64})', str(hashes or ''))
    return match.group(1).lower() if match else None


def utc(value):
    """Sysmon UtcTime ('2026-11-24 21:40:33.123') as seconds."""
    try:
        return datetime.strptime(str(value)[:23], '%Y-%m-%d %H:%M:%S.%f').replace(tzinfo=timezone.utc).timestamp()
    except ValueError:
        try:
            return datetime.strptime(str(value)[:19], '%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc).timestamp()
        except ValueError:
            return None


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def query_4688(pid, within_ms=300000):
    """Windows' own records of creations with this process id (Security log, event 4688), newest first.
    A process id is reused, so the caller picks the one created at the same moment as the target."""
    import win32evtlog
    import xml.etree.ElementTree as ET
    xpath = ("*[System[EventID=4688 and TimeCreated[timediff(@SystemTime) <= %d]]] and "
             "*[EventData[Data[@Name='NewProcessId']='0x%x']]" % (within_ms, int(pid)))
    handle = win32evtlog.EvtQuery('Security', win32evtlog.EvtQueryReverseDirection, xpath)
    ns = '{http://schemas.microsoft.com/win/2004/08/events/event}'
    found = []
    while True:
        rows = win32evtlog.EvtNext(handle, 8)
        if not rows:
            break
        for row in rows:
            root = ET.fromstring(win32evtlog.EvtRender(row, win32evtlog.EvtRenderEventXml))
            data = {d.get('Name'): (d.text or '') for d in root.iter(ns + 'Data')}
            created = root.find(ns + 'System/' + ns + 'TimeCreated')
            found.append({'new_pid': int(data.get('NewProcessId') or '0', 16), 'image': data.get('NewProcessName'),
                          'creator_pid': int(data.get('ProcessId') or '0', 16),
                          'creator_image': data.get('ParentProcessName'),
                          'at': utc(str(created.get('SystemTime') if created is not None else '').replace('T', ' ').rstrip('Z'))})
        if len(found) >= 32:
            break
    return found


def query_service_pid():
    """The process id the Windows service manager gives for SatsumaCore, or None. Hizmet yöneticisinin PID'i."""
    try:
        import win32service
    except ImportError:
        return None
    scm = service = None
    try:
        scm = win32service.OpenSCManager(None, None, win32service.SC_MANAGER_CONNECT)
        service = win32service.OpenService(scm, SERVICE_NAME, win32service.SERVICE_QUERY_STATUS)
        return int(win32service.QueryServiceStatusEx(service).get('ProcessId') or 0) or None
    except Exception:  # no such service, no access: unverified, never assumed
        return None
    finally:
        for handle in (service, scm):
            if handle is not None:
                try:
                    win32service.CloseServiceHandle(handle)
                except Exception:
                    pass


def own_start():
    """This process's start time (epoch seconds), or None when it cannot be read. Kendi başlangıç zamanı."""
    try:
        import psutil
        return float(psutil.Process(os.getpid()).create_time())
    except Exception:
        return None


def service_pid(clock=time.time, query=query_service_pid):
    now = clock()
    if _service['at'] is None or now - _service['at'] >= SERVICE_EVERY:
        _service.update(at=now, pid=query())
    return _service['pid']


def enable_process_audit(runner):
    """Turn on Windows' own process-creation audit (event 4688), by subcategory GUID (any language)."""
    kw = {'capture_output': True, 'text': True, 'timeout': 60}
    result = runner(['auditpol.exe', '/set', '/subcategory:' + AUDIT_PROCESS_CREATION, '/success:enable'], **kw)
    check = runner(['auditpol.exe', '/get', '/subcategory:' + AUDIT_PROCESS_CREATION, '/r'], **kw)
    text = str(getattr(check, 'stdout', '') or '')
    return {'ok': getattr(result, 'returncode', 1) == 0 and 'Success' in text, 'status':
            'ENABLED' if 'Success' in text else 'NOT_ENABLED', 'detail': text.strip()[-200:]}


class Lineage:
    def __init__(self, directory, key=None, clock=time.time, approved=None, installed=None,
                 service_pid=None, os_log=query_4688, own_pid=None, parent_pid=None, started=None):
        self.dir, self.key, self.clock = Path(directory), key, clock
        self.approved = approved or (lambda: set())          # SHA-256 of every build in the signed record
        self.installed = installed or (lambda: {})          # {lowercase path: SHA-256 on disk}
        self.service_pid = service_pid or (lambda: None)    # what the Windows service manager says
        self.os_log = os_log
        self.own_pid = os.getpid() if own_pid is None else own_pid
        self.started = started    # this process's own start (epoch seconds); None = not checked (tests)
        self.parent_pid = os.getppid() if parent_pid is None else parent_pid
        self.creations = OrderedDict()                      # guid -> creation facts
        self.known = {}                                     # Satsuma instance guid -> {'pid', 'at'}
        self.waiting = []                                   # (deadline, event)
        self._load()

    # --- Satsuma instances, kept for the current boot -------------------------------------------
    def _boot(self):
        try:
            import ctypes
            return int(self.clock() - ctypes.windll.kernel32.GetTickCount64() / 1000.0) // 60
        except Exception:  # not Windows (tests): one boot
            return 0

    def _load(self):
        try:
            stored = json.loads((self.dir / STATE).read_text(encoding='utf-8'))
        except (OSError, ValueError):
            return
        body = stored.get('body') if isinstance(stored, dict) else None
        if not isinstance(body, dict) or self.key is None:
            return
        if not self.key.verify(json.dumps(body, sort_keys=True).encode(), str(stored.get('signature'))):
            return  # a list changed by hand is never trusted
        if body.get('boot') != self._boot():
            return  # GUIDs are unique only within one boot
        self.known = {g: v for g, v in (body.get('known') or {}).items() if isinstance(v, dict)}

    def _save(self):
        if self.key is None:
            return
        body = {'boot': self._boot(), 'known': dict(list(self.known.items())[-20:])}
        try:
            tmp = (self.dir / STATE).with_suffix('.tmp')
            tmp.write_text(json.dumps({'body': body, 'signature': self.key.sign(
                json.dumps(body, sort_keys=True).encode())}), encoding='utf-8')
            os.replace(tmp, self.dir / STATE)
        except OSError:
            pass

    # --- Sysmon creation records ---------------------------------------------------------------
    def note(self, event):
        """A Sysmon process-creation record (event 1). Sysmon süreç oluşturma kaydı."""
        guid = _lower(event.get('ProcessGuid'))
        if not guid:
            return
        self.creations[guid] = {'pid': _int(event.get('ProcessId')), 'image': _lower(event.get('Image')),
                                'sha256': sha256_of(event.get('Hashes')), 'parent': _lower(event.get('ParentProcessGuid')),
                                'parent_pid': _int(event.get('ParentProcessId')), 'at': utc(event.get('UtcTime')),
                                'cmd': str(event.get('CommandLine') or ''), 'seen': self.clock()}
        while len(self.creations) > LIMIT:
            self.creations.popitem(last=False)
        self._confirm_instance(guid)

    def _satsuma_image(self, facts):
        """The creation is of an installed, approved Satsuma exe: path, Sysmon hash, disk hash, signed record."""
        if not facts or not facts['image'].startswith(satsuma_dir()) or not facts['sha256']:
            return False
        disk = self.installed().get(facts['image'])
        return disk is not None and disk == facts['sha256'] and facts['sha256'] in self.approved()

    def _confirm_instance(self, guid):
        """A new process is a Satsuma instance when it is an approved Satsuma exe the service manager
        names, or the unpacked child of one. Hizmet yöneticisinin adlandırdığı onaylı Satsuma süreci."""
        facts = self.creations.get(guid)
        if not self._satsuma_image(facts):
            return
        service = self.service_pid()
        parent = self.creations.get(facts['parent'])
        named = service is not None and facts['pid'] == service
        unpacked = facts['parent'] in self.known and parent is not None and parent['image'] == facts['image']
        if named or unpacked:
            self.known[guid] = {'pid': facts['pid'], 'at': self.clock(), 'image': facts['image'],
                                'sha256': facts['sha256']}
            self._save()

    def _source_is_satsuma(self, event):
        guid = _lower(event.get('SourceProcessGUID'))
        entry = self.known.get(guid)
        if entry is not None:
            # Every use re-checks the exe: path hash on disk equal to the Sysmon hash and to a signed build.
            # Her kullanımda exe özeti yeniden denetlenir; tutmazsa kayıt silinir, güven geri alınır.
            image, sha = entry.get('image'), entry.get('sha256')
            if image and sha and self.installed().get(image) == sha and sha in self.approved():
                return None
            self.known.pop(guid, None)
            self._save()
        pid = _int(event.get('SourceProcessId'))
        if pid in (self.own_pid, self.parent_pid):
            service = self.service_pid()
            if service is None:
                return 'hizmet yöneticisi SatsumaCore sürecini doğrulayamadı'
            if service not in (self.own_pid, self.parent_pid):
                return 'hizmet yöneticisinin SatsumaCore süreci bu süreç değil'
            # A process id alone is not an identity: the program must be an approved Satsuma exe on disk and,
            # for this very process, the event must not be older than its start.
            # Numara tek başına kimlik değildir: program onaylı Satsuma exe'si olmalı, olay süreçten eski olmamalı.
            image = _lower(event.get('SourceImage'))
            sha = self.installed().get(image)
            if not image.startswith(satsuma_dir()) or sha is None or sha not in self.approved():
                return 'kaynak program onaylı bir Satsuma exe\'si değil'
            if pid == self.own_pid and self.started is not None:
                at = utc(event.get('UtcTime'))
                if at is None or at < self.started - START_SLACK:
                    return 'olay bu sürecin başlamasından önce (numara yeniden kullanılmış olabilir)'
            self.known[guid] = {'pid': pid, 'at': self.clock(), 'image': image, 'sha256': sha}
            self._save()
            return None
        facts = self.creations.get(guid)
        if self._satsuma_image(facts):
            return None  # a Satsuma exe the user started (the panel, a command): approved and on disk
        return 'kaynak süreç doğrulanmış bir Satsuma örneği değil'

    # --- the check ---------------------------------------------------------------------------
    def judge(self, event):
        """None (Satsuma's own launch), 'wait', or the reason it is not. Kendi işi mi?"""
        granted = _lower(event.get('GrantedAccess'))
        if granted != FULL:
            # B2 (2026-11-25): Satsuma's memory scan of LSASS is no longer exempt in Sysmon. The read-only codes
            # that used to be exempt are Satsuma's own when the source is a confirmed Satsuma process.
            # Eskiden muaf okuma kodları, kaynak doğrulanmış Satsuma ise Satsuma'nın kendi bellek taramasıdır.
            if _own_read(granted) and not self._source_is_satsuma(event):
                return None
            return 'tam erişim dışında bir istek'
        problem = self._source_is_satsuma(event)
        if problem:
            return problem
        source = _lower(event.get('SourceProcessGUID'))
        target = self._target(event)
        if target is None:
            return 'wait'
        weak = False   # identity rests on process ids only (stale GUID of the source)
        if target['parent'] != source:
            # A stale GUID may name another program's launch with the same id (CI 2026-11-25): look for a
            # launch of the same id, program and moment whose parent is the source; none (yet) -> wait, then alarm.
            # Bayat kimlik başkasının başlatmasını gösterebilir; aynı numara, program ve anda kaynağın başlattığı aranır.
            alt = self._target(event, parent=source)
            # Sysmon may write a stale GUID for the source too (CI 2026-11-25): the creation's parent id is
            # the source's id, already confirmed as Satsuma by id and the service manager; 4688 checks it below.
            # Kaynağın kimliği de bayat olabilir: üst süreç numarası, doğrulanmış kaynağın numarasıysa kabul.
            if alt is None and target.get('parent_pid') is not None \
                    and target['parent_pid'] == _int(event.get('SourceProcessId')):
                alt, weak = target, True
            target = alt
            if target is None:
                return 'wait-parent'
        access_at = utc(event.get('UtcTime'))
        if target['at'] is None or access_at is None or abs(access_at - target['at']) > NEAR:
            return 'erişim, hedefin başlatılmasıyla aynı anda değil'
        source_facts = self.creations.get(source)
        same_exe = source_facts is not None and source_facts['image'] == target['image']
        if target['image'].startswith(satsuma_dir()) and target['image'].endswith('.exe') and same_exe:
            if not self._satsuma_image(target):
                return 'açılan Satsuma exe\'si onaylı ve diskteki dosyayla aynı değil'
        elif not allowed_target(target['image'], target.get('cmd')):
            return 'hedef, Satsuma\'nın başlattığı araçların klasörlerinde değil'
        try:
            records = self.os_log(target['pid'])
        except Exception as exc:  # the Security log could not be read: never assumed
            return 'Windows süreç kaydı (4688) okunamadı: ' + type(exc).__name__
        if isinstance(records, dict):
            records = [records]
        # The same process id is reused: only Windows' record of this very creation counts.
        # Aynı süreç numarası yeniden kullanılır: yalnızca bu başlatmanın Windows kaydı sayılır.
        same = [r for r in records or () if r.get('at') is None or abs(r['at'] - target['at']) <= NEAR]
        if not same:
            return 'wait-4688'  # Windows writes its record a moment later; asked again until WAIT
        windows = same[0]
        if _lower(windows.get('image')) != target['image']:
            return 'Windows ve Sysmon farklı program gösteriyor'
        creator = _lower(windows.get('creator_image'))
        if creator and creator != _lower(event.get('SourceImage')):
            return 'Windows başka bir başlatan program gösteriyor'
        if weak and not creator.startswith(satsuma_dir()):
            return 'bayat kimlikte Windows başlatan Satsuma programını doğrulamadı'
        if windows.get('creator_pid') != _int(event.get('SourceProcessId')):
            return 'Windows başka bir başlatan süreç gösteriyor'
        return None

    def _target(self, event, parent=None):
        """The target's creation record. Sysmon may write a stale GUID in an access record when the process
        id was just reused (owner's machine 2026-11-25: PID 9180 of a finished SearchProtocolHost, given to
        Satsuma's route.exe); then the creation with the same id and program, just before the access, is used.
        Süreç numarası yeniden kullanılınca Sysmon bayat kimlik yazabilir; aynı numara ve programın hemen
        önceki başlatma kaydı kullanılır."""
        image = _lower(event.get('TargetImage'))
        pid, at = _int(event.get('TargetProcessId')), utc(event.get('UtcTime'))
        facts = None if parent else self.creations.get(_lower(event.get('TargetProcessGUID')))
        # Trusted only when both the program and the moment agree: a stale GUID may even name an earlier
        # process of the same program that had the same id (route.exe, every two seconds).
        # Kimlik ancak program ve zaman birlikte tutarsa güvenilir.
        if facts is not None and (not image or facts['image'] == image) and (
                at is None or facts['at'] is None or -EARLY <= at - facts['at'] <= NEAR):
            return facts
        if pid is None or at is None:
            return facts if facts is not None and facts['image'] == image else None
        candidates = [f for f in self.creations.values() if f['pid'] == pid and f['image'] == image
                      and f['at'] is not None and -EARLY <= at - f['at'] <= NEAR
                      and (parent is None or f['parent'] == parent)]
        return max(candidates, key=lambda f: f['at']) if candidates else None

    def decide(self, event):
        """None, or the reason; an access whose target is not seen yet waits up to WAIT seconds."""
        verdict = self.judge(event)
        if verdict in ('wait', 'wait-4688', 'wait-parent'):
            self.waiting.append((self.clock() + WAIT, event))
            return 'wait'
        return verdict

    def due(self):
        """Waiting accesses decided now: [(event, verdict)]; past the deadline a missing creation is a reason."""
        now, keep, done = self.clock(), [], []
        for deadline, event in self.waiting:
            verdict = self.judge(event)
            if verdict in ('wait', 'wait-4688', 'wait-parent') and now < deadline:
                keep.append((deadline, event))
            else:
                done.append((event, {'wait': 'hedefin Sysmon başlatma kaydı bulunamadı',
                                     'wait-4688': 'Windows süreç kaydı (4688) yok; Windows bu başlatmayı kaydetmemiş',
                                     'wait-parent': 'hedefin Sysmon başlatma kaydı başka bir üst süreç gösteriyor '
                                                    '(üst süreç sahtelemesi olabilir)'}
                             .get(verdict, verdict)))
        self.waiting = keep
        cutoff = now - KEEP
        while self.creations and next(iter(self.creations.values()))['seen'] < cutoff:
            self.creations.popitem(last=False)
        return done


def _int(value):
    try:
        return int(str(value).strip(), 0) if str(value).strip().lower().startswith('0x') else int(value)
    except (TypeError, ValueError):
        return None
