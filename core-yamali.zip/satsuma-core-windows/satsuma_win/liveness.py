"""Did the previous run of the service end without its stop record? (owner's machine 2026-11-25)

The owner ended Satsuma from Task Manager at 05:10: the service wrote nothing, Windows' service
manager wrote nothing and the recovery never started it again. Now the service keeps
``service-alive.json`` (Windows' boot time, its pid, the last time it was seen) up to date while
it runs and marks it clean when a stop is requested. At the next start:

* not clean, same boot: critical ``satsuma_ended_without_stop`` (ended from outside, or crashed);
* not clean, another boot: ``satsuma_previous_run_ended_by_shutdown`` (the machine went down:
  Windows does not stop services at shutdown).

Hizmetin bir önceki çalışması durdurma kaydı olmadan bitti mi? Aynı açılışta bittiyse kritik kayıt.
"""
import json
import os
import time
from pathlib import Path

MARKER = 'service-alive.json'
BEAT = 60.0
SAME_BOOT = 120.0  # seconds of tolerance between two readings of the boot time


def boot_time(clock=time.time):
    """Windows' boot time from GetTickCount64 (milliseconds since boot)."""
    import ctypes
    getter = ctypes.windll.kernel32.GetTickCount64
    getter.restype = ctypes.c_ulonglong
    return clock() - getter() / 1000.0


def _write(directory, row):
    path = Path(directory) / MARKER
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(row), encoding='utf-8')
    os.replace(temporary, path)


class Liveness:
    def __init__(self, directory, record, pid=None, boot=None, clock=time.time):
        self.dir, self.record, self.clock = Path(directory), record, clock
        self.pid = os.getpid() if pid is None else pid
        self.boot = boot_time(clock) if boot is None else boot
        self.started = clock()
        self.beat_at = None

    def check_previous(self):
        """At start: report how the previous run ended, then mark this run as alive."""
        try:
            row = json.loads((self.dir / MARKER).read_text(encoding='utf-8'))
        except (OSError, ValueError):
            row = None
        event = None
        if isinstance(row, dict) and not row.get('clean'):
            details = {'previous_pid': row.get('pid'), 'previous_started': row.get('started'),
                       'last_seen': row.get('last_seen')}
            if abs(float(row.get('boot') or 0) - self.boot) <= SAME_BOOT:
                event = self.record('satsuma_ended_without_stop', severity='critical', alarm='critical',
                                    reason='Satsuma durdurma kaydı olmadan sonlandı (dışarıdan sonlandırıldı ya da çöktü)',
                                    **details)
            else:
                event = self.record('satsuma_previous_run_ended_by_shutdown', **details)
        self.beat(force=True)
        return event

    def beat(self, force=False):
        now = self.clock()
        if not force and self.beat_at is not None and now - self.beat_at < BEAT:
            return
        self.beat_at = now
        _write(self.dir, {'boot': self.boot, 'pid': self.pid, 'started': self.started, 'last_seen': now, 'clean': False})

    def clean_stop(self):
        _write(self.dir, {'boot': self.boot, 'pid': self.pid, 'started': self.started, 'last_seen': self.clock(),
                          'clean': True})
