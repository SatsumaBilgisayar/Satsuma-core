"""Windows Firewall set up by Satsuma, and every block it decided kept as a signed list (owner's decision 2026-11-24).

Baseline, checked every minute and written back: the three profiles on, incoming traffic
blocked by default, dropped packets logged to %ProgramData%\\Satsuma\\firewall\\pfirewall.log
(16 MB), no notification asking the user to allow a program in.

Block list: every address Satsuma blocked (PTR rule, subnet limit, OTX) is added to
blocks.json with its reason and signed with the machine key. At start and every minute each
listed address must still have its block rules; a rule someone deleted is written again and
recorded. A list whose signature fails is set aside and never trusted.

Windows Güvenlik Duvarı'nı Satsuma yapılandırır; verdiği her engel imzalı listede tutulur
(sahibinin kararı 2026-11-24). Üç profil açık, gelen trafik varsayılan engelli, düşen paketler
günlüğe yazılır, program izni bildirimi yok; dakikada bir denetlenir. Engellenen her adres
nedeniyle blocks.json'a eklenir ve makine anahtarıyla imzalanır; silinen kural geri yazılır.
"""
import json
import os
import time
from pathlib import Path

from . import firewall

LIST = 'blocks.json'
ALLOWED = 'allowed.json'


def baseline_script(log):
    quoted = "'" + str(log).replace("'", "''") + "'"
    return ("New-Item -ItemType Directory -Force -Path (Split-Path " + quoted + ") | Out-Null; "
            "Set-NetFirewallProfile -All -Enabled True -DefaultInboundAction Block -NotifyOnListen False "
            "-LogBlocked True -LogMaxSizeKilobytes 16384 -LogFileName " + quoted + "; " + check_script())


def check_script():
    return ("@(Get-NetFirewallProfile | ForEach-Object { @{name=[string]$_.Name; enabled=[string]$_.Enabled; "
            "inbound=[string]$_.DefaultInboundAction; blocked=[string]$_.LogBlocked; notify=[string]$_.NotifyOnListen} }) "
            "| ConvertTo-Json -Compress")


def profiles_ok(rows):
    rows = rows if isinstance(rows, list) else [rows]
    return len(rows) >= 3 and all(r.get('enabled') == 'True' and r.get('inbound') == 'Block'
                                  and r.get('blocked') == 'True' and r.get('notify') == 'False' for r in rows)


def present_script(ips):
    """Both block rules of every listed address, with whether each is enabled and still blocks.
    Her adresin iki engel kuralı: var mı, açık mı, hâlâ engelliyor mu."""
    names = ','.join("'" + name + "'" for ip in ips for name in firewall.rule_names(ip))
    return ("@(Get-NetFirewallRule -Name " + names + " -ErrorAction SilentlyContinue | "
            "ForEach-Object { @{name=[string]$_.Name; enabled=[string]$_.Enabled; action=[string]$_.Action} }) "
            "| ConvertTo-Json -Compress")


def remove_script(ip):
    names = ','.join("'" + name + "'" for name in firewall.rule_names(ip))
    return "Remove-NetFirewallRule -Name " + names + " -ErrorAction SilentlyContinue"


def rule_state(rows):
    """{rule name: problem or None} from present_script's answer. Kural adı → sorun."""
    rows = [rows] if isinstance(rows, dict) else list(rows or [])
    state = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        enabled = str(row.get('enabled')) in ('True', '1')
        blocks = str(row.get('action')) in ('Block', '4')
        state[str(row.get('name'))] = (None if enabled and blocks else
                                       'kapatılmış' if not enabled and blocks else
                                       'engellemiyor (' + str(row.get('action')) + ')' if enabled else
                                       'kapatılmış ve engellemiyor (' + str(row.get('action')) + ')')
    return state


class FirewallAuto:
    def __init__(self, state_dir, key, record, runner=firewall.safe_run, clock=time.time):
        self.dir, self.key, self.record, self.runner, self.clock = Path(state_dir), key, record, runner, clock

    def log_path(self):
        return self.dir / 'firewall' / 'pfirewall.log'

    def baseline(self):
        rows = json.loads(firewall.run_powershell(baseline_script(self.log_path()), self.runner) or '[]')
        return {'ok': profiles_ok(rows), 'status': 'LOCKED' if profiles_ok(rows) else 'NOT_LOCKED', 'profiles': rows}

    def baseline_ok(self):
        return profiles_ok(json.loads(firewall.run_powershell(check_script(), self.runner) or '[]'))

    def blocks(self):
        path = self.dir / LIST
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            rows = data['rows']
            if self.key is not None and self.key.verify(json.dumps(rows, sort_keys=True).encode(), data['signature']):
                return rows
        except FileNotFoundError:
            return {}
        except (OSError, ValueError, KeyError, TypeError):
            pass
        if path.exists():
            os.replace(path, self.dir / ('rejected-' + time.strftime('%Y%m%d%H%M%S') + '-' + LIST))
            self.record('firewall_block_list_rejected')
        return {}

    def add(self, ip, reason, **extra):
        """Keep one block for ever (signed). Bir engeli kalıcı tutar (imzalı)."""
        if self.key is None:
            return False
        rows = self.blocks()
        rows[ip] = {'reason': reason, 'since': rows.get(ip, {}).get('since', self.clock()), **extra}
        self.dir.mkdir(parents=True, exist_ok=True)
        text = json.dumps({'rows': rows, 'signature': self.key.sign(json.dumps(rows, sort_keys=True).encode())})
        (self.dir / (LIST + '.tmp')).write_text(text, encoding='utf-8')
        os.replace(self.dir / (LIST + '.tmp'), self.dir / LIST)
        return True

    def _write(self, name, rows):
        self.dir.mkdir(parents=True, exist_ok=True)
        text = json.dumps({'rows': rows, 'signature': self.key.sign(json.dumps(rows, sort_keys=True).encode())})
        (self.dir / (name + '.tmp')).write_text(text, encoding='utf-8')
        os.replace(self.dir / (name + '.tmp'), self.dir / name)

    def forget(self, ip):
        """Drop one address from the kept blocks (the owner removed the block). Kalıcı engelden çıkarır."""
        rows = self.blocks()
        if self.key is None or ip not in rows:
            return False
        rows.pop(ip)
        self._write(LIST, rows)
        return True

    def allowed(self):
        """Addresses the owner allowed: never blocked again (signed). Sahibin izin verdiği adresler (imzalı)."""
        try:
            data = json.loads((self.dir / ALLOWED).read_text(encoding='utf-8'))
            rows = data['rows']
            if self.key is not None and self.key.verify(json.dumps(rows, sort_keys=True).encode(), data['signature']):
                return rows
        except (OSError, ValueError, KeyError, TypeError):
            pass
        return {}

    def allow(self, ip, **extra):
        if self.key is None:
            return False
        rows = self.allowed()
        rows[ip] = {'since': self.clock(), **extra}
        self._write(ALLOWED, rows)
        return True

    def restore_blocks(self):
        """Write back the block rules of every listed address that lost them, and turn back on (critical
        record) a block rule someone disabled or changed: only the owner's --unblock removes a block.
        Silinen kural geri yazılır; kapatılan ya da değiştirilen kural geri açılır ve kritik kayıt düşer."""
        rows = self.blocks()
        if not rows:
            return []
        state = rule_state(json.loads(firewall.run_powershell(present_script(sorted(rows)), self.runner) or '[]'))
        events = []
        for ip in sorted(rows):
            names = firewall.rule_names(ip)
            missing = [name for name in names if name not in state]
            changed = {name: state[name] for name in names if state.get(name)}
            if not missing and not changed:
                continue
            try:
                if changed:
                    firewall.run_powershell(remove_script(ip), self.runner)
                firewall.block_ip(ip, rows[ip].get('reason', 'kept'), self.runner)
                if changed:
                    events.append(self.record('firewall_block_disabled', severity='critical', ip=ip,
                                              reason=rows[ip].get('reason'), rules=changed, restored=True))
                else:
                    events.append(self.record('firewall_block_restored', ip=ip, reason=rows[ip].get('reason'),
                                              rules=missing))
            except (firewall.FirewallError, ValueError) as exc:
                kind = 'firewall_block_disabled' if changed else 'firewall_block_restore_failed'
                events.append(self.record(kind, severity='critical' if changed else 'high', ip=ip,
                                          rules=changed or missing, restored=False, error=str(exc)[:200]))
        return events
