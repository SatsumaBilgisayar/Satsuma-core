"""The Windows network guard: closes 853, locks DNS, refuses incoming connections, then applies the fixed rules.

At start: port 853 is closed, the DNS lock is set and incoming connections
are refused (satsuma_win.inbound); every result is recorded, and a failure
is reported, never hidden. The incoming lock is checked every minute and
written back if something reopened it. Then every poll reads the
connection table once and applies the no-PTR rule and the subnet limit; each
decision is blocked with Windows Firewall and recorded, whether or not the
block succeeded. Protected addresses (gateway, DNS servers, remote support)
are never blocked. Every few seconds the memory of every process is read
(satsuma_win.memory) and what the shared memory rules stop is stopped. The
ClamAV memory signature scan (RAM v2) is removed (2026-11-24: its clamd
listened on 127.0.0.1:3311 unencrypted and unchecked); at start whatever an
earlier version left of it is deleted (satsuma_win.retired). Records: %ProgramData%\\Satsuma\\events.jsonl and
state.json. Needs an administrator account.

Windows ağ bekçisi: 853'ü kapatır, DNS'i kilitler, sonra sabit kuralları iki
saniyede bir uygular. Açılışta 853 kapatılır, DNS kilitlenir ve gelen bağlantılar
reddedilir; her sonuç kaydedilir, başarısızlık gizlenmez, bildirilir. Gelen
bağlantı kilidi dakikada bir denetlenir, biri açarsa geri yazılır. Sonra her turda bağlantı
tablosu bir kez okunur, PTR kuralı ve alt ağ sınırı uygulanır; her karar
Windows Güvenlik Duvarı ile engellenir ve engel başarılı olsun olmasın
kaydedilir. Korunan adresler asla engellenmez. Birkaç saniyede
bir her sürecin belleği okunur ve ortak bellek kurallarının durdurduğu
durdurulur. ClamAV bellek imza taraması (RAM v2) kaldırıldı (2026-11-24:
clamd'si 127.0.0.1:3311'de şifresiz ve denetimsiz dinliyordu); açılışta önceki
sürümden kalanı silinir (satsuma_win.retired). Kayıtlar:
%ProgramData%\\Satsuma\\events.jsonl ve state.json. Yönetici hesabı gerekir.
"""
import json
import os
import sys
import time
from pathlib import Path

from . import connections, dns, firewall, inbound, protect
from .peers import PeerRule
from .subnet import SubnetRule

POLL_SECONDS = 2.0
INFRASTRUCTURE_EVERY = 60.0
INBOUND_EVERY = 60.0
MEMORY_EVERY = 5.0
ACCOUNTS_EVERY = 60.0
SYSMON_RETRY_EVERY = 60.0
SYSMON_INSTALL_EVERY = 600.0
RULE_REPEAT_EVERY = 600.0        # the same rule for the same process is recorded again after this


def sysmon_dir():
    return Path(os.environ.get('ProgramFiles', r'C:\Program Files')) / 'Satsuma' / 'Sysmon'


def state_dir():
    return Path(os.environ.get('ProgramData', r'C:\ProgramData')) / 'Satsuma'


IMPORTANT = 'important.jsonl'


def important(event):
    """Kept apart for the panel: blocks, stops, critical and high findings, alarms, failures."""
    return (event.get('severity') in ('critical', 'high') or event.get('kind') == 'blocked'
            or event.get('outcome') in ('stopped', 'stop_failed') or event.get('alarm') == 'critical'
            or str(event.get('kind', '')).endswith('_failed'))


BACKFILL_DONE = 'important-backfill.done'


def backfill_important(directory):
    """Once (owner's approval 2026-11-25): every important record already in events.jsonl is copied into
    important.jsonl, before the ones written since, so the panel shows yesterday's blocks and stops too.
    Bir kez: events.jsonl'deki bütün önemli kayıtlar important.jsonl'e, sonradan yazılanların önüne aktarılır."""
    directory = Path(directory)
    if (directory / BACKFILL_DONE).exists():
        return {'ok': True, 'status': 'ALREADY_DONE'}
    target = directory / IMPORTANT
    try:
        existing = target.read_text(encoding='utf-8').splitlines() if target.exists() else []
        seen, copied = set(line for line in existing if line.strip()), []
        with open(directory / 'events.jsonl', encoding='utf-8', errors='replace') as stream:
            for line in stream:
                line = line.rstrip('\n')
                if not line.strip() or line in seen:
                    continue
                try:
                    event = json.loads(line)
                except ValueError:
                    continue
                if isinstance(event, dict) and important(event):
                    seen.add(line)
                    copied.append(line)
        tmp = target.with_suffix('.tmp')
        tmp.write_text('\n'.join(copied + [l for l in existing if l.strip()]) + '\n', encoding='utf-8')
        os.replace(tmp, target)
        (directory / BACKFILL_DONE).write_text(str(len(copied)), encoding='utf-8')
        return {'ok': True, 'status': 'COPIED', 'count': len(copied)}
    except OSError as exc:  # tried again at the next start
        return {'ok': False, 'status': 'ERROR', 'error': str(exc)[:200]}


class Guard:
    def __init__(self, runner=None, read=connections.read, clock=time.time, directory=None,
                 peer_rule=None, subnet_rule=None, echo=print, memory_factory=None, key_loader=None,
                 sysmon_factory=None, package_manager_running=None, gateway_factory=None,
                 accounts_factory=None, devices_factory=None, sysmon_installer=None, retire=None, rules_factory=None, ai_factory=None,
                 browser_factory=None, suricata_factory=None, hardening_factory=None, certs_factory=None,
                 fw_factory=None, otx_factory=None, connkill=None, own_child=None,
                 firmware_reader=None):
        self.runner = runner or firewall.safe_run
        self.read, self.clock, self.echo = read, clock, echo
        self.directory = Path(directory) if directory else state_dir()
        self.infrastructure, self.infrastructure_at, self.support = set(), None, set()
        self.peers = peer_rule or PeerRule(self.protected, clock=clock)
        self.subnet = subnet_rule or SubnetRule(self.protected, clock=clock)
        self.counts = {'blocked': 0, 'block_failed': 0, 'skipped_protected': 0,
                       'inbound_changed': 0, 'inbound_restored': 0}
        self.inbound_at = None
        self.startup = {}
        # A Sysmon full-access record is confirmed as Satsuma's own launch by Sysmon GUIDs, the approved
        # exe digests and Windows' own 4688 record (satsuma_win.lineage); tests may pass a judge.
        # Tam erişim kaydı Sysmon kimliği, onaylı özet ve Windows'un 4688 kaydıyla doğrulanır.
        self.confirm_own_child, self.lineage, self.audit_at = own_child, None, None
        self.firmware_reader, self.firmware = firmware_reader, None
        self.memory_factory = memory_factory or default_memory_scanner
        self.memory, self.memory_at = None, None
        self.key = None
        if key_loader is None:
            from . import machine_key
            key_loader = machine_key.ensure
        self.key_loader = key_loader
        self.sysmon_factory = sysmon_factory or default_sysmon_reader
        self.pm_running = package_manager_running or windows_package_manager_running
        self.sysmon, self.sysmon_at, self.sysmon_install_at = None, None, None
        self.sysmon_installer = sysmon_installer or default_sysmon_installer
        self.gateway_factory = gateway_factory or default_gateway
        self.gateway, self.key_created = None, False
        self.accounts_factory = accounts_factory or default_accounts
        self.accounts, self.accounts_at = None, None
        self.devices_factory = devices_factory or default_devices
        self.devices, self.devices_at = None, None
        self.counts.update({'sysmon_events': 0, 'build_tool_stopped': 0, 'build_tool_allowed': 0,
                            'build_tool_stop_failed': 0})
        self.retire = retire or default_retire
        self.rules_factory = rules_factory or default_rules
        self.rules, self.rule_seen = None, {}
        self.ai_factory = ai_factory or default_ai
        self.ai = None
        self.gate = None
        self.liveness = None
        self.browser_factory = browser_factory or default_browser
        self.hardening_factory = hardening_factory or default_hardening
        self.certs_factory = certs_factory or default_certs
        self.fw_factory, self.otx_factory = fw_factory or default_fwauto, otx_factory or default_otx
        self.fw, self.fw_at, self.otx = None, None, None
        self.connkill = connkill or default_connkill
        self.counts.update({'connections_ended': 0, 'otx_blocked': 0})
        import threading
        self.scan_lock, self.sysmon_lane = threading.RLock(), False
        self.integrity_at = None
        self.certs, self.certs_at = None, None
        self.hardening, self.hardening_at = None, None
        self.counts.update({'hardening_changed': 0, 'hardening_restored': 0})
        self.suricata_factory = suricata_factory or default_suricata
        self.suricata = None
        self.browser, self.browser_at = None, None
        self.counts.update({'browser_policy_changed': 0, 'browser_policy_restored': 0})
        self.counts.update({'rule_findings': 0, 'rule_stopped': 0, 'rule_stop_failed': 0, 'rule_not_stopped': 0})

    def protected(self, ip):
        reason = protect.protected_reason(ip, self.infrastructure, self.support)
        if reason is None and self.fw is not None:
            try:
                if ip in self.fw.allowed():
                    return 'owner_allowed'
            except Exception:  # an unreadable allow list never blocks the guard
                pass
        return reason

    def record(self, kind, **fields):
        # Owner's approval 2026-11-25: while the service is being stopped (an update, say) a PowerShell step cut
        # short is not a failure worth an alarm. Hizmet dururken yarıda kalan PowerShell adımı hata sayılmaz.
        if getattr(self, 'stopping', False) and fields.get('error') == 'PowerShell failed':
            return {'time': self.clock(), 'kind': kind, 'suppressed': 'service_stopping', **fields}
        event = {'time': self.clock(), 'kind': kind, **fields}
        line = json.dumps(event, ensure_ascii=False, sort_keys=True)
        with RECORD_LOCK:  # the Sysmon lane writes too; one line at a time
            self.echo(line)
            try:
                self.directory.mkdir(parents=True, exist_ok=True)
                with open(self.directory / 'events.jsonl', 'a', encoding='utf-8') as stream:
                    stream.write(line + '\n')
                if important(event):
                    # Owner's decision 2026-11-25: blocks, stops and critical findings are also kept apart,
                    # so routine records never push them out of the panel. Önemli kayıtlar ayrıca tutulur.
                    with open(self.directory / IMPORTANT, 'a', encoding='utf-8') as stream:
                        stream.write(line + '\n')
            except OSError:
                pass
        return event

    def start_sysmon_lane(self, stopped, every=1.0):
        """Read Sysmon every second in its own thread, apart from the slower checks (owner's proof 2026-11-24).

        A minute's PowerShell checks (firewall, hardening, devices...) delayed Sysmon events by
        tens of seconds, so a build tool kept running. The memory scanner is shared, so both
        lanes take the same lock. Sysmon kendi iş parçacığında saniyede bir okunur.
        """
        import threading
        self.sysmon_lane = True

        def lane():
            while not stopped(every):
                try:
                    self.check_sysmon()
                except Exception as exc:  # recorded; the lane goes on
                    self.record('sysmon_lane_error', error=type(exc).__name__ + ': ' + str(exc)[:300])
        thread = threading.Thread(target=lane, name='satsuma-sysmon', daemon=True)
        thread.start()
        return thread

    def start(self):
        """Close 853, lock DNS and refuse incoming connections; every outcome is recorded."""
        self.startup['important_backfill'] = backfill_important(self.directory)
        # Owner's machine 2026-11-25: ended from Task Manager, nothing was written. How did the last run end?
        # Önceki çalışma durdurma kaydı olmadan mı bitti?
        try:
            from .liveness import Liveness
            self.liveness = Liveness(self.directory, self.record, clock=self.clock)
            self.liveness.check_previous()
        except Exception as exc:  # reported, never fatal
            self.liveness = None
            self.record('startup_liveness', ok=False, error=type(exc).__name__ + ': ' + str(exc)[:300])
        # First of all: Windows' own process audit, so every later launch has its 4688 witness.
        # Önce Windows'un süreç denetimi: sonraki her başlatmanın 4688 tanığı olsun.
        self.startup['process_audit'] = self.check_process_audit(force=True)
        for name, step in (('state_dir_lock', self.lock_state_dir),
                           ('machine_key', self.load_machine_key),
                           ('port_853', lambda: firewall.close_port_853(self.runner)),
                           ('dns_lock', lambda: dns.lock(self.runner)),
                           ('inbound_lock', lambda: inbound.lock(self.runner)),
                           ('browser_policy', self.start_browser),
                           ('hardening', self.start_hardening)):
            try:
                result = step()
            except (firewall.FirewallError, ValueError, OSError, ImportError) as exc:
                result = {'ok': False, 'status': 'ERROR', 'error': str(exc)[:300]}
            ok = result.get('ok', result.get('status') in ('closed', 'LOCKED'))
            self.startup[name] = {**result, 'ok': bool(ok)}
            self.record('startup_' + name, **self.startup[name])
        self.inbound_at = self.browser_at = self.hardening_at = self.clock()
        self.startup['install_consent'] = self.check_install_consent()
        self.startup['owner_password'] = self.start_owner_password()
        self.startup['firmware'] = self.check_firmware(force=True)
        self.startup['accounts'] = self.check_accounts(force=True) or {'ok': False, 'status': 'NOT_CHECKED'}
        self.startup['firewall_auto'] = self.start_firewall()
        self.record('startup_firewall_auto', **self.startup['firewall_auto'])
        try:
            self.otx = self.otx_factory(self.directory, self.record, self.block_address, self.protected)
        except Exception as exc:  # reported; the rest of the guard keeps running
            self.record('startup_otx', ok=False, error=type(exc).__name__ + ': ' + str(exc)[:300])
        self.startup['certificates'] = self.start_certs()
        self.record('startup_certificates', **self.startup['certificates'])
        self.startup['gateway'] = self.start_gateway()
        self.record('startup_gateway', **self.startup['gateway'])
        self.startup['memory'] = self.start_memory()
        self.record('startup_memory', **self.startup['memory'])
        self.startup['rules'] = self.start_rules()
        self.record('startup_rules', **self.startup['rules'])
        self.startup['sysmon'] = self.start_sysmon()
        self.record('startup_sysmon', **self.startup['sysmon'])
        self.startup['suricata'] = self.start_suricata()
        self.record('startup_suricata', **self.startup['suricata'])
        self.startup['ram_v2_removed'] = self.remove_ram_v2()
        self.record('startup_ram_v2_removed', **self.startup['ram_v2_removed'])
        return self.startup

    def start_suricata(self):
        """Start Suricata inline (WinDivert) if installed; otherwise the service installs it itself.

        Kuruluysa Suricata'yı satır içi başlatır; değilse hizmet kendisi kurar.
        """
        try:
            self.suricata = self.suricata_factory(self.directory, self.record)
            started = self.suricata.start()
            if started.get('ok') and getattr(sys, 'frozen', False):
                from . import suricata as suricata_module
                try:
                    self.record('suricata_old_folders', **suricata_module.cleanup_old(self.directory))
                except OSError as exc:  # reported; the engine keeps running
                    self.record('suricata_old_folders', ok=False, error=str(exc)[:300])
            return started
        except Exception as exc:  # reported; check_suricata tries again
            return {'ok': False, 'status': 'ERROR', 'error': type(exc).__name__ + ': ' + str(exc)[:300]}

    def check_suricata(self):
        if self.suricata is None:
            return []
        try:
            return self.suricata.check()
        except Exception as exc:  # recorded; the guard keeps running
            return [self.record('suricata_error', error=type(exc).__name__ + ': ' + str(exc)[:300])]

    def remove_ram_v2(self):
        """Stop a leftover clamd of the retired RAM v2 and delete its folders (satsuma_win.retired).

        Kaldırılan RAM v2'nin artakalan clamd'sini durdurur, klasörlerini siler.
        """
        try:
            return self.retire(self.directory)
        except Exception as exc:  # reported in startup_ram_v2_removed; the rest of the guard keeps running
            return {'ok': False, 'status': 'ERROR', 'error': type(exc).__name__ + ': ' + str(exc)[:300]}

    def stop(self):
        """Nothing runs beside the poll loop any more; kept for the service and --once.

        Döngü dışında çalışan bir şey kalmadı; hizmet ve --once için durur.
        """
        if self.suricata is not None:
            self.suricata.stop()

    def start_gateway(self):
        """Load the approved modem; at the first start (installation) approve the one seen now.

        Onaylı modemi yükler; ilk açılışta (kurulum) o an görüleni onaylar.
        """
        if self.key is None:
            return {'ok': False, 'status': 'NO_MACHINE_KEY'}
        try:
            self.gateway = self.gateway_factory(self.directory, self.key, self.runner, self.record, self.clock)
            approved = self.gateway.load()
            status = 'LOADED'
            if approved is None and self.key_created:
                approved, status = self.gateway.approve_now(), 'APPROVED_AT_INSTALL'
        except Exception as exc:  # reported; without an approved modem the MITM guard cannot compare
            return {'ok': False, 'status': 'ERROR', 'error': type(exc).__name__ + ': ' + str(exc)[:300]}
        if approved is None:
            return {'ok': False, 'status': 'NOT_APPROVED'}
        return {'ok': True, 'status': status, **approved}

    def check_accounts(self, force=False):
        """Every minute: only the owner may log on; other accounts are denied by policy (owner's decision).

        Dakikada bir: yalnızca sahip oturum açabilir; diğer hesaplar ilkeyle reddedilir.
        """
        now = self.clock()
        if not force and self.accounts_at is not None and now - self.accounts_at < ACCOUNTS_EVERY:
            return None
        self.accounts_at = now
        try:
            if self.accounts is None:
                self.accounts = self.accounts_factory(self.directory, self.key, self.runner, self.record)
            state = self.accounts.enforce()
        except Exception as exc:  # recorded; checked again next minute
            state = {'ok': False, 'status': 'ERROR', 'error': type(exc).__name__ + ': ' + str(exc)[:300]}
        if force or not state.get('ok') or state.get('status') == 'WRITTEN' or state.get('disabled'):
            self.record('startup_accounts' if force else 'accounts_' + state.get('status', 'ERROR').lower(), **state)
        if state.get('disabled') and not force:
            # An account other than the owner was enabled (or created): it was disabled at once.
            # Sahip dışında bir hesap açılmış ya da oluşturulmuş: hemen kapatıldı.
            self.record('account_enabled_disabled_again', severity='critical', accounts=state['disabled'],
                        owner=state.get('owner'))
        return state

    def check_devices(self):
        """Every minute: disable the devices the owner does not allow (owner's decision 2026-11-11)."""
        now = self.clock()
        if self.devices_at is not None and now - self.devices_at < ACCOUNTS_EVERY:
            return []
        self.devices_at = now
        try:
            if self.devices is None:
                self.devices = self.devices_factory(self.directory, self.key, self.runner, self.record)
            return self.devices.check()
        except Exception as exc:  # recorded; checked again next minute
            return [self.record('devices_unreadable', error=type(exc).__name__ + ': ' + str(exc)[:300])]

    def check_gateway(self):
        return self.gateway.check() if self.gateway is not None else []

    def start_rules(self):
        """Load the Windows rules (satsuma_win.rules); a failure is reported, never hidden.

        Windows kurallarını yükler; başarısızlık gizlenmez, bildirilir.
        """
        try:
            # DeepSeek rules (satsuma_win.ai_rules) load beside the bundled ones, only when signed.
            # DeepSeek kuralları paketli kuralların yanında, yalnızca imzalıysa yüklenir.
            self.ai = self.ai_factory(self.directory, self.key, self.record,
                                      existing=lambda: [c['rule'] for c in (self.rules.rules if self.rules else ())
                                                        if c['origin'] == 'bundled'])
            from . import owner_requests
            try:
                self.ai.gate = self.gate if self.gate is not None else owner_requests.CLOSED
            except AttributeError:
                pass
        except Exception as exc:  # reported; the bundled rules still load
            self.ai = None
            self.record('startup_deepseek', ok=False, status='ERROR', error=type(exc).__name__ + ': ' + str(exc)[:300])
        try:
            self.rules = self.rules_factory(self.directory, self.ai.active_rules if self.ai else (lambda: ()))
        except Exception as exc:  # reported in startup_rules; the rest of the guard keeps running
            self.rules = None
            return {'ok': False, 'status': 'ERROR', 'error': type(exc).__name__ + ': ' + str(exc)[:300]}
        stats = self.rules.stats()
        if self.ai is not None:
            self.record('startup_deepseek', ok=True, **self.ai.status())
        bundled_errors = [e for e in stats['load_errors'] if e.get('file') != 'deepseek' and not str(e.get('file', '')).startswith('SATSUMA-AI-')]
        return {'ok': stats['by_origin'].get('bundled', 0) > 0 and not bundled_errors, 'status': 'LOADED', **stats}

    def check_ai(self):
        """Once per poll: DeepSeek requests and automatic fetching; reload the rules when one changed."""
        if self.ai is None or self.rules is None:
            return None
        try:
            changed = self.ai.tick()
        except Exception as exc:  # recorded; the guard keeps running
            self.record('deepseek_error', error=type(exc).__name__ + ': ' + str(exc)[:300])
            return None
        for alarm in self.rules.take_alarms():
            self.record('deepseek_rule_suspended', alarm='critical', **{k: v for k, v in alarm.items() if k != 'timestamp'})
        if changed:
            stats = self.rules.reload()
            self.record('rules_reloaded', **stats)
            return stats
        return None

    def apply_rules(self, event):
        """Match one Sysmon event; stop what the shared decision stops, record every finding.

        Bir Sysmon olayını eşler; ortak kararın durdurduğunu durdurur, her bulguyu kaydeder.
        """
        if self.rules is None:
            return []
        from . import sysmon
        results, now = [], self.clock()
        for finding in self.rules.match(event):
            key = (finding['rule_id'], finding.get('pid'), finding.get('image'))
            if now - self.rule_seen.get(key, -1e9) < RULE_REPEAT_EVERY:
                continue
            self.rule_seen[key] = now
            if len(self.rule_seen) > 20000:
                self.rule_seen.clear()
            self.counts['rule_findings'] += 1
            if not finding.pop('stop'):
                results.append(self.record('rule_finding', outcome='recorded', **finding))
                continue
            if self.rule_allowed(finding):
                results.append(self.record('rule_finding', outcome='allowed_by_owner', **finding))
                continue
            block = self.rule_stop_block(finding)
            if block:
                self.counts['rule_not_stopped'] += 1
                results.append(self.record('rule_finding', outcome='not_stopped', not_stopped=block, **finding))
                continue
            try:
                outcome = self.memory.reader.stop_if_image(int(finding['pid']), finding['image'],
                                                         not_after=sysmon.event_filetime(event))
            except (AttributeError, KeyError, ValueError, OSError) as exc:
                self.counts['rule_stop_failed'] += 1
                results.append(self.record('rule_finding', outcome='stop_failed', error=str(exc)[:300], **finding))
                continue
            if outcome == 'stopped':
                self.counts['rule_stopped'] += 1
                self.rule_stopped(finding)
            results.append(self.record('rule_finding', outcome=outcome, **finding))
        return results

    def rule_stop_block(self, finding):
        """Why this finding may not stop its process, or None. Neden durdurulamaz ya da None."""
        try:
            pid = int(finding.get('pid') or 0)
        except ValueError:
            return 'pid_unknown'
        if pid <= 4 or pid == os.getpid():
            return 'protected_process'
        if not self.memory_enforce():
            return 'report_mode'
        if self.ai is not None and finding.get('origin') == 'deepseek':
            return self.ai.stop_block(finding, self.rules.compiled(finding['rule_id']))
        return None

    def rule_stopped(self, finding):
        """Called after a stop; DeepSeek rules count it against their limit."""
        if self.ai is not None:
            self.ai.count_stop(finding)

    def memory_enforce(self):
        return self.memory is None or getattr(self.memory, 'enforce', True)

    def start_sysmon(self):
        """Open the Sysmon event channel; without Sysmon the guard keeps running and says so."""
        try:
            self.sysmon = self.sysmon_factory()
            # The first read's events are kept for check_sysmon, never thrown away: they are the programs
            # started while the service was starting (owner's proof 2026-11-24).
            # İlk okumanın olayları atılmaz; hizmet açılırken başlayan programlardır.
            self.sysmon_pending = list(self.sysmon.read() or [])
        except Exception as exc:  # reported in startup_sysmon: process monitoring is off until it is fixed
            self.sysmon = None
            return {'ok': False, 'status': 'UNAVAILABLE', 'error': type(exc).__name__ + ': ' + str(exc)[:300]}
        return {'ok': True, 'status': 'READING'}

    def check_sysmon(self):
        """New Sysmon events: stop build tools, memory scan the processes the events point at."""
        from satsuma import build_tools
        from . import sysmon
        if self.sysmon is None:
            now = self.clock()
            if self.sysmon_at is None or now - self.sysmon_at >= SYSMON_RETRY_EVERY:
                self.sysmon_at = now
                state = self.start_sysmon()
                if state['ok']:
                    self.record('sysmon_available', **state)
                elif self.sysmon_install_at is None or now - self.sysmon_install_at >= SYSMON_INSTALL_EVERY:
                    # Satsuma installs what it needs by itself (owner's rule); the reason is recorded.
                    # Satsuma gerekeni kendisi kurar; neden kaydedilir.
                    self.sysmon_install_at = now
                    try:
                        result = self.sysmon_installer()
                    except Exception as exc:  # recorded; tried again in ten minutes
                        result = {'ok': False, 'status': 'ERROR', 'error': type(exc).__name__ + ': ' + str(exc)[:300]}
                    self.record('sysmon_install', **result)
            return []
        try:
            events = list(getattr(self, 'sysmon_pending', None) or []) + list(self.sysmon.read() or [])
            self.sysmon_pending = []
            resets = getattr(self.sysmon, 'resets', 0)
            if resets != getattr(self, 'sysmon_resets', 0):
                self.sysmon_resets = resets
                self.record('sysmon_log_replaced', severity='high', resets=resets,
                            note='Sysmon günlüğü silindi ya da yeniden kuruldu; okuma baştan başladı')
        except Exception as exc:  # a broken read is recorded; the next poll tries again
            self.record('sysmon_unreadable', error=type(exc).__name__ + ': ' + str(exc)[:300])
            return []
        self.counts['sysmon_events'] += len(events)
        results, scan = [], {}
        recent = self.__dict__.setdefault('scan_recent', {})   # {pid: when its memory was last scanned}
        scan_now = self.clock()
        own = str(sys.executable).lower()
        lineage = self.own_lineage() if self.confirm_own_child is None else None
        if lineage is not None:
            # Creation records first: an access record often comes before its target's creation.
            for event in events:
                if event['id'] == 1:
                    lineage.note(event)
        for event in events:
            # Satsuma's own process access (its memory reading) is never a finding and never a reason to scan
            # again: that loop filled Sysmon and delayed every other event (owner's machine 2026-11-24).
            # Satsuma'nın kendi süreç erişimi bulgu değildir ve yeniden tarama nedeni değildir.
            if event['id'] == 10 and str(event.get('SourceImage') or '').lower() in (own, ) + OWN_IMAGES:
                access = str(event.get('GrantedAccess') or '').lower()
                if access in sysmon.OWN_ACCESS:
                    continue
                # A full-access handle to a child Satsuma itself just started, confirmed against the service
                # manager and Satsuma's own list of started children (owner's rule 2026-11-24).
                # Satsuma'nın kendi başlattığı çocuk: hizmet yöneticisi ve başlatılanlar listesiyle doğrulanır.
                reason = lineage.decide(event) if lineage is not None else self.confirm_own_child(event)
                if reason != 'wait':
                    results.extend(self._own_access(event, access, reason))
            try:
                results.extend(self.apply_rules(event))
            except Exception as exc:  # one bad event never hides the build tool check or the rest of the batch
                results.append(self.record('rule_engine_error', error=type(exc).__name__ + ': ' + str(exc)[:200]))
            if event['id'] == 1 and build_tools.tool_name(event.get('Image'), windows=True):
                results.append(self.stop_build_tool(event, build_tools))
            if event['id'] in sysmon.SCAN_EVENTS:
                busy = event['id'] in sysmon.BUSY_EVENTS
                sysmon.add_targets(scan, event, {pid for pid, at in recent.items()
                                                 if scan_now - at < sysmon.SCAN_COOLDOWN} if busy else ())
            if event['id'] == 25:
                results.append(self.record('process_tampering', pid=event.get('ProcessId'),
                                           image=event.get('Image'), type=event.get('Type')))
        if lineage is not None:
            for event, reason in lineage.due():
                results.extend(self._own_access(event, str(event.get('GrantedAccess') or '').lower(), reason))
        if scan and self.memory is not None:
            # Only the shared memory scanner is locked; reading Sysmon and stopping build tools never wait for it.
            # Yalnızca ortak bellek tarayıcısı kilitlenir; Sysmon okuma ve derleme aracı durdurma onu beklemez.
            with self.scan_lock:
                results.extend(self.memory.scan(sorted(scan), not_after=scan))
            recent.update(dict.fromkeys(scan, scan_now))
            if len(recent) > 5000:
                for pid in [p for p, at in recent.items() if scan_now - at >= sysmon.SCAN_COOLDOWN]:
                    del recent[pid]
        return results

    def stop_build_tool(self, event, build_tools):
        from . import sysmon
        try:
            running = self.pm_running()
        except Exception:  # an unreadable process list never skips the decision; Windows Installer unknown = not running
            running = None
        decision = build_tools.decide(event.get('Image'), bool(running), windows=True)
        if running:
            decision = {**decision, 'package_manager': running if isinstance(running, str) else True}
        fields = {**decision, 'pid': event.get('ProcessId'), 'parent': event.get('ParentImage'),
                  'command': (event.get('CommandLine') or '')[:500]}
        if not decision['stop']:
            self.counts['build_tool_allowed'] += 1
            return self.record('build_tool_allowed', **fields)
        try:
            outcome = self.memory.reader.stop_if_image(int(event['ProcessId']), event['Image'],
                                                         not_after=sysmon.event_filetime(event))
        except (AttributeError, KeyError, ValueError, OSError) as exc:
            self.counts['build_tool_stop_failed'] += 1
            return self.record('build_tool_stop_failed', error=str(exc)[:300], **fields)
        if outcome == 'stopped':
            self.counts['build_tool_stopped'] += 1
        return self.record('build_tool_stopped' if outcome == 'stopped' else 'build_tool_' + outcome, **fields)

    def lock_state_dir(self):
        """Only SYSTEM and Administrators may write the records and the setup approvals.

        Kayıtları ve kurulum onaylarını yalnızca SYSTEM ve Yöneticiler yazabilir.
        """
        self.directory.mkdir(parents=True, exist_ok=True)
        result = self.runner(['icacls', str(self.directory), '/inheritance:r', '/grant:r',
                              '*S-1-5-18:(OI)(CI)F', '*S-1-5-32-544:(OI)(CI)F'],
                             capture_output=True, text=True, timeout=60)
        ok = result.returncode == 0
        return {'ok': ok, 'status': 'LOCKED' if ok else 'OPEN',
                **({} if ok else {'error': (result.stderr or result.stdout or '')[:300]})}

    def load_machine_key(self):
        """Create this computer's Satsuma key the first time (during installation), then load it."""
        try:
            self.key, created = self.key_loader(self.directory)
            self.key_created = created
        except Exception as exc:  # reported; without the key no setup approval is accepted
            self.key = None
            return {'ok': False, 'status': 'ERROR', 'error': type(exc).__name__ + ': ' + str(exc)[:300]}
        fingerprint = __import__('hashlib').sha256(self.key.public_bytes).hexdigest()[:16]
        from . import memory
        try:
            approvals = memory.apply_install_approvals(self.directory, self.key, created)
        except (OSError, ValueError) as exc:
            approvals = {'error': str(exc)[:300]}
        result = {'ok': True, 'status': 'CREATED' if created else 'LOADED', 'fingerprint': fingerprint}
        if getattr(self.key, 'replaced', None):
            result['replaced_unreadable_key'] = self.key.replaced
        if approvals is not None:
            result['install_approvals'] = approvals
        return result

    def _own_access(self, event, access, reason):
        if reason is None:
            self.counts['own_child_confirmed'] = self.counts.get('own_child_confirmed', 0) + 1
            return []
        # Satsuma asked another process for more than reading or stopping, not confirmed as its own launch.
        # Satsuma başka bir süreçten okuma ya da durdurmadan fazlasını istedi ve kendi başlatması doğrulanmadı.
        return [self.record('satsuma_unexpected_access', severity='critical', access=access,
                            source=event.get('SourceImage'), target=event.get('TargetImage'),
                            target_pid=event.get('TargetProcessId'), source_pid=event.get('SourceProcessId'),
                            source_guid=event.get('SourceProcessGUID'), target_guid=event.get('TargetProcessGUID'),
                            reason=reason)]

    def own_lineage(self):
        if self.lineage is None:
            from . import lineage as lineage_module, upgrade
            folder = upgrade.install_dir()
            cache = {'at': None, 'files': {}}

            def installed():
                if cache['at'] is None or self.clock() - cache['at'] > 3600:
                    files = {}
                    for name in upgrade.EXES:
                        try:
                            files[str(folder / name).lower()] = lineage_module.file_sha256(folder / name)
                        except OSError:
                            pass
                    cache.update(at=self.clock(), files=files)
                return cache['files']

            def approved():
                builds, _ = upgrade._load_consents(self.directory, self.key) if self.key is not None else ({}, None)
                return {d for exe, entry in builds.items() for d in (exe, (entry or {}).get('panel')) if d}

            self.lineage = lineage_module.Lineage(self.directory, self.key, self.clock, approved=approved,
                                                  installed=installed, service_pid=lineage_module.service_pid,
                                                  started=lineage_module.own_start())
        return self.lineage

    def check_process_audit(self, force=False):
        """Windows' own process-creation audit (4688) stays on: the second witness of Satsuma's launches.
        Windows'un süreç oluşturma denetimi açık kalır: Satsuma'nın başlattıklarının ikinci tanığı."""
        now = self.clock()
        if not force and self.audit_at is not None and now - self.audit_at < 3600:
            return None
        self.audit_at = now
        from . import lineage as lineage_module
        try:
            result = lineage_module.enable_process_audit(self.runner)
        except Exception as exc:  # recorded; tried again in an hour
            result = {'ok': False, 'status': 'ERROR', 'detail': type(exc).__name__ + ': ' + str(exc)[:200]}
        if not result['ok']:
            self.record('process_audit_off', severity='high', **result)
        return result

    def check_firmware(self, force=False):
        """BIOS, TPM and boot measurements against the signed baseline (owner's rule 2026-11-25).
        BIOS, TPM ve önyükleme ölçümleri imzalı taban çizgisiyle karşılaştırılır."""
        from . import firmware
        try:
            if self.firmware is None:
                self.firmware = firmware.Watch(self.directory, self.key, self.record, self.clock,
                                               reader=self.firmware_reader or firmware.read)
            event = self.firmware.check(force=force)
        except Exception as exc:  # recorded; checked again in an hour
            event = self.record('firmware_unreadable', severity='high', error=type(exc).__name__ + ': ' + str(exc)[:200])
        kind = (event or {}).get('kind')
        return {'ok': kind in (None, 'firmware_baseline_taken'), 'status': kind or 'UNCHANGED'}

    def _approve_firmware(self, seen):
        from . import firmware
        if self.firmware is None:
            self.firmware = firmware.Watch(self.directory, self.key, self.record, self.clock,
                                           reader=self.firmware_reader or firmware.read)
        return self.firmware.approve(seen)

    def check_install_consent(self):
        """Owner's rule 2026-11-24: Satsuma records at every start whether it was installed with
        "onaylıyorum"; otherwise a critical record. Satsuma her açılışta onaylı mı onaysız mı başladığını yazar."""
        from . import upgrade
        folder = upgrade.install_dir()
        current = {name: upgrade._digest(folder / name) for name in upgrade.EXES}
        try:
            kind, fields = upgrade.settle_consent(self.directory, self.key, current, self.clock)
        except (OSError, ValueError, TypeError) as exc:
            kind, fields = 'satsuma_started_unapproved', {'severity': 'critical', 'reason': 'onay denetlenemedi: ' + str(exc)[:200]}
        self.record(kind, **fields)
        return {'ok': kind == 'satsuma_started_approved', 'status': kind, 'reason': fields.get('reason')}

    def start_memory(self):
        """Load the shared memory rules and open the reader; a failure is reported, never hidden."""
        try:
            self.memory = self.memory_factory(self.record, self.directory, lambda: self.key)
        except Exception as exc:  # reported in startup_memory; the network guard keeps running
            self.memory = None
            return {'ok': False, 'status': 'ERROR', 'error': type(exc).__name__ + ': ' + str(exc)[:300]}
        return {'ok': True, 'status': 'ACTIVE', 'enforce': self.memory.enforce,
                'debug_privilege': getattr(self.memory.reader, 'debug_privilege', None)}

    def check_memory(self):
        """Every MEMORY_EVERY seconds: read every process and stop what the shared rules stop."""
        now = self.clock()
        if self.memory is None or (self.memory_at is not None and now - self.memory_at < MEMORY_EVERY):
            return []
        self.memory_at = now
        return self.memory.scan()

    def start_browser(self):
        """Lock the browsers to Satsuma's policies (satsuma_win.browser). Tarayıcıları ilkelere kilitler."""
        self.browser = self.browser_factory(self.directory)
        return self.browser.apply()

    def start_hardening(self):
        """MITM paths closed, .NET and PowerShell tightened (satsuma_win.hardening)."""
        self.hardening = self.hardening_factory(self.directory)
        result = self.hardening.apply()
        ps2 = self.hardening.check_ps2(force=True)
        return {**result, 'powershell_v2': ps2}

    def check_hardening(self):
        """Every minute: write back a hardening setting someone changed; once a day: PowerShell 2.0.

        Dakikada bir: değiştirilen sıkılaştırma ayarı geri yazılır; günde bir: PowerShell 2.0.
        """
        now = self.clock()
        if self.hardening is None or (self.hardening_at is not None and now - self.hardening_at < INBOUND_EVERY):
            return None
        self.hardening_at = now
        try:
            ps2 = self.hardening.check_ps2()
            if ps2 is not None and (ps2.get('removed') or not ps2.get('ok')):
                self.record('powershell_v2', **ps2)
            state = self.hardening.status()
            if state['ok']:
                return state
            self.counts['hardening_changed'] += 1
            restored = self.hardening.apply()
            if restored['ok']:
                self.counts['hardening_restored'] += 1
            return self.record('hardening_changed', differs=(state['differs'] + state['live'])[:20],
                               restored=restored['ok'], still_differs=restored['left'][:20])
        except (OSError, ValueError) as exc:
            return self.record('hardening_unreadable', error=str(exc)[:300])

    def after_block(self, ip, reason, **extra):
        """After a block: end the open connections to ``ip`` and keep the block in the signed list.

        Engelden sonra: adrese açık bağlantılar sonlandırılır, engel imzalı listeye eklenir.
        """
        fields = {}
        try:
            ended = self.connkill(ip)
            self.counts['connections_ended'] += len(ended.get('ended') or [])
            fields['connections_ended'] = len(ended.get('ended') or [])
            if ended.get('failed'):
                fields['connections_not_ended'] = ended['failed'][:10]
        except Exception as exc:  # recorded with the block; the firewall rule already stands
            fields['connection_kill_error'] = type(exc).__name__ + ': ' + str(exc)[:200]
        if self.fw is not None:
            try:
                fields['kept'] = self.fw.add(ip, reason, **extra)
            except OSError as exc:
                fields['kept_error'] = str(exc)[:200]
        return fields

    def block_address(self, ip, reason, **extra):
        """Block one address for another module (OTX): firewall, end the connections, keep it."""
        why = self.protected(ip)
        if why:
            return self.record('block_skipped', ip=ip, rule=reason, reason=why, **extra)
        try:
            result = firewall.block_ip(ip, reason, self.runner)
        except (firewall.FirewallError, ValueError) as exc:
            self.counts['block_failed'] += 1
            return self.record('block_failed', ip=ip, rule=reason, error=str(exc)[:300], **extra)
        self.counts['blocked'] += 1
        if reason == 'otx':
            self.counts['otx_blocked'] += 1
        return self.record('blocked', ip=ip, rule=reason, firewall=result, **extra, **self.after_block(ip, reason, **extra))

    def start_firewall(self):
        """Windows Firewall baseline and the signed block list (satsuma_win.fwauto)."""
        try:
            self.fw = self.fw_factory(self.directory, self.key, self.record, self.runner)
            result = self.fw.baseline()
            result['restored'] = len(self.fw.restore_blocks())
            return result
        except Exception as exc:  # reported; checked again in a minute
            return {'ok': False, 'status': 'ERROR', 'error': type(exc).__name__ + ': ' + str(exc)[:300]}

    def check_firewall(self):
        now = self.clock()
        if self.fw is None or (self.fw_at is not None and now - self.fw_at < INBOUND_EVERY):
            return None
        self.fw_at = now
        try:
            if not self.fw.baseline_ok():
                result = self.fw.baseline()
                self.record('firewall_baseline_changed', restored=result['ok'])
            self.fw.restore_blocks()
        except Exception as exc:  # recorded; checked again in a minute
            self.record('firewall_auto_unreadable', error=type(exc).__name__ + ': ' + str(exc)[:300])

    def check_integrity(self):
        """Every five minutes: Satsuma's own exes in Program Files against their signed digests.

        The baseline is signed with the machine key from the installer's manifest when the running
        service exe matches it (each re-signing is recorded). A changed exe, or a service running from
        outside Program Files, is a critical record (owner's approval 2026-11-24).
        Satsuma'nın kendi exe'leri imzalı özetlerine karşı 5 dakikada bir denetlenir.
        """
        from . import upgrade
        now = self.clock()
        if self.key is None or (self.integrity_at is not None and now - self.integrity_at < INTEGRITY_EVERY):
            return None
        self.integrity_at = now
        folder = upgrade.install_dir()
        path = self.directory / 'self-integrity.json'
        try:
            stored = json.loads(path.read_text(encoding='utf-8'))
            rows = stored['rows'] if self.key.verify(json.dumps(stored['rows'], sort_keys=True).encode(), stored['signature']) else None
        except (OSError, ValueError, KeyError, TypeError):
            rows = None
        manifest = upgrade.load_manifest(self.directory) or {}
        running = str(sys.executable).lower()
        if getattr(sys, 'frozen', False) and not running.startswith(str(folder).lower() + os.sep):
            return self.record('satsuma_tampered', severity='critical', reason='service_outside_program_files', exe=running)
        current = {name: upgrade._digest(folder / name) for name in upgrade.EXES}
        wanted = {'satsuma-core-windows.exe': manifest.get('exe'), 'satsuma-panel.exe': manifest.get('panel')}
        if rows is None or (rows != wanted and current == wanted and wanted['satsuma-core-windows.exe']):
            if wanted['satsuma-core-windows.exe'] and current['satsuma-core-windows.exe'] == wanted['satsuma-core-windows.exe']:
                body = json.dumps(wanted, sort_keys=True).encode()
                path.write_text(json.dumps({'rows': wanted, 'signature': self.key.sign(body)}), encoding='utf-8')
                return self.record('satsuma_integrity_baseline', exes=wanted)
            return None
        changed = [name for name in upgrade.EXES if rows.get(name) and current.get(name) != rows.get(name)]
        if not changed:
            return None
        # B5 (owner's approval 2026-11-25): an install that copied only some exes (the panel was open, say) is one
        # clear critical record, not a 'tampered' alarm every five minutes. Any finding is recorded once per state.
        # Yarım kalan kurulum tek ve açık bir kayıttır; her durum yalnız bir kez kaydedilir.
        state = tuple(sorted(current.items()))
        seen = getattr(self, '_integrity_seen', set())
        self._integrity_seen = seen
        if state in seen:
            return None
        seen.add(state)
        # A new install wrote a new manifest (wanted differs from the signed baseline) but not every exe got copied.
        partial = rows != wanted and wanted['satsuma-core-windows.exe'] and any(current.get(n) == wanted.get(n) for n in upgrade.EXES) \
            and any(current.get(n) != wanted.get(n) for n in upgrade.EXES)
        if partial:
            missing = [n for n in upgrade.EXES if current.get(n) != wanted.get(n)]
            return self.record('install_incomplete', severity='critical', alarm='critical', exes=missing,
                               expected={n: wanted.get(n) for n in missing}, found={n: current.get(n) for n in missing},
                               reason='kurulum yarım kaldı: bu dosyalar yeni sürümle değiştirilemedi; kurulumu yeniden çalıştırın '
                                      'ya da önceki sürüme dönün')
        return self.record('satsuma_tampered', severity='critical', reason='exe_changed', exes=changed,
                           expected={n: rows.get(n) for n in changed}, found={n: current.get(n) for n in changed})

    # Owner's request 2026-11-25: from the panel's stopped list, allow one program (path + SHA-256 of the file
    # now on disk) for one rule; signed by the machine key. Bir programa bir kural için izin (yol + SHA-256).
    RULE_ALLOW = 'rule-allow.json'

    def _rule_allow_rows(self):
        try:
            data = json.loads((self.directory / self.RULE_ALLOW).read_text(encoding='utf-8'))
            if self.key is not None and self.key.verify(canonical_rows(data['rows']), data['signature']):
                return [r for r in data['rows'] if isinstance(r, dict)]
        except (OSError, ValueError, KeyError, TypeError):
            pass
        return []

    def allow_rule_process(self, rule_id, image):
        from . import upgrade
        path = Path(image)
        if not path.is_file():
            return {'ok': False, 'error': 'program diskte yok: ' + image}
        digest = upgrade._digest(path)
        rows = [r for r in self._rule_allow_rows() if not (r.get('rule_id') == rule_id and r.get('image') == image.lower())]
        rows.append({'rule_id': rule_id, 'image': image.lower(), 'sha256': digest, 'at': self.clock()})
        temporary = self.directory / (self.RULE_ALLOW + '.tmp')
        temporary.write_text(json.dumps({'rows': rows, 'signature': self.key.sign(canonical_rows(rows))}), encoding='utf-8')
        os.replace(temporary, self.directory / self.RULE_ALLOW)
        self._allow_cache = None
        return {'ok': True, 'rule_id': rule_id, 'image': image, 'sha256': digest}

    def rule_allowed(self, finding):
        rule_id, image = str(finding.get('rule_id') or ''), str(finding.get('image') or '')
        rows = [r for r in self._rule_allow_rows() if r.get('rule_id') == rule_id and r.get('image') == image.lower()]
        if not rows:
            return False
        from . import upgrade
        try:
            digest = upgrade._digest(Path(image))
        except OSError:
            return False
        return any(r.get('sha256') == digest for r in rows)

    def set_rule_mode(self, rule_id, mode):
        from .ai_rules import is_ai
        if self.ai is None or not is_ai(rule_id):
            return {'ok': False, 'error': 'yalnız DeepSeek kuralları panelden kapatılıp açılabilir'}
        self.ai.set_override(rule_id, mode)
        if self.rules is not None:
            self.record('rules_reloaded', **self.rules.reload())
        return {'ok': True, 'rule_id': rule_id, 'mode': mode}

    def net_context(self):
        """Who opened a connection (satsuma_win.netcontext); None without the Windows signature check."""
        if getattr(self, '_net_context', None) is None:
            signed = getattr(getattr(self.memory, 'reader', None), 'signed', None)
            if signed is None:
                return None
            from .netcontext import Context
            self._net_context = Context(signed)
        return self._net_context

    def defender_or_update_peer(self, ip):
        context = self.net_context()
        processes = sorted({(c.get('pid'), c.get('process')) for c in (getattr(self, 'current_connections', None) or [])
                            if c.get('remote') == ip})
        if context is not None and processes and context.defender_or_update(processes):
            return 'defender_or_windows_update'
        return None

    def start_owner_password(self):
        """The Satsuma administrator password (satsuma_win.owner_password); without it no request is applied."""
        from . import machine_key, owner_password
        try:
            self.gate = owner_password.Gate(self.directory, machine_key.dpapi_protect, machine_key.dpapi_unprotect,
                                            self.record, clock=self.clock)
            self.gate.settle()
            result = {'ok': True, 'set': owner_password.is_set(self.directory)}
        except Exception as exc:  # reported; requests are then refused
            self.gate = None
            result = {'ok': False, 'error': type(exc).__name__ + ': ' + str(exc)[:300]}
        self.record('startup_owner_password', **result)
        return result

    def check_requests(self):
        """Apply the owner's requests from the panel or the command line (satsuma_win.owner_requests)."""
        from . import owner_requests
        if not owner_requests.pending(self.directory):
            return []
        from . import devices as devices_module
        from .memory import approve_location

        def enable(device_id):
            firewall.run_powershell(devices_module.enable_script(device_id), self.runner)

        applier = owner_requests.Applier(self.directory, self.key, self.record, self.fw,
                                         lambda ip: firewall.unblock_ip(ip, self.runner), approve_location,
                                         devices_module.approve_device, enable,
                                         approve_firmware=lambda seen: self._approve_firmware(seen),
                                         gate=self.gate if self.gate is not None else owner_requests.CLOSED,
                                         allow_rule=self.allow_rule_process, rule_mode=self.set_rule_mode)
        try:
            return applier.run()
        except Exception as exc:  # recorded; the files stay for the next minute
            return [self.record('owner_request_error', error=type(exc).__name__ + ': ' + str(exc)[:300])]

    def check_otx(self, current):
        if self.otx is None:
            return []
        try:
            return self.otx.check(current)
        except Exception as exc:  # recorded; the guard keeps running
            return [self.record('otx_error', error=type(exc).__name__ + ': ' + str(exc)[:300])]

    def start_certs(self):
        """Certificate store watch (satsuma_win.certs): the signed baseline, taken at the first start."""
        try:
            self.certs = self.certs_factory(self.directory, self.key, self.record)
            return self.certs.start()
        except Exception as exc:  # reported; the rest of the guard keeps running
            self.certs = None
            return {'ok': False, 'status': 'ERROR', 'error': type(exc).__name__ + ': ' + str(exc)[:300]}

    def check_certs(self):
        now = self.clock()
        if self.certs is None or (self.certs_at is not None and now - self.certs_at < INBOUND_EVERY):
            return []
        self.certs_at = now
        try:
            return self.certs.check()
        except Exception as exc:  # recorded; checked again in a minute
            return [self.record('cert_store_unreadable', error=type(exc).__name__ + ': ' + str(exc)[:300])]

    def check_browser(self):
        """Every minute: write back a browser policy someone changed, and record it.

        Dakikada bir: biri tarayıcı ilkesini değiştirdiyse geri yazılır ve kaydedilir.
        """
        now = self.clock()
        if self.browser is None or (self.browser_at is not None and now - self.browser_at < INBOUND_EVERY):
            return None
        self.browser_at = now
        try:
            state = self.browser.status()
            if state['ok']:
                return state
            self.counts['browser_policy_changed'] += 1
            restored = self.browser.apply()
            if restored['ok']:
                self.counts['browser_policy_restored'] += 1
            return self.record('browser_policy_changed', differs=state['differs'][:20], restored=restored['ok'],
                               still_differs=restored['left'][:20])
        except (OSError, ValueError) as exc:
            return self.record('browser_policy_unreadable', error=str(exc)[:300])

    def check_inbound(self):
        """Every minute: if something reopened incoming access, write it back and record it.

        Dakikada bir: gelen erişimi yeniden açan bir değişiklik varsa geri yazılır ve kaydedilir.
        """
        now = self.clock()
        if self.inbound_at is not None and now - self.inbound_at < INBOUND_EVERY:
            return None
        self.inbound_at = now
        try:
            state = inbound.check(self.runner)
            if state['ok']:
                return state
            self.counts['inbound_changed'] += 1
            restored = inbound.lock(self.runner)
            if restored['ok']:
                self.counts['inbound_restored'] += 1
            return self.record('inbound_changed', open=state['open'], restored=restored['ok'],
                               still_open=restored['open'])
        except (firewall.FirewallError, ValueError, OSError) as exc:
            return self.record('inbound_unreadable', error=str(exc)[:300])

    def refresh_infrastructure(self):
        now = self.clock()
        if self.infrastructure_at is None or now - self.infrastructure_at >= INFRASTRUCTURE_EVERY:
            try:
                self.infrastructure = protect.infrastructure(self.runner)
                self.infrastructure_at = now
            except (firewall.FirewallError, ValueError, OSError) as exc:
                self.record('infrastructure_unreadable', error=str(exc)[:300])

    def poll(self):
        if getattr(self, 'liveness', None) is not None:
            self.liveness.beat()
        if getattr(self, 'gate', None) is not None:
            self.gate.settle()
        self.refresh_infrastructure()
        self.check_inbound()
        self.check_browser()
        self.check_hardening()
        self.check_certs()
        self.check_firewall()
        self.check_requests()
        try:
            self.check_integrity()
        except Exception as exc:  # recorded; checked again in five minutes
            self.record('integrity_unreadable', error=type(exc).__name__ + ': ' + str(exc)[:200])
        self.check_firmware()
        self.check_process_audit()
        self.check_gateway()
        self.check_accounts()
        self.check_devices()
        if not self.sysmon_lane:
            self.check_sysmon()
        with self.scan_lock:
            self.check_memory()
        self.check_ai()
        self.check_suricata()
        current = self.read()
        self.support = protect.support_peers(current)
        self.current_connections = current
        if self.otx is not None and getattr(self.otx, 'trusted_ip', None) is None:
            self.otx.trusted_ip = self.defender_or_update_peer
        self.check_otx(current)
        decisions = self.peers.poll(current) + self.subnet.poll(current)
        done = {}
        for decision in decisions:
            ip = decision['ip']
            if ip in done:
                continue
            reason = self.protected(ip)
            if reason:
                self.counts['skipped_protected'] += 1
                done[ip] = self.record('block_skipped', reason=reason, **decision)
                continue
            # Owner's choice C (2026-11-25): the PTR rule records instead of blocking only when every process on
            # the peer is a signed program from the system or program folders (Windows, Defender, browsers).
            if decision['rule'] == 'no_ptr_connection_flood' and self.net_context() is not None:
                trusted, paths = self.net_context().all_trusted(decision.get('processes') or [])
                if trusted:
                    self.counts['ptr_trusted_process'] = self.counts.get('ptr_trusted_process', 0) + 1
                    done[ip] = self.record('ptr_flood_trusted_process', images=paths, **decision)
                    continue
            try:
                result = firewall.block_ip(ip, decision['rule'], self.runner)
                self.counts['blocked'] += 1
                done[ip] = self.record('blocked', **decision, firewall=result, **self.after_block(ip, decision['rule']))
            except (firewall.FirewallError, ValueError) as exc:
                self.counts['block_failed'] += 1
                done[ip] = self.record('block_failed', error=str(exc)[:300], **decision)
        self.save_state()
        return list(done.values())

    def save_state(self):
        state = {'updated_at': self.clock(), 'startup': self.startup, 'counts': self.counts,
                 'gateway': self.gateway.counts if self.gateway else None,
                 'memory': self.memory.counts if self.memory else None,
                 'protected_infrastructure': sorted(self.infrastructure)}
        try:
            self.directory.mkdir(parents=True, exist_ok=True)
            temporary = self.directory / 'state.json.tmp'
            temporary.write_text(json.dumps(state, ensure_ascii=False, sort_keys=True), encoding='utf-8')
            os.replace(temporary, self.directory / 'state.json')
        except OSError:
            pass
        return state


def ask_owner(typed=None, sure=False, ask=None, runner=None):
    """The only authorised account, typed by the person installing (owner's rule 2026-11-24).

    Every other local account is disabled and kept disabled. If the typed account is not the one
    installing, that one is disabled too, so it must be confirmed with "evet" (or --yes).
    Tek yetkili hesap kurulumda elle yazılır; kuran hesap farklıysa "evet" ile onaylanır.
    """
    from . import accounts, service
    ask = ask or input
    runner = runner or accounts.safe_run
    name = typed if typed is not None else ask('İlk kurulum. Tek yetkili hesabın kullanıcı adı (yalnızca bu hesap açık kalacak): ')
    owner = accounts.resolve_owner(name, runner)
    installing = service.current_user_sid(runner)
    if owner['sid'] != installing and not sure:
        answer = ask('Kurulumu yapan hesap (' + installing + ') de kapatılacak. Onaylıyorsan "evet" yaz: ')
        if str(answer).strip().lower() != 'evet':
            raise ValueError('onaylanmadı: kurulumu yapan hesap kapatılmayacaktı')
    return owner


def install_approvals(args):
    """--approve-location FOLDER and --approve-file PATH, given by the wizard after the administrator password."""
    locations, files = [], []
    pairs = iter(args)
    for flag in pairs:
        value = next(pairs, None)
        if flag == '--approve-location' and value:
            locations.append(value)
        elif flag == '--approve-file' and value:
            files.append(value)
        else:
            raise ValueError('bilinmeyen kurulum seçeneği: ' + str(flag))
    return {'locations': locations, 'files': files}


def default_devices(directory, key, runner, record):
    from .devices import Devices
    return Devices(directory, key, runner, record)


def default_accounts(directory, key, runner, record):
    from .accounts import Accounts
    return Accounts(directory, key, runner, record)


def default_gateway(directory, key, runner, record, clock):
    from .gateway import Gateway
    return Gateway(directory, key, runner, record, clock)


def default_sysmon_installer():
    from . import sysmon
    return sysmon.install(sysmon_dir())


def default_sysmon_reader():
    from .sysmon import EventReader
    return EventReader()


def windows_package_manager_running():
    """Windows Installer or Windows Update is running (the 'dnf/rpm runs' of Windows)."""
    import psutil
    from .sysmon import PACKAGE_MANAGERS
    for process in psutil.process_iter(['name']):
        name = (process.info.get('name') or '').lower()
        # TrustedInstaller stays up idle for minutes after servicing; TiWorker is the servicing itself.
        # TrustedInstaller bakım sonrası dakikalarca boşta kalır; asıl bakım TiWorker'dır.
        if name not in PACKAGE_MANAGERS or name == 'trustedinstaller.exe':
            continue
        if name == 'msiexec.exe':
            # Only msiexec's command line is read; one that cannot be read is not taken as installing, so an
            # unclear case ends in a stop (psutil can raise a plain OSError, WinError 299).
            # Okunamayan msiexec kurulum sayılmaz; belirsiz durum durdurmayla biter.
            try:
                if not msiexec_working(process.cmdline()):
                    continue
            except Exception:
                continue
        return name
    return None


def msiexec_working(cmdline):
    """An msiexec that installs, removes, repairs or unpacks; not the idle Windows Installer service.

    The service (msiexec.exe /V) stays up for minutes after any MSI operation (owner's
    proof 2026-11-24: Satsuma's own Suricata unpack kept every build tool allowed).
    Kuran, kaldıran, onaran ya da açan msiexec; boşta bekleyen Windows Installer hizmeti değil.
    """
    args = [str(a).lower() for a in (cmdline or [])[1:]]
    return any(a.startswith(('/i', '/x', '/p', '/a', '/f', '/j', '/update', '/uninstall', '/package', '-i', '-x', '-p', '-a'))
               for a in args)


def default_memory_scanner(record, directory=None, key=lambda: None, enforce=True):
    from satsuma import memory_decision
    from .memory import Scanner, Win32Reader, load_approvals, load_locations
    from .rwx_inspection import Holds
    directory = Path(directory) if directory else state_dir()
    # Only the service writes holds.json; the memory report holds nothing. Yalnızca hizmet bekletir.
    # Only the memory rules Windows implements (owner's approval 2026-11-25): RAM-002/003/005 are Linux-only.
    # Yalnız Windows'un uyguladığı bellek kuralları; RAM-002/003/005 Linux'a özgü.
    windows_rules = {k: r for k, r in memory_decision.load_rules().items() if r.get('id') in WINDOWS_MEMORY_RULES}
    scanner = Scanner(windows_rules, Win32Reader(), record,
                      satsuma_exe=sys.executable if getattr(sys, 'frozen', False) else None, enforce=enforce,
                      approvals=lambda: load_approvals(directory, key()),
                      locations=lambda: load_locations(directory, key()),
                      holds=Holds(directory if enforce else None))
    if enforce:
        scanner.recover_holds()
    return scanner


def default_rules(directory=None, extra=lambda: ()):
    from .rules import Engine
    return Engine(extra=extra, satsuma_exe=sys.executable if getattr(sys, 'frozen', False) else None)


def default_suricata(directory, record):
    from .suricata import Runtime
    return Runtime(directory, record)


import threading as _threading
RECORD_LOCK = _threading.Lock()
INTEGRITY_EVERY = 300.0
OWN_IMAGES = tuple(os.path.join(os.environ.get('ProgramFiles', r'C:\Program Files'), 'Satsuma', name).lower()
                   for name in ('satsuma-core-windows.exe', 'satsuma-panel.exe'))


def default_fwauto(directory, key, record, runner):
    from .fwauto import FirewallAuto
    return FirewallAuto(directory, key, record, runner)


def default_otx(directory, record, block, protected):
    from .otx import Otx
    return Otx(directory, record, block, protected)


def default_connkill(ip):
    from . import connkill
    return connkill.kill(ip)


def default_certs(directory, key, record):
    from .certs import CertWatch
    return CertWatch(directory, key, record)


def default_hardening(directory):
    from .hardening import Hardening
    return Hardening(directory)


def default_browser(directory):
    from .browser import BrowserPolicy
    return BrowserPolicy(directory)


def default_ai(directory, key, record, existing=lambda: ()):
    from .ai_rules import AiRules
    return AiRules(directory, key, record, existing=existing)


def default_retire(directory=None):
    from . import retired
    return retired.remove(Path(directory) if directory else state_dir())


def memory_report():
    """One scan that stops nothing: what the memory rules would stop on this machine now."""
    found = []
    scanner = default_memory_scanner(lambda kind, **fields: found.append(fields) or fields, enforce=False)
    scanner.scan()
    return {'ok': True, 'counts': scanner.counts, 'debug_privilege': scanner.reader.debug_privilege,
            'findings': found}


def is_admin():
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except (AttributeError, OSError):
        return False


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    # Turkish text must reach any console or pipe; a cp1252 console cannot encode it.
    # Türkçe metin her konsola ve boruya ulaşmalı; cp1252 konsolu onu kodlayamaz.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding='utf-8', errors='replace')
        except (AttributeError, ValueError):
            pass
    if args[:1] == ['--regex-probe']:
        # The child of the DeepSeek regex check (satsuma_win.ai_rules.linear); runs nothing else.
        from .ai_rules import regex_probe_main
        return regex_probe_main()
    if not is_admin():
        print('Yönetici olarak çalıştırın (Administrator).', file=sys.stderr)
        return 1
    if args[:1] and args[0] in DEEPSEEK_COMMANDS:
        return deepseek_command(args)
    if args[:1] == ['--cert-approve']:
        return cert_command(args)
    if args[:1] in (['--approve-location'], ['--approve-device'], ['--unblock'], ['--unblock-otx']) and '--install' not in args:
        # Applied by the running service within a minute. Çalışan hizmet bir dakika içinde uygular.
        from . import owner_requests
        if args[0] == '--unblock-otx':
            name = owner_requests.write(state_dir(), password=_pw(state_dir()), action='unblock_rule', rule='otx')
        elif len(args) != 2:
            print(json.dumps({'ok': False, 'error': 'usage: ' + args[0] + ' VALUE'}))
            return 2
        else:
            action, field = {'--approve-location': ('approve_location', 'folder'), '--approve-device': ('approve_device', 'id'),
                             '--unblock': ('unblock', 'ip')}[args[0]]
            name = owner_requests.write(state_dir(), password=_pw(state_dir()), action=action, **{field: args[1]})
        print(json.dumps({'ok': True, 'status': 'SENT_TO_SERVICE', 'request': name}))
        return 0
    if args[:1] == ['--approve-firmware']:
        # Owner's rule 2026-11-25: the differences are shown, "onaylıyorum" takes the values seen.
        # Farklar gösterilir; "onaylıyorum" yalnız görülen değerleri taban çizgisi yapar.
        from . import firmware, owner_requests, upgrade
        current = firmware.read()
        if 'tpm_error' in current or 'registry_error' in current:
            print(json.dumps({'ok': False, 'error': current.get('tpm_error') or current.get('registry_error')}, ensure_ascii=False))
            return 2
        try:
            stored = json.loads((state_dir() / firmware.BASELINE).read_text(encoding='utf-8')).get('facts') or {}
        except (OSError, ValueError):
            stored = {}
        diffs = firmware.differences(stored, current)
        print('Ürün yazılımı taban çizgisine göre farklar:')
        for line in firmware.lines(diffs) or ['Fark yok; taban çizgisi şu anki değerlerle aynı.']:
            print('  - ' + line)
        answer = input('Bunları yeni taban çizgisi yapmak için "' + upgrade.CONFIRM + '" yaz (başka her şey: değişmez): ')
        if answer.strip() != upgrade.CONFIRM:
            print(json.dumps({'ok': False, 'status': 'NOT_CONFIRMED'}, ensure_ascii=False))
            return 1
        name = owner_requests.write(state_dir(), password=_pw(state_dir()), action='approve_firmware', digest=firmware.digest(current))
        print(json.dumps({'ok': True, 'status': 'SENT_TO_SERVICE', 'request': name, 'changes': firmware.lines(diffs)}, ensure_ascii=False))
        return 0
    if args[:1] == ['--otx-key']:
        from . import otx
        import getpass
        key = (getpass.getpass('OTX API anahtarı: ') if sys.stdin and sys.stdin.isatty() else sys.stdin.readline()).strip()
        if not (16 <= len(key) <= 200 and key.isalnum()):
            print(json.dumps({'ok': False, 'error': 'invalid_key'}))
            return 2
        otx.write_key_request(state_dir(), key)
        print(json.dumps({'ok': True, 'status': 'SENT_TO_SERVICE'}))
        return 0
    if args[:1] == ['--set-password']:
        # Owner's request 2026-11-25: the Satsuma administrator password (the Linux design).
        # Satsuma yönetici parolasını belirler ya da değiştirir; eski parola değişikliği imzalar.
        from . import owner_password
        try:
            old = owner_password.ask('Eski Satsuma yönetici parolası: ') if owner_password.is_set(state_dir()) else None
            new = new_password()
            owner_password.prepare(state_dir(), new, old)
        except (ValueError, OSError, EOFError, KeyboardInterrupt) as exc:
            print(json.dumps({'ok': False, 'error': str(exc)[:300]}, ensure_ascii=False))
            return 2
        print(json.dumps({'ok': True, 'status': 'SENT_TO_SERVICE',
                          'note': 'hizmet bir dakika içinde alır; sonuç kayıtta owner_password_set'}, ensure_ascii=False))
        return 0
    if args[:1] in (['--install'], ['--uninstall'], ['--status']):
        from . import service
        if args[0] == '--install':
            if not getattr(sys, 'frozen', False):
                print('Kurulum derlenmiş satsuma-core-windows.exe ile yapılır.', file=sys.stderr)
                return 2
            from . import rules as rules_module, upgrade
            rest = list(args[1:])
            typed, sure = None, '--yes' in rest  # --yes: automated test runs only (no keyboard)
            rest = [a for a in rest if a != '--yes']
            if '--owner' in rest:
                at = rest.index('--owner')
                typed = rest[at + 1] if at + 1 < len(rest) else ''
                del rest[at:at + 2]
            answer = (lambda prompt: 'evet' if 'evet' in prompt else upgrade.CONFIRM) if sure else input
            first = upgrade.owner_on_disk(state_dir()) is None
            try:
                approvals = install_approvals(rest)
                if first:
                    owner = ask_owner(typed, sure, ask=answer if sure else None)
                    approvals['owner'] = owner['sid']
                else:
                    if typed is not None:
                        raise ValueError('sahip hesabı yalnızca ilk kurulumda belirlenir; güncelleme onu değiştiremez')
                    owner = {'sid': upgrade.owner_on_disk(state_dir())}
                    problem = upgrade.owner_problem(owner['sid'], service.safe_run)
                    if problem:
                        raise ValueError('güncelleme yapılmadı, önceki sürüm devrede: ' + problem)
            except (ValueError, EOFError, KeyboardInterrupt) as exc:
                print(json.dumps({'ok': False, 'status': 'OWNER_REFUSED', 'error': str(exc)[:300]}, ensure_ascii=False))
                return 2
            # What this installation changes, and the owner's typed consent before anything is touched.
            # Bu kurulumun değiştirdikleri; hiçbir şeye dokunmadan önce sahibin yazılı onayı.
            new_manifest = upgrade.manifest(sys.executable, rules_module.rules_dir())
            listed = upgrade.changes(upgrade.load_manifest(state_dir()), new_manifest)
            print('Bu kurulumun değiştirdikleri:', file=sys.stderr)
            for line in listed:
                print('  - ' + line, file=sys.stderr)
            try:
                consent = answer('Onaylıyorsan "' + upgrade.CONFIRM + '" yaz (başka her şey: kurulmaz, önceki sürüm kalır): ')
            except (EOFError, KeyboardInterrupt):
                consent = ''
            if str(consent).strip().lower() != upgrade.CONFIRM:
                print(json.dumps({'ok': False, 'status': 'NOT_CONFIRMED', 'changes': listed,
                                  'note': 'hiçbir şey değişmedi; önceki sürüm devrede'}, ensure_ascii=False))
                return 2
            # Owner's request 2026-11-25: the Satsuma administrator password is set at the first install,
            # or at the first update that finds none. Parola ilk kurulumda (ya da hiç yoksa) belirlenir.
            from . import owner_password
            if not owner_password.is_set(state_dir()):
                try:
                    if sure and not os.environ.get('SATSUMA_OWNER_PASSWORD'):
                        print('Uyarı: Satsuma yönetici parolası belirlenmedi; --set-password ile belirleyin.', file=sys.stderr)
                    else:
                        owner_password.prepare(state_dir(), new_password())
                except (ValueError, OSError, EOFError, KeyboardInterrupt) as exc:
                    print(json.dumps({'ok': False, 'status': 'PASSWORD_NOT_SET', 'error': str(exc)[:300],
                                      'note': 'hiçbir şey değişmedi; önceki sürüm devrede'}, ensure_ascii=False))
                    return 2
            saved = [] if first else upgrade.backup()
            # The service signs this at its next start and records whether it started approved.
            # Hizmet bunu ilk açılışta imzalar ve onaylı mı onaysız mı başladığını kaydeder.
            try:
                upgrade.write_consent_request(state_dir(), sure, {'satsuma-core-windows.exe': new_manifest.get('exe'),
                                                                  'satsuma-panel.exe': new_manifest.get('panel')})
            except OSError as exc:
                # Owner's machine 2026-11-25: Controlled folder access refused the write from C:\. Said plainly.
                # Fidye koruması C:\'den yazmayı reddetti: açıkça söylenir, hiçbir şey değişmez.
                print(json.dumps({'ok': False, 'status': 'CONSENT_NOT_WRITTEN', 'error': str(exc)[:300],
                                  'hint': 'Windows Güvenliği > Fidye yazılımı koruması engellemiş olabilir; '
                                          'engelleme geçmişine bakın ya da kurulumu yeniden çalıştırın. Hiçbir şey değişmedi.'},
                                 ensure_ascii=False))
                return 1
            # Sysmon first, so the service reads its events from the first start.
            # Önce Sysmon; hizmet olaylarını ilk açılıştan itibaren okur.
            from . import retired, suricata, sysmon
            monitor = sysmon.install(sysmon_dir())
            # Suricata before the service too: it starts inline (WinDivert) at the first start.
            # Suricata da hizmetten önce: ilk açılışta satır içi (WinDivert) başlar.
            try:
                ips = suricata.install(state_dir())
            except Exception as exc:  # reported as a failed step, never hidden
                ips = {'ok': False, 'status': 'ERROR', 'error': type(exc).__name__ + ': ' + str(exc)[:300]}
            result = service.install(sys.executable, **approvals)
            result['changes'] = listed
            if not first:
                # The owner after the update must be the same signed owner and still usable; else back.
                # Güncellemeden sonra sahip aynı ve kullanılabilir olmalı; değilse önceki sürüme dönülür.
                import time as _time
                _time.sleep(5)
                after = upgrade.owner_on_disk(state_dir())
                problem = ('sahip kaydı değişti' if after != owner['sid']
                           else upgrade.owner_problem(after, service.safe_run))
                if problem:
                    result.update(ok=False, status='ROLLED_BACK', reason=problem, previous=saved,
                                  rollback=upgrade.rollback(service.safe_run))
                    # A critical record: why it was rolled back and how the update had been approved.
                    # Kritik kayıt: neden geri dönüldü ve güncelleme nasıl onaylanmıştı.
                    upgrade.record(state_dir(), 'update_rolled_back', severity='critical', reason=problem,
                                   consent=upgrade.consent_text(sure), changes=listed, restored=saved)
                    print(json.dumps(result, ensure_ascii=False))
                    return 1
            upgrade.save_manifest(state_dir(), new_manifest)
            upgrade.record(state_dir(), 'installed', first=first, consent=upgrade.consent_text(sure), changes=listed)
            result['consent'] = upgrade.consent_text(sure)
            result['owner'] = owner.get('name') or owner['sid']
            # After service.install: it stops the old service first, and with it the old clamd (RAM v2).
            # service.install'dan sonra: önce eski hizmeti, onunla eski clamd'yi (RAM v2) durdurur.
            try:
                leftover = retired.remove(state_dir())
            except Exception as exc:  # reported as a failed step, never hidden
                leftover = {'ok': False, 'status': 'ERROR', 'error': type(exc).__name__ + ': ' + str(exc)[:300]}
            result['sysmon'] = monitor
            result['suricata'] = ips
            result['ram_v2_removed'] = leftover
            result['ok'] = (bool(result.get('ok')) and bool(monitor.get('ok')) and bool(leftover.get('ok'))
                            and (bool(ips.get('ok')) or ips.get('status') == 'NPCAP_REQUIRED'))
            if ips.get('status') == 'NPCAP_REQUIRED':
                # Not a failed installation: the owner installs Npcap (its licence forbids a silent install).
                # Başarısız kurulum değil: Npcap'i sahibi kurar (lisansı sessiz kuruluma izin vermez).
                result['warnings'] = [ips['hint']]
        elif args[0] == '--uninstall':
            result = service.uninstall()
            from . import accounts, devices, gateway, retired, sysmon
            result['sysmon'] = sysmon.uninstall(sysmon_dir())
            try:
                from . import suricata
                result['suricata'] = suricata.uninstall(state_dir())
            except Exception as exc:  # reported; the service is already removed
                result['suricata'] = {'ok': False, 'error': str(exc)[:300]}
            try:
                from .hardening import Hardening
                result['hardening'] = Hardening(state_dir()).restore()
            except Exception as exc:  # reported; the service is already removed
                result['hardening'] = {'ok': False, 'error': str(exc)[:300]}
            try:
                from .browser import BrowserPolicy
                result['browser_policy'] = BrowserPolicy(state_dir()).restore()
            except Exception as exc:  # reported; the service is already removed
                result['browser_policy'] = {'ok': False, 'error': str(exc)[:300]}
            try:
                result['ram_v2_removed'] = retired.remove(state_dir())
            except Exception as exc:  # reported; the service is already removed
                result['ram_v2_removed'] = {'ok': False, 'error': str(exc)[:300]}
            try:
                result['devices'] = devices.restore(state_dir())
            except Exception as exc:  # reported; the service is already removed
                result['devices'] = {'ok': False, 'error': str(exc)[:300]}
            try:
                result['accounts'] = accounts.Accounts(state_dir(), None).restore()
            except Exception as exc:  # reported; the service is already removed
                result['accounts'] = {'ok': False, 'error': str(exc)[:300]}
            try:
                result['gateway'] = gateway.unpin(state_dir())
            except Exception as exc:  # reported; the service is already removed
                result['gateway'] = {'ok': False, 'error': str(exc)[:300]}
        else:
            result = service.status()
        print(json.dumps(result, ensure_ascii=False))
        return 0 if result.get('ok') else 1
    if args[:1] == ['--memory-report']:
        print(json.dumps(memory_report(), ensure_ascii=False))
        return 0
    if not args or args[0] not in ('--run', '--once'):
        # Double-clicking the exe must never start the guard unattended outside the service
        # (2026-11-11 on the owner's machine it ran from inside the zip). Çift tıklama bekçiyi başlatmaz.
        print(USAGE)
        if not args and sys.stdin and sys.stdin.isatty():
            try:
                input('Kapatmak için Enter tuşuna basın.')
            except EOFError:
                pass
        return 2
    guard = Guard()
    guard.start()
    if '--once' in args:
        guard.poll()
        guard.stop()
        return 0
    run_loop(guard, lambda seconds: time.sleep(seconds) or False)
    return 0


USAGE = '''Satsuma Core (Windows)

Kurulum (PowerShell yönetici olarak, exe'nin bulunduğu klasörde):
  .\\satsuma-core-windows.exe --install [--owner KULLANICI --yes] [--approve-location KLASÖR ...]
  (--owner verilmezse tek yetkili hesap adı sorulur)
Durum:     & 'C:\\Program Files\\Satsuma\\satsuma-core-windows.exe' --status
Kaldırma:  & 'C:\\Program Files\\Satsuma\\satsuma-core-windows.exe' --uninstall
Bellek raporu (hiçbir şeyi durdurmaz): --memory-report
Parola: --set-password (Satsuma yönetici parolasını belirler/değiştirir; engel kaldırma, onaylar ve DeepSeek komutları bu parolayı ister)
DeepSeek: --deepseek-key (anahtarı verir; otomatik kural çekmeye onaydır), --deepseek-off,
          --deepseek-now, --rules (kurallar ve DeepSeek durumu),
          --rule-report KİMLİK, --rule-disable KİMLİK, --rule-enable KİMLİK, --rule-remove KİMLİK
OTX: --otx-key (anahtarı verir; OTX denetimi başlar), --unblock-otx (tüm OTX engellerini kaldırır)
Engel: --unblock ADRES (engeli kaldırır, adres bir daha engellenmez)
Onay (kurulu hizmete): --approve-firmware (BIOS/TPM değişikliğini onayla), --approve-location KLASÖR, --approve-device AYGIT_KİMLİĞİ
Panel: & 'C:\\Program Files\\Satsuma\\satsuma-panel.exe'
Sertifika: --cert-approve PARMAK_İZİ (karantinadaki kök ya da yayıncıyı onaylar ve geri koyar)
'''

def cert_command(args, directory=None, out=print):
    """--cert-approve THUMBPRINT: the service approves it (and puts a quarantined one back) within a minute."""
    from . import certs
    thumb = (args[1] if len(args) > 1 else '').replace(' ', '').upper()
    if not certs.THUMB.match(thumb):
        out(json.dumps({'ok': False, 'error': 'thumbprint_must_be_40_hex'}))
        return 2
    certs.write_request(Path(directory) if directory else state_dir(), thumb)
    out(json.dumps({'ok': True, 'status': 'SENT_TO_SERVICE', 'thumbprint': thumb}))
    return 0


DEEPSEEK_COMMANDS = ('--deepseek-key', '--deepseek-off', '--deepseek-now', '--rules', '--rule-report',
                     '--rule-disable', '--rule-enable', '--rule-remove')


WINDOWS_MEMORY_RULES = ('SATSUMA-RAM-001', 'SATSUMA-RAM-004', 'SATSUMA-RAM-008', 'SATSUMA-RAM-009')


def new_password():
    """A new Satsuma administrator password, typed twice (or SATSUMA_OWNER_PASSWORD in automated tests)."""
    from . import owner_password
    first = owner_password.ask('Yeni Satsuma yönetici parolası (en az %d karakter): ' % owner_password.MIN_LENGTH)
    if not os.environ.get('SATSUMA_OWNER_PASSWORD'):
        if owner_password.ask('Yeni parola (tekrar): ') != first:
            raise ValueError('iki parola aynı değil')
    owner_password.check_strength(first)
    return first


def canonical_rows(rows):
    return json.dumps(rows, sort_keys=True, ensure_ascii=False).encode('utf-8')


def _pw(directory):
    """The Satsuma administrator password for a request (owner's request 2026-11-25)."""
    from . import owner_password
    return owner_password.for_request(directory)


def deepseek_command(args, directory=None, read_key=None, out=print):
    """Administrator command line for DeepSeek: writes a request the service carries out within seconds.

    Yönetici komut satırı: hizmetin birkaç saniye içinde yerine getirdiği bir istek yazar.
    """
    from . import ai_rules
    directory = Path(directory) if directory else state_dir()
    command = args[0]
    if command == '--deepseek-key':
        if read_key is None:
            import getpass
            read_key = (lambda: getpass.getpass('DeepSeek API anahtarı: ')) if sys.stdin and sys.stdin.isatty() \
                else (lambda: sys.stdin.readline())
        key = (read_key() or '').strip()
        if not 16 <= len(key) <= 4096 or any(ord(c) < 33 or ord(c) > 126 for c in key):
            out(json.dumps({'ok': False, 'error': 'invalid_key'}))
            return 2
        ai_rules.write_request(directory, password=_pw(directory), kind='set_key', key=key)
        out(json.dumps({'ok': True, 'status': 'SENT_TO_SERVICE',
                        'note': 'Hizmet anahtarı DPAPI ile saklar ve kuralları otomatik çekmeye başlar.'}, ensure_ascii=False))
        return 0
    if command in ('--deepseek-off', '--deepseek-now'):
        ai_rules.write_request(directory, password=_pw(directory), kind='clear_key' if command == '--deepseek-off' else 'fetch_now')
        out(json.dumps({'ok': True, 'status': 'SENT_TO_SERVICE'}))
        return 0
    if command == '--rules':
        folder = ai_rules.deepseek_dir(directory)
        try:
            state = json.loads((folder / 'state.json').read_text(encoding='utf-8'))
        except (OSError, ValueError):
            state = {}
        active = []
        for path in sorted((folder / 'active').glob('*.json')) if (folder / 'active').is_dir() else []:
            try:
                package = json.loads(path.read_text(encoding='utf-8'))['package']
                active.append({'id': package['detection']['id'], 'attack_type': package.get('attack_type'),
                               'name': package['detection'].get('name')})
            except (OSError, ValueError, KeyError, TypeError):
                active.append({'file': path.name, 'error': 'unreadable'})
        from .rules import Engine
        out(json.dumps({'bundled': Engine().stats(), 'deepseek': {'state': state, 'active': active}},
                       ensure_ascii=False, indent=1))
        return 0
    rule_id = args[1] if len(args) > 1 else ''
    if not ai_rules.ID_PATTERN.match(rule_id):
        out(json.dumps({'ok': False, 'error': 'rule_id_must_be_SATSUMA-AI-WIN-...'}))
        return 2
    if command == '--rule-remove':
        ai_rules.write_request(directory, password=_pw(directory), kind='remove', rule_id=rule_id)
    else:
        mode = {'--rule-report': 'report', '--rule-disable': 'disabled', '--rule-enable': 'enabled'}[command]
        ai_rules.write_request(directory, password=_pw(directory), kind='override', rule_id=rule_id, mode=mode)
    out(json.dumps({'ok': True, 'status': 'SENT_TO_SERVICE', 'rule_id': rule_id}))
    return 0



def run_loop(guard, wait):
    """Poll until ``wait(seconds)`` returns True (a stop request); a failing poll is recorded, never fatal.

    Window and Windows service run the same loop. Pencere ve Windows hizmeti aynı döngüyü çalıştırır.
    """
    while True:
        started = time.monotonic()
        try:
            guard.poll()
        except Exception as exc:  # the guard keeps running; the failure is recorded
            guard.record('guard_error', error=type(exc).__name__ + ': ' + str(exc)[:300])
        if wait(max(0.0, POLL_SECONDS - (time.monotonic() - started))):
            guard.record('stop_requested')
            if getattr(guard, 'liveness', None) is not None:
                guard.liveness.clean_stop()
            guard.stop()
            return


if __name__ == '__main__':
    raise SystemExit(main())
