"""Suricata on Windows: installed by Satsuma itself, inline IPS through WinDivert (owner's decision 2026-11-24).

Installation: the official OISF Windows build with WinDivert (Suricata 8.0.8,
Suricata-<v>-windivert-1-64bit.zip) is downloaded from download.openinfosecfoundation.org.
OISF publishes no checksum, so GitHub's Windows server downloads the same archive when
it builds satsuma-core-windows.exe and pins its SHA-256 into the exe (suricata-pin.json);
on the owner's machine an archive that does not match is not installed, and without a pin
nothing is installed. The WinDivert driver must carry a valid Authenticode signature
(Windows loads no unsigned driver either). Files go to %ProgramFiles%\\Satsuma\\Suricata;
configuration, rules and logs to %ProgramData%\\Satsuma\\suricata (SYSTEM and
Administrators only).

Configuration: built with the Linux code itself (satsuma.suricata_config.build: HOME_NET
from this machine's networks, the EVE log Satsuma reads, inline stream, no bypass) from
the suricata.yaml the archive ships; only the Windows parts differ (no NFQUEUE, no unix
socket, Windows paths). It is tested with ``suricata -T`` before it is used.

Rules: the Emerging Threats Open set for this Suricata version (the source suricata-update
uses on Linux), checked against its published MD5. Inline, a rule only drops when its
action is drop: Satsuma turns into drops the ET rules marked both "confidence High" and
"signature_severity Major/Critical", and keeps the rest as alerts. One rule of Satsuma's
own drops only a made-up token (satsuma-ips-proof-7f3c9a1e), the IPS self-test.

Running: Suricata is the service's own child in a Windows job object (it closes with the
service) with ``--windivert "not loopback"``: every packet of this machine passes through
Suricata; when Suricata stops, WinDivert closes and traffic flows again without
inspection, which the service reports and restarts. EVE alerts are recorded.

Windows'ta Suricata: Satsuma kendisi kurar, WinDivert ile satır içi IPS (sahibinin kararı
2026-11-24). Resmi OISF WinDivert derlemesi indirilir; OISF özet yayımlamadığından GitHub'ın
Windows sunucusu exe'yi derlerken aynı arşivi indirip SHA-256'sını exe'ye sabitler; tutmayan
arşiv kurulmaz. WinDivert sürücüsünün Authenticode imzası geçerli olmalıdır. Yapılandırma
Linux'un kendi koduyla kurulur, ``suricata -T`` ile denenir. Kurallar ET Open'dır (MD5
denetimli); "confidence High" ve "Major/Critical" işaretli ET kuralları düşürmeye çevrilir.
Suricata hizmetin alt sürecidir, ``--windivert "not loopback"`` ile çalışır; durursa trafik
denetimsiz akar, hizmet bildirir ve yeniden başlatır. EVE uyarıları kaydedilir.
"""
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import time
import zipfile
from pathlib import Path

VERSION = '8.0.8'
# The MSI itself: inside OISF's zip the same MSI is password protected (AV false alarms on WinDivert).
# MSI'ın kendisi: OISF zip'inin içindeki aynı MSI parola korumalıdır.
DISABLE_ROUNDS = 8
ARCHIVE = 'Suricata-%s-windivert-1-64bit.msi' % VERSION
URL = 'https://download.openinfosecfoundation.org/downloads/windows/' + ARCHIVE
RULE_URLS = ('https://rules.emergingthreats.net/open/suricata-%s/emerging.rules.tar.gz' % VERSION,
             'https://rules.emergingthreats.net/open/suricata-8.0.0/emerging.rules.tar.gz')
FILTER = 'not loopback'
PROOF_TOKEN = 'satsuma-ips-proof-7f3c9a1e'
PROOF_SID = 9900001
LOCAL_RULES = (
    'drop http any any -> any any (msg:"SATSUMA IPS self-test"; flow:to_server,established; '
    'http.uri; content:"%s"; classtype:policy-violation; sid:%d; rev:1;)\n' % (PROOF_TOKEN, PROOF_SID))
RESTART_EVERY = 60.0
INSTALL_EVERY = 600.0
RULES_EVERY = 24 * 3600.0
MAX_ARCHIVE = 200 * 1024 * 1024
DROP_CONFIDENCE = re.compile(r'\bconfidence\s+high\b', re.IGNORECASE)
DROP_SEVERITY = re.compile(r'\bsignature_severity\s+(major|critical)\b', re.IGNORECASE)


def engine_dir():
    return Path(os.environ.get('ProgramFiles', r'C:\Program Files')) / 'Satsuma' / 'Suricata'


def cleanup_old(state_dir, root=None):
    """Delete Suricata engine folders other than the one engine.json names (owner's approval 2026-11-25).

    Old versions and folders left because WinDivert64.sys was still loaded (replace_folder) pile up:
    the owner found five copies of Suricata and six of the driver. A folder still locked is left and
    reported; it goes at a later start, after the restart that unloads the driver.
    Eski Suricata klasörleri silinir; kilitli olan bırakılır, sonraki açılışta silinir.
    """
    import shutil
    root = Path(root) if root else engine_dir()
    try:
        current = Path(json.loads((data_dir(state_dir) / 'engine.json').read_text(encoding='utf-8'))['folder']).resolve()
    except (OSError, ValueError, KeyError, TypeError):
        return {'ok': False, 'status': 'NO_ENGINE_RECORD', 'removed': [], 'left': []}
    candidates = [p for p in root.iterdir() if p.is_dir()] if root.is_dir() else []
    candidates += [p for p in root.parent.glob(root.name + '-*') if p.is_dir()]
    removed, left = [], []
    for folder in candidates:
        resolved = folder.resolve()
        if resolved == current or resolved in current.parents:
            continue
        shutil.rmtree(folder, ignore_errors=True)
        (left if folder.exists() else removed).append(str(folder))
    return {'ok': not left, 'status': 'CLEANED' if not left else 'SOME_LOCKED', 'removed': removed, 'left': left}


def data_dir(state_dir):
    return Path(state_dir) / 'suricata'


def pin():
    """The SHA-256 GitHub's build server pinned into the exe, or None (source run, tests)."""
    bundled = getattr(sys, '_MEIPASS', None)
    for folder in ([Path(bundled)] if bundled else []) + [Path(__file__).resolve().parents[1]]:
        try:
            row = json.loads((folder / 'suricata-pin.json').read_text(encoding='utf-8'))
        except (OSError, ValueError):
            continue
        if row.get('archive') == ARCHIVE and re.fullmatch(r'[0-9a-f]{64}', str(row.get('sha256', ''))):
            return row['sha256']
    return None


def download_windows(url, timeout=600):
    """Download with Windows' own TLS (Schannel), which fetches a missing root certificate itself.

    Python cannot trigger that; the archive is pinned by SHA-256 and the rules by MD5, so the
    content is checked the same way. Windows'un kendi TLS'iyle indirir (eksik kök sertifikayı
    kendisi getirir); içerik yine SHA-256/MD5 ile denetlenir.
    """
    import tempfile
    from .firewall import run_powershell
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / 'download.bin'
        run_powershell("$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12,Tls13'; "
                       "Invoke-WebRequest -UseBasicParsing -Uri '" + url.replace("'", "''") + "' -OutFile '"
                       + str(out).replace("'", "''") + "'", timeout=timeout)
        return out.read_bytes()


def download(url, limit=MAX_ARCHIVE):
    import ssl
    import urllib.error
    import urllib.request
    try:
        with urllib.request.urlopen(url, timeout=60) as response:
            data = response.read(limit + 1)
    except urllib.error.URLError as exc:
        if not isinstance(getattr(exc, 'reason', None), ssl.SSLCertVerificationError):
            raise
        data = download_windows(url)
    if len(data) > limit:
        raise OSError('download too large: ' + url)
    return data


def replace_folder(staging, target):
    """Put ``staging`` in place of ``target``; a locked old folder is left and a new one used.

    The old engine folder holds WinDivert64.sys, which Windows keeps loaded until restart, so it
    cannot always be removed (owner's machine 2026-11-24: WinError 5). Then the new engine goes to
    a folder of its own; engine.json records which folder runs.
    Kilitli eski klasör bırakılır, yeni motor kendi klasörüne konur.
    """
    target = Path(target)
    shutil.rmtree(target, ignore_errors=True)
    if target.exists():
        target = target.with_name(target.name + '-' + time.strftime('%Y%m%d%H%M%S'))
    os.replace(staging, target)
    return target


def extract_msi(data, target, runner=None):
    """Unpack the MSI without installing it (msiexec /a, administrative image) into ``target``."""
    import tempfile
    from .firewall import safe_run
    runner = runner or safe_run
    target = Path(target)
    staging = target.with_name(target.name + '.new')
    shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir(parents=True)
    with tempfile.TemporaryDirectory() as tmp:
        msi = Path(tmp) / ARCHIVE
        msi.write_bytes(data)
        # One command line: msiexec wants TARGETDIR="C:\Program Files\...", which a list would quote
        # as "TARGETDIR=..." (code 1639). Tek komut satırı: liste yolu yanlış tırnaklar (1639).
        line = ('msiexec.exe /a "%s" /qn TARGETDIR="%s" /l*v "%s"'
                % (msi, str(staging).rstrip('\\'), Path(tmp) / 'msi.log'))
        done = runner(line, capture_output=True, text=True, timeout=600)
        if done.returncode != 0:
            log = ''
            try:
                log = (Path(tmp) / 'msi.log').read_text(encoding='utf-16', errors='replace')[-300:]
            except OSError:
                pass
            shutil.rmtree(staging, ignore_errors=True)
            raise ValueError('msiexec /a code ' + str(done.returncode) + ': ' + log)
    for leftover in staging.rglob('*.msi'):
        leftover.unlink()
    found = sorted(staging.rglob('suricata.exe'), key=lambda p: len(p.parts))
    if not found:
        shutil.rmtree(staging, ignore_errors=True)
        raise ValueError('suricata.exe is not in the MSI')
    target = replace_folder(staging, target)
    return target / found[0].parent.relative_to(staging)


def extract(data, target, runner=None):
    if data[:8] == bytes.fromhex('d0cf11e0a1b11ae1'):  # MSI (OLE compound file)
        return extract_msi(data, target, runner)
    return extract_zip(data, target)


def extract_zip(data, target):
    """Unpack the archive into ``target``; no absolute path or .. may leave it. Returns the Suricata folder."""
    target = Path(target)
    staging = target.with_name(target.name + '.new')
    shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir(parents=True)
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        for member in archive.infolist():
            name = member.filename.replace('\\', '/')
            parts = [p for p in name.split('/') if p]
            if not parts or name.startswith('/') or ':' in parts[0] or '..' in parts:
                raise ValueError('unsafe path in archive: ' + member.filename[:120])
            path = staging.joinpath(*parts)
            if member.is_dir():
                path.mkdir(parents=True, exist_ok=True)
                continue
            path.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(member) as source, open(path, 'wb') as out:
                shutil.copyfileobj(source, out)
    found = sorted(staging.rglob('suricata.exe'), key=lambda p: len(p.parts))
    if not found:
        shutil.rmtree(staging, ignore_errors=True)
        raise ValueError('suricata.exe is not in the archive')
    target = replace_folder(staging, target)
    return target / found[0].parent.relative_to(staging)


def windivert_files(folder):
    folder = Path(folder)
    return {name: next(iter(sorted(folder.rglob(name))), None) for name in ('WinDivert.dll', 'WinDivert64.sys')}


def signature_script(path):
    quoted = "'" + str(path).replace("'", "''") + "'"
    return ("$s = Get-AuthenticodeSignature -LiteralPath " + quoted + "; "
            "@{status=[string]$s.Status; subject=[string]$s.SignerCertificate.Subject} | ConvertTo-Json -Compress")


def drop_converted(text):
    """ET rules marked confidence High and Major/Critical severity become drops; the rest stay alerts."""
    lines, converted = [], 0
    for line in text.splitlines(keepends=True):
        if line.startswith('alert ') and DROP_CONFIDENCE.search(line) and DROP_SEVERITY.search(line):
            line = 'drop ' + line[len('alert '):]
            converted += 1
        lines.append(line)
    return ''.join(lines), converted


def install_rules(data, fetch=download):
    """Download ET Open (MD5 checked), convert the confident ones to drops, add Satsuma's self-test."""
    rules_dir = Path(data) / 'rules'
    errors = []
    for url in RULE_URLS:
        try:
            archive = fetch(url)
            expected = fetch(url + '.md5').decode('ascii', 'replace').split()[0].strip().lower()
        except OSError as exc:
            errors.append(url.rsplit('/', 2)[-2] + ': ' + str(exc)[:120])
            continue
        if hashlib.md5(archive).hexdigest() != expected:
            errors.append(url.rsplit('/', 2)[-2] + ': md5_mismatch')
            continue
        texts = []
        with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as bundle:
            for member in bundle.getmembers():
                if member.isfile() and member.name.endswith('.rules') and '..' not in member.name:
                    texts.append(bundle.extractfile(member).read().decode('utf-8', 'replace'))
        text, converted = drop_converted(''.join(texts))
        rules_dir.mkdir(parents=True, exist_ok=True)
        temporary = rules_dir / 'suricata.rules.tmp'
        temporary.write_text(text + '\n' + LOCAL_RULES, encoding='utf-8')
        os.replace(temporary, rules_dir / 'suricata.rules')
        count = sum(1 for line in text.splitlines() if line.startswith(('alert ', 'drop ')))
        return {'ok': True, 'status': 'UPDATED', 'source': url, 'rules': count, 'drops': converted}
    return {'ok': False, 'status': 'RULES_UNAVAILABLE', 'errors': errors}


def home_networks(runner=None):
    """This machine's IPv4 networks (Get-NetIPAddress), or the private ranges."""
    from .firewall import run_powershell, safe_run
    import ipaddress
    script = ("@(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { "
              "$_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | "
              "ForEach-Object { $_.IPAddress + '/' + $_.PrefixLength }) | ConvertTo-Json -Compress")
    try:
        rows = json.loads(run_powershell(script, runner or safe_run) or '[]')
        rows = [rows] if isinstance(rows, str) else rows
        networks = sorted({str(ipaddress.ip_interface(r).network) for r in rows})
    except Exception:  # the private ranges are a safe default for HOME_NET
        networks = []
    from satsuma.suricata_config import FALLBACK_HOME
    return networks or list(FALLBACK_HOME)


def config_text(system_text, engine, data, networks):
    """Satsuma's suricata.yaml: the Linux build(), then the Windows parts."""
    import yaml
    from satsuma.suricata_config import HEADER, build
    config = build(yaml.safe_load(system_text) or {}, networks, Path(data) / 'rules')
    config.pop('nfq', None)
    config['unix-command'] = {'enabled': 'no'}
    config['default-log-dir'] = str(Path(data) / 'log')
    config['default-rule-path'] = str(Path(data) / 'rules')
    config['rule-files'] = ['suricata.rules']
    for key, name in (('classification-file', 'classification.config'), ('reference-config-file', 'reference.config'),
                      ('threshold-file', 'threshold.config')):
        found = next(iter(sorted(Path(engine).rglob(name))), None)
        if found is not None:
            config[key] = str(found)
        else:
            config.pop(key, None)
    return HEADER + yaml.safe_dump(config, default_flow_style=False, sort_keys=False, allow_unicode=False)


class NpcapMissing(ValueError):
    """Suricata for Windows needs Npcap's wpcap.dll; the free Npcap may not be installed silently."""


NPCAP_HINT = ('Suricata Npcap ister: https://npcap.com adresinden kurun ve "WinPcap API-compatible Mode" seçeneğini '
              'işaretleyin; hizmet Suricata\'yı 10 dakika içinde kendisi başlatır.')


def write_config(engine, data, runner=subprocess.run, networks=None):
    exe = Path(engine) / 'suricata.exe'
    system = next(iter(sorted(Path(engine).rglob('suricata.yaml'))), None)
    if system is None:
        raise ValueError('suricata.yaml is not in the archive')
    (Path(data) / 'log').mkdir(parents=True, exist_ok=True)
    text = config_text(system.read_text(encoding='utf-8', errors='replace'), engine, data,
                       networks if networks is not None else home_networks(runner))
    path = Path(data) / 'suricata.yaml'
    path.write_text(text, encoding='utf-8')
    # A rule this Windows build cannot load (a keyword it lacks) is commented out and recorded, then the test
    # runs again; at most DISABLE_ROUNDS times. Bu derlemenin yükleyemediği kural kapatılır, kaydedilir, yeniden sınanır.
    import re
    rules = Path(data) / 'rules' / 'suricata.rules'
    for _ in range(DISABLE_ROUNDS):
        test = runner([str(exe), '-T', '-c', str(path), '-l', str(Path(data) / 'log')], capture_output=True, text=True,
                      timeout=600, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if test.returncode == 0:
            return str(path)
        if test.returncode in (3221225781, -1073741515):  # STATUS_DLL_NOT_FOUND: wpcap.dll (Npcap) is missing
            raise NpcapMissing('Npcap is not installed (wpcap.dll)')
        output = (test.stderr or '') + (test.stdout or '')
        bad = {int(n) for n in re.findall(r'suricata\.rules at line (\d+)', output)}
        if not bad or not rules.exists():
            raise ValueError('suricata -T code ' + str(test.returncode) + ': ' + output[-600:])
        lines = rules.read_text(encoding='utf-8', errors='replace').splitlines()
        for n in sorted(bad):
            if 0 < n <= len(lines) and not lines[n - 1].startswith('#'):
                lines[n - 1] = '# satsuma-disabled (bu derleme yükleyemedi): ' + lines[n - 1]
        rules.write_text('\n'.join(lines) + '\n', encoding='utf-8')
        with open(Path(data) / 'disabled-rules.log', 'a', encoding='utf-8') as log:
            log.write(time.strftime('%Y-%m-%dT%H:%M:%S ') + ','.join(map(str, sorted(bad))) + '\n')
    raise ValueError('suricata -T: still failing after disabling unloadable rules')


def install(state_dir, runner=None, fetch=download, expected=None, signature=None, engine=None):
    """Download, verify, unpack, configure; never installs an unverified archive. Returns a result dict."""
    from .firewall import run_powershell, safe_run
    runner = runner or safe_run
    expected = expected if expected is not None else pin()
    if not expected:
        return {'ok': False, 'status': 'NO_PIN', 'error': 'this exe carries no pinned Suricata archive'}
    # Already installed from the same pinned archive with its rules and configuration: nothing to
    # download (owner's machine 2026-11-24: a reinstall hung on a stalled download). The service
    # refreshes the rules daily. Aynı sabitli paket kuruluysa indirme yok; kuralları hizmet günceller.
    state = data_dir(state_dir)
    try:
        installed = json.loads((state / 'engine.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        installed = {}
    if (engine is None and installed.get('sha256') == expected and (Path(installed.get('folder', '')) / 'suricata.exe').exists()
            and (state / 'rules' / 'suricata.rules').exists() and (state / 'suricata.yaml').exists()):
        return {'ok': True, 'status': 'ALREADY_INSTALLED', 'version': installed.get('version'), 'sha256': expected,
                'config': str(state / 'suricata.yaml'), 'rules': {'ok': True, 'status': 'KEPT_SERVICE_UPDATES_DAILY'}}
    try:
        data = fetch(URL)
    except OSError as exc:
        return {'ok': False, 'status': 'DOWNLOAD_FAILED', 'error': str(exc)[:300]}
    digest = hashlib.sha256(data).hexdigest()
    if digest != expected:
        return {'ok': False, 'status': 'ARCHIVE_MISMATCH', 'sha256': digest}
    # A folder per version: an upgrade never has to delete the files the running Suricata uses.
    # Sürüm başına klasör: yükseltme çalışan Suricata'nın dosyalarını silmek zorunda kalmaz.
    engine_root = Path(engine) if engine else engine_dir() / VERSION
    if installed.get('sha256') == digest and (Path(installed.get('folder', '')) / 'suricata.exe').exists():
        folder = Path(installed['folder'])
    else:
        try:
            folder = extract(data, engine_root, runner)
        except (ValueError, OSError, zipfile.BadZipFile) as exc:
            return {'ok': False, 'status': 'UNPACK_FAILED', 'error': str(exc)[:300]}
    files = windivert_files(engine_root)
    if not all(files.values()):
        return {'ok': False, 'status': 'WINDIVERT_MISSING', 'files': {k: bool(v) for k, v in files.items()}}
    check = signature or (lambda path: json.loads(run_powershell(signature_script(path), runner) or '{}'))
    try:
        signed = check(files['WinDivert64.sys'])
    except Exception as exc:  # FirewallError, ValueError: never installs then
        signed = {'status': '', 'error': str(exc)[:200]}
    if signed.get('status') != 'Valid':
        shutil.rmtree(engine_root, ignore_errors=True)
        return {'ok': False, 'status': 'DRIVER_SIGNATURE_REJECTED', 'signature': signed}
    rules = install_rules(state, fetch)
    try:
        config = write_config(folder, state, runner)
    except NpcapMissing:
        return {'ok': False, 'status': 'NPCAP_REQUIRED', 'hint': NPCAP_HINT, 'rules': rules}
    except (ValueError, OSError, subprocess.SubprocessError) as exc:
        return {'ok': False, 'status': 'CONFIG_REJECTED', 'error': str(exc)[:400], 'rules': rules}
    (state / 'engine.json').write_text(json.dumps({'folder': str(folder), 'version': VERSION, 'sha256': digest}),
                                       encoding='utf-8')
    return {'ok': rules['ok'], 'status': 'INSTALLED', 'version': VERSION, 'sha256': digest, 'config': config,
            'rules': rules, 'driver_signature': signed}


def update_rules(state_dir, runner=subprocess.run):
    """The daily ET Open refresh, tested with suricata -T before Suricata restarts with it."""
    state = data_dir(state_dir)
    try:
        folder = json.loads((state / 'engine.json').read_text(encoding='utf-8'))['folder']
    except (OSError, ValueError, KeyError):
        return {'ok': False, 'status': 'NOT_INSTALLED'}
    rules = install_rules(state)
    if not rules['ok']:
        return rules
    try:
        write_config(folder, state, runner)
    except (ValueError, OSError, subprocess.SubprocessError) as exc:
        return {'ok': False, 'status': 'CONFIG_REJECTED', 'error': str(exc)[:400], 'rules': rules}
    return rules


def uninstall(state_dir, runner=None):
    from .firewall import safe_run
    runner = runner or safe_run
    for argv in (['sc.exe', 'stop', 'WinDivert'], ['sc.exe', 'delete', 'WinDivert']):
        try:
            runner(argv, capture_output=True, text=True, timeout=60)
        except (OSError, subprocess.SubprocessError):
            pass
    shutil.rmtree(engine_dir(), ignore_errors=True)
    shutil.rmtree(data_dir(state_dir), ignore_errors=True)
    gone = not engine_dir().exists() and not data_dir(state_dir).exists()
    return {'ok': gone, 'status': 'REMOVED' if gone else 'REMOVE_FAILED'}


def command(folder, data):
    data = Path(data)
    return [str(Path(folder) / 'suricata.exe'), '-c', str(data / 'suricata.yaml'), '-l', str(data / 'log'),
            '--init-errors-fatal', '--windivert', FILTER, '--set', 'stream.inline=yes', '--set', 'stream.bypass=no']


class _Job:
    """A Windows job object: its processes die when the service closes it (or dies)."""

    def __init__(self):
        import win32job
        self.win32job = win32job
        self.handle = win32job.CreateJobObject(None, '')
        info = win32job.QueryInformationJobObject(self.handle, win32job.JobObjectExtendedLimitInformation)
        info['BasicLimitInformation']['LimitFlags'] |= win32job.JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        win32job.SetInformationJobObject(self.handle, win32job.JobObjectExtendedLimitInformation, info)

    def add(self, process):
        self.win32job.AssignProcessToJobObject(self.handle, int(process._handle))


class Runtime:
    """Keeps Suricata running as the service's child; reads its EVE alerts. Suricata'yı çalışır tutar."""

    def __init__(self, state_dir, record, clock=time.monotonic, popen=None, job=None):
        self.data = data_dir(state_dir)
        self.record, self.clock = record, clock
        self.popen = popen or (lambda argv: subprocess.Popen(
            argv, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)))
        self.job_factory = job or _Job
        self.job, self.process, self.started_at, self.tried_at = None, None, None, None
        self.eve_offset, self.counts = None, {'starts': 0, 'exits': 0, 'alerts': 0, 'blocked': 0}
        self.worker, self.result, self.installed_at, self.rules_at = None, None, None, None
        self.state_dir = state_dir
        self.installer = lambda: install(state_dir)
        self.rules_updater = lambda: update_rules(state_dir)

    def background(self):
        """Install when missing (every 10 minutes), refresh the rules daily; never blocks the poll.

        Eksikse kurar (10 dakikada bir), kuralları günde bir yeniler; turu asla bekletmez.
        """
        import threading
        if self.worker is not None and self.worker.is_alive():
            return []
        events = []
        if self.result is not None:
            kind, result = self.result
            self.result, self.worker = None, None
            events.append(self.record('suricata_' + kind, **result))
            if result.get('ok') and self.process is not None:
                self.stop()                    # restarted by check() with the new files or rules
                self.tried_at = None
        now = self.clock()
        job = None
        if self.folder() is None:
            if self.installed_at is None or now - self.installed_at >= INSTALL_EVERY:
                self.installed_at, job = now, ('install', self.installer)
        elif self.rules_at is None:
            self.rules_at = now
        elif now - self.rules_at >= RULES_EVERY:
            self.rules_at, job = now, ('rules_update', self.rules_updater)
        if job is not None:
            def work(kind=job[0], run=job[1]):
                try:
                    self.result = (kind, run())
                except Exception as exc:  # recorded at the next poll
                    self.result = (kind, {'ok': False, 'status': 'ERROR', 'error': type(exc).__name__ + ': ' + str(exc)[:200]})
            self.worker = threading.Thread(target=work, name='satsuma-suricata', daemon=True)
            self.worker.start()
        return events

    def folder(self):
        try:
            return json.loads((self.data / 'engine.json').read_text(encoding='utf-8'))['folder']
        except (OSError, ValueError, KeyError):
            return None

    def start(self):
        folder = self.folder()
        if folder is None or not (self.data / 'suricata.yaml').exists():
            return {'ok': False, 'status': 'NOT_INSTALLED'}
        if self.job is None:
            self.job = self.job_factory()
        self.process = self.popen(command(folder, self.data))
        self.job.add(self.process)
        self.started_at = self.tried_at = self.clock()
        self.counts['starts'] += 1
        return {'ok': True, 'status': 'RUNNING', 'pid': self.process.pid, 'filter': FILTER}

    def check(self):
        """Every poll: restart Suricata if it stopped (at most once a minute), record new alerts."""
        events = []
        if self.process is not None and self.process.poll() is not None:
            self.counts['exits'] += 1
            events.append(self.record('suricata_exited', code=self.process.returncode,
                                      note='WinDivert kapandı; trafik denetimsiz akıyor, yeniden başlatılacak.'))
            self.process = None
        if self.process is None and (self.tried_at is None or self.clock() - self.tried_at >= RESTART_EVERY):
            self.tried_at = self.clock()
            try:
                result = self.start()
            except Exception as exc:  # recorded; tried again in a minute
                result = {'ok': False, 'status': 'START_FAILED', 'error': type(exc).__name__ + ': ' + str(exc)[:200]}
            if result.get('status') != 'NOT_INSTALLED':
                events.append(self.record('suricata_started' if result['ok'] else 'suricata_start_failed', **result))
        events.extend(self.alerts())
        events.extend(self.background())
        return events

    def alerts(self, limit=500):
        path = self.data / 'log' / 'eve.json'
        try:
            size = path.stat().st_size
        except OSError:
            return []
        if self.eve_offset is None or size < self.eve_offset:
            self.eve_offset = size if self.eve_offset is None else 0
            return []
        events = []
        with open(path, 'rb') as stream:
            stream.seek(self.eve_offset)
            for raw in stream:
                if not raw.endswith(b'\n'):
                    break
                self.eve_offset += len(raw)
                try:
                    row = json.loads(raw)
                except ValueError:
                    continue
                if row.get('event_type') != 'alert':
                    continue
                alert = row.get('alert') or {}
                self.counts['alerts'] += 1
                if alert.get('action') == 'blocked':
                    self.counts['blocked'] += 1
                events.append(self.record('suricata_alert', sid=alert.get('signature_id'), signature=alert.get('signature'),
                                          severity=alert.get('severity'), category=alert.get('category'),
                                          action=alert.get('action'), src=row.get('src_ip'), src_port=row.get('src_port'),
                                          dest=row.get('dest_ip'), dest_port=row.get('dest_port'), proto=row.get('proto')))
                if len(events) >= limit:
                    break
        return events

    def stop(self):
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(15)
            except subprocess.TimeoutExpired:
                self.process.kill()
        self.process = None

    def health(self):
        return {'running': self.process is not None and self.process.poll() is None, 'filter': FILTER,
                'version': VERSION, **self.counts}
