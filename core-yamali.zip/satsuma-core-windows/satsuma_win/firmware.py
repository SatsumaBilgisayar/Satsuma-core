"""Firmware baseline: BIOS, TPM and boot measurements, signed at installation (owner's rule 2026-11-25).

The owner never updates the BIOS: earlier BIOS updates brought fake firmware and a TPM that
reported version 0.0.0. Satsuma keeps, signed with the machine key, what the machine reported
at installation:

* BIOS vendor, version and date, board maker and model (registry, HARDWARE\\DESCRIPTION\\System\\BIOS);
* Secure Boot on or off (registry, SecureBoot\\State);
* TPM maker and firmware version (TPM2_GetCapability through the Windows TPM Base Services);
* PCR 0 (firmware code) and PCR 7 (Secure Boot policy), SHA-256 (TPM2_PCR_Read through TBS).

At every start and every hour the same values are read again. Any difference is a critical
'firmware_changed' record naming each field, old and new; it is recorded again only when the
difference changes. The baseline is never moved by Satsuma itself: only the owner, with
``--approve-firmware`` and the word "onaylıyorum", takes the current values as the new baseline.
No PowerShell is used (the owner's ransomware protection blocks PowerShell's catalog access).

Ürün yazılımı taban çizgisi: BIOS, TPM ve önyükleme ölçümleri kurulumda makine anahtarıyla
imzalanır; her açılışta ve saatte bir karşılaştırılır. Fark kritik kayıttır; taban çizgisini yalnız
sahip "onaylıyorum" yazarak yeniler.
"""
import json
import os
import struct
import time
from pathlib import Path

BASELINE = 'firmware-baseline.json'
EVERY = 3600
FIELDS = ('bios_vendor', 'bios_version', 'bios_date', 'board_maker', 'board_model', 'secure_boot',
          'tpm_maker', 'tpm_firmware', 'pcr0', 'pcr7')
LABELS = {'bios_vendor': 'BIOS üreticisi', 'bios_version': 'BIOS sürümü', 'bios_date': 'BIOS tarihi',
          'board_maker': 'Anakart üreticisi', 'board_model': 'Anakart modeli', 'secure_boot': 'Güvenli Önyükleme',
          'tpm_maker': 'TPM üreticisi', 'tpm_firmware': 'TPM firmware sürümü',
          'pcr0': 'PCR0 (firmware kodu ölçümü)', 'pcr7': 'PCR7 (Güvenli Önyükleme ilkesi ölçümü)'}

# TPM 2.0 commands (TCG TPM 2.0 Part 2/3). TPM 2.0 komutları.
ST_NO_SESSIONS = 0x8001
CC_GET_CAPABILITY = 0x0000017A
CC_PCR_READ = 0x0000017E
CAP_TPM_PROPERTIES = 0x00000006
PT_MANUFACTURER = 0x105
PT_FIRMWARE_VERSION_1 = 0x10B
PT_FIRMWARE_VERSION_2 = 0x10C
ALG_SHA256 = 0x000B


def get_capability_command(first=PT_MANUFACTURER, count=8):
    body = struct.pack('>III', CAP_TPM_PROPERTIES, first, count)
    return struct.pack('>HII', ST_NO_SESSIONS, 10 + len(body), CC_GET_CAPABILITY) + body


def parse_properties(response):
    """{property: value} from a TPM2_GetCapability(TPM_PROPERTIES) response."""
    tag, size, rc = struct.unpack_from('>HII', response, 0)
    if rc != 0:
        raise ValueError('TPM2_GetCapability rc=0x%x' % rc)
    capability, count = struct.unpack_from('>II', response, 11)  # after moreData (1 byte)
    if capability != CAP_TPM_PROPERTIES:
        raise ValueError('unexpected capability')
    return dict(struct.unpack_from('>II', response, 19 + 8 * i) for i in range(count))


def pcr_read_command(pcrs=(0, 7)):
    select = bytearray(3)
    for pcr in pcrs:
        select[pcr // 8] |= 1 << (pcr % 8)
    body = struct.pack('>IHB', 1, ALG_SHA256, 3) + bytes(select)
    return struct.pack('>HII', ST_NO_SESSIONS, 10 + len(body), CC_PCR_READ) + body


def parse_pcr_read(response, pcrs=(0, 7)):
    """{pcr: hex digest} from a TPM2_PCR_Read response, in ascending PCR order."""
    tag, size, rc = struct.unpack_from('>HII', response, 0)
    if rc != 0:
        raise ValueError('TPM2_PCR_Read rc=0x%x' % rc)
    offset = 14  # header + pcrUpdateCounter
    (selections,) = struct.unpack_from('>I', response, offset)
    offset += 4
    for _ in range(selections):
        _, length = struct.unpack_from('>HB', response, offset)
        offset += 3 + length
    (digests,) = struct.unpack_from('>I', response, offset)
    offset += 4
    values = []
    for _ in range(digests):
        (length,) = struct.unpack_from('>H', response, offset)
        values.append(response[offset + 2:offset + 2 + length].hex())
        offset += 2 + length
    if len(values) != len(pcrs):
        raise ValueError('TPM returned %d of %d PCRs' % (len(values), len(pcrs)))
    return dict(zip(sorted(pcrs), values))


def maker_text(value):
    return value.to_bytes(4, 'big').decode('ascii', 'replace').strip('\x00 ')


def firmware_text(fw1, fw2):
    return '%d.%d.%d.%d' % (fw1 >> 16, fw1 & 0xFFFF, fw2 >> 16, fw2 & 0xFFFF)


def tbs_submit(command):
    """One TPM command through the Windows TPM Base Services (tbs.dll). TBS ile tek TPM komutu."""
    import ctypes
    from ctypes import wintypes

    class Params(ctypes.Structure):  # TBS_CONTEXT_PARAMS2
        _fields_ = [('version', ctypes.c_uint32), ('flags', ctypes.c_uint32)]

    tbs = ctypes.WinDLL('tbs')
    handle = ctypes.c_void_p()
    params = Params(2, 4)  # TBS_CONTEXT_VERSION_TWO, includeTpm20
    rc = tbs.Tbsi_Context_Create(ctypes.byref(params), ctypes.byref(handle))
    if rc != 0:
        raise OSError('Tbsi_Context_Create 0x%x' % (rc & 0xFFFFFFFF))
    try:
        result = (ctypes.c_ubyte * 4096)()
        length = wintypes.UINT(len(result))
        source = (ctypes.c_ubyte * len(command)).from_buffer_copy(command)
        rc = tbs.Tbsip_Submit_Command(handle, 0, 200, source, len(command), result, ctypes.byref(length))
        if rc != 0:
            raise OSError('Tbsip_Submit_Command 0x%x' % (rc & 0xFFFFFFFF))
        return bytes(result[:length.value])
    finally:
        tbs.Tbsip_Context_Close(handle)


def read_registry():
    import winreg
    facts = {}
    names = {'bios_vendor': 'BIOSVendor', 'bios_version': 'BIOSVersion', 'bios_date': 'BIOSReleaseDate',
             'board_maker': 'BaseBoardManufacturer', 'board_model': 'BaseBoardProduct'}
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'HARDWARE\DESCRIPTION\System\BIOS') as key:
        for field, name in names.items():
            try:
                facts[field] = str(winreg.QueryValueEx(key, name)[0]).strip()
            except OSError:
                facts[field] = None
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SYSTEM\CurrentControlSet\Control\SecureBoot\State') as key:
            facts['secure_boot'] = 'açık' if winreg.QueryValueEx(key, 'UEFISecureBootEnabled')[0] == 1 else 'kapalı'
    except OSError:
        facts['secure_boot'] = 'okunamadı'
    return facts


def read_tpm(submit=tbs_submit):
    props = parse_properties(submit(get_capability_command()))
    pcrs = parse_pcr_read(submit(pcr_read_command()))
    return {'tpm_maker': maker_text(props.get(PT_MANUFACTURER, 0)),
            'tpm_firmware': firmware_text(props.get(PT_FIRMWARE_VERSION_1, 0), props.get(PT_FIRMWARE_VERSION_2, 0)),
            'pcr0': pcrs[0], 'pcr7': pcrs[7]}


def read(registry=read_registry, tpm=read_tpm):
    """What the machine reports now; a part that cannot be read says so. Şu an bildirilen değerler."""
    facts = {}
    try:
        facts.update(registry())
    except Exception as exc:  # no registry (not Windows) or a missing key: said, never guessed
        facts['registry_error'] = (type(exc).__name__ + ': ' + str(exc))[:200]
    try:
        facts.update(tpm())
    except Exception as exc:  # no TPM, TBS refused, an answer that does not parse
        facts['tpm_error'] = (type(exc).__name__ + ': ' + str(exc))[:200]
    return facts


def digest(facts):
    import hashlib
    return hashlib.sha256(json.dumps({k: facts.get(k) for k in FIELDS}, sort_keys=True).encode()).hexdigest()


def load(directory, key):
    """(baseline facts, problem). The signature covers every field. İmzalı taban çizgisi."""
    try:
        stored = json.loads((Path(directory) / BASELINE).read_text(encoding='utf-8'))
    except OSError:
        return None, None
    except ValueError:
        return None, 'taban çizgisi okunamıyor'
    facts = stored.get('facts') if isinstance(stored, dict) else None
    if not isinstance(facts, dict) or key is None or not key.verify(
            json.dumps(facts, sort_keys=True).encode(), str(stored.get('signature'))):
        return None, 'taban çizgisinin imzası bozuk'
    return facts, None


def save(directory, key, facts, clock=time.time, approved=False):
    body = {k: facts.get(k) for k in FIELDS}
    path = Path(directory) / BASELINE
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps({'facts': body, 'signature': key.sign(json.dumps(body, sort_keys=True).encode()),
                               'time': clock(), 'approved_by_owner': approved}, ensure_ascii=False), encoding='utf-8')
    os.replace(tmp, path)
    return body


def differences(old, new):
    """[{field, label, old, new}] for every field that differs. Farklı her alan."""
    return [{'field': f, 'label': LABELS[f], 'old': old.get(f), 'new': new.get(f)}
            for f in FIELDS if old.get(f) != new.get(f)]


def lines(diffs):
    return [f"{d['label']}: {d['old']} → {d['new']}" for d in diffs]


class Watch:
    """The service side. Hizmet tarafı."""

    def __init__(self, directory, key, record, clock=time.time, reader=read):
        self.dir, self.key, self.record, self.clock, self.reader = Path(directory), key, record, clock, reader
        self.at, self.reported = None, None

    def check(self, force=False):
        now = self.clock()
        if not force and self.at is not None and now - self.at < EVERY:
            return None
        self.at = now
        if self.key is None:
            return self._once('firmware_unchecked', severity='high', reason='makine anahtarı yok')
        facts = self.reader()
        if 'tpm_error' in facts or 'registry_error' in facts:
            # Unreadable is itself recorded; the readable part is still compared.
            self._once('firmware_unreadable', severity='high',
                       error=facts.get('tpm_error') or facts.get('registry_error'))
        baseline, problem = load(self.dir, self.key)
        if problem:
            return self._once('firmware_changed', severity='critical', reason=problem, current=_public(facts))
        if baseline is None:
            if any(f not in facts for f in FIELDS):
                return None  # a baseline is taken only from values all read; tried again in an hour
            save(self.dir, self.key, facts, self.clock)
            return self.record('firmware_baseline_taken', **_public(facts))
        readable = {f: facts[f] for f in FIELDS if f in facts}
        diffs = [d for d in differences(baseline, {**baseline, **readable}) if d['field'] in readable]
        if not diffs:
            self.reported = None
            return None
        return self._once('firmware_changed', severity='critical', changes=diffs, summary=lines(diffs))

    def _once(self, kind, **fields):
        mark = json.dumps([kind, fields], sort_keys=True, default=str)
        if mark == self.reported:
            return None
        self.reported = mark
        return self.record(kind, **fields)

    def approve(self, seen_digest):
        """The owner's approval: only the very values the owner saw become the baseline."""
        facts = self.reader()
        if 'tpm_error' in facts or 'registry_error' in facts:
            return {'ok': False, 'error': 'değerler okunamadı'}
        if digest(facts) != seen_digest:
            return {'ok': False, 'error': 'değerler sahibin gördüğünden farklı; yeniden bakın'}
        body = save(self.dir, self.key, facts, self.clock, approved=True)
        self.reported = None
        return {'ok': True, 'baseline': body}


def _public(facts):
    return {k: facts.get(k) for k in FIELDS}
