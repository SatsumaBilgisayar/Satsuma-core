# Satsuma Core — Windows 11

Satsuma Core 2.2.36'nın Windows 11 karşılığı. Ağırlıklı Python; Windows'un kendi araçlarını (Windows Güvenlik Duvarı, DNS istemcisi, bağlantı tablosu) kullanır. Sürüm **0.1.0**: geliştirme aşaması. `satsuma-core-windows.exe` GitHub Actions'ın Windows sunucusunda derlenir; 853 kapatma ve DNS kilidi sahibinin Windows 11 makinesinde 2026-11-11'de çalıştı.

## Bu sürümde (aşama 1: ağ ve MITM koruması)

| Koruma | Nasıl | Linux ürünüyle |
|---|---|---|
| Gelen bağlantı yok | Güvenlik duvarı üç profilde açık, gelen bağlantılar ve izinli uygulamalar listesi engelli; Uzak Masaüstü, Uzak Yardım, WinRM, dosya/yazıcı paylaşımı (SMB, SMB1) ve Uzak Kayıt Defteri kapalı; dakikada bir denetlenir, değişirse geri yazılır | Sahibinin kuralı: uzak destek yalnızca dışarıya |
| 853 portu kapalı (TCP ve UDP, dışa) | Windows Güvenlik Duvarı engel kuralı | Aynı sabit kural |
| DNS kilidi | Bağlı her bağdaştırıcıda OpenDNS 208.67.222.222 / 208.67.220.220; modemin DHCP DNS'i kullanılmaz; çözümleme sınanır | Aynı sunucular |
| PTR'siz uç 6. bağlantıda engellenir | Bağlantı tablosu + PTR sorgusu; CDN'ler dahil gevşetilmez | **Ortak kod** (`satsuma.peer_watch`) |
| Alt ağ sınırı | Aynı /24 içinde 300 sn'de 10 farklı uç | Aynı kural |
| Asla engellenmeyenler | Modem, DNS sunucuları, TeamViewer/AnyDesk uçları | Aynı |

## Sıkılaştırma: MITM, .NET ve PowerShell

`satsuma_win/hardening.py` (sahibinin kararı 2026-11-24). Her ayar yazılır, dakikada bir denetlenir ve değiştirilirse geri yazılır (`hardening_changed` kaydı). İlk yazmadan önce bulunan değerler `hardening-backup.json` dosyasına saklanır; `--uninstall` onları geri yükler.

| Konu | Ne yapılır | Neye karşı |
|---|---|---|
| IPv6 | `DisabledComponents=0xFF` (yeniden başlatınca), IPv6 her bağdaştırıcıdan hemen ayrılır, Teredo/6to4/ISATAP kapanır (Linux'taki gibi üç katman) | Sahte IPv6 yönlendirici ya da DHCPv6 yanıtı (mitm6) |
| LLMNR, mDNS, NetBIOS | `EnableMulticast=0`, `EnableMDNS=0`, her arayüzde `NetbiosOptions=2`, `NodeType=2` | Ad sorgusuna sahte yanıt (Responder) |
| WPAD | `DisableWpad=1`; vekil sunucu ayarları zaten `gateway` tarafından kaldırılıyor | Sahte otomatik vekil sunucu |
| DNS | OpenDNS'e DoH; adres Linux'un `satsuma/dns_encrypted.py` dosyasındakiyle aynı (`dns.opendns.com`, 443). İlke DoH'u zorunlu kılar (`DoHPolicy=3`), düz UDP'ye geri dönüş yoktur | Yolda DNS'i okuma ya da sahte yanıt |
| TCP/IP | Kaynak yönlendirme yok, ICMP yönlendirmesi yok, yönlendirici keşfi yok | Trafiğin başka yola saptırılması |
| .NET Framework | 2.0 ve 4.x için, 32 ve 64 bit: `SchUseStrongCrypto=1`, `SystemDefaultTlsVersions=1` | SSL 3 / TLS 1.0'a düşürme |
| PowerShell | Betik bloğu ve modül günlüğü açık (Windows PowerShell ve PowerShell 7); Windows PowerShell için ilkeyle AllSigned; PowerShell 2.0 motoru günde bir denetlenip kaldırılır | AMSI ve günlükten kaçan eski motor; imzasız betik dosyaları |

**Yeniden başlatma:** `DisabledComponents`, `EnableMDNS` ve `NodeType` yeniden başlatmadan sonra geçerli olur; bu kayıtta belirtilir. Satsuma'nın kendi PowerShell çağrıları `-Command` metinleridir, betik dosyası değildir; bu yüzden AllSigned onları etkilemez.

**Bilinen sınırlar:**
- Suricata, DoH'tan sonra DNS sorgularının içini göremez; Linux'ta da durum aynıdır.
- Hiçbiri gerçek bir Windows makinesinde henüz denenmedi.

## Sertifika deposu denetimi

`satsuma_win/certs.py` (sahibinin kararı 2026-11-24). Güvenilen köklere eklenen bir sertifika, anahtarına sahip olanın bu makinenin bütün TLS bağlantılarını okuyup değiştirmesini sağlar (MITM). Güvenilen yayıncılara eklenen bir sertifika ise kodunun güvenilir olarak çalışmasını sağlar. Depolar kayıt defterindeki fiziksel halleriyle okunur; böylece Microsoft'un otomatik kök güncellemeleri saldırı sanılmaz.

- **Sıkı depolar:** Makinenin, grup ilkesinin ve kuruluşun Root ve TrustedPublisher depoları ile oturum açmış her kullanıcının Root ve TrustedPublisher depoları.
  - İlk açılıştaki içerik taban çizgisi olur ve makine anahtarıyla imzalanır.
  - Sonradan eklenen ve onaylanmamış bir sertifika `cert-quarantine` klasörüne aktarılır, depodan silinir ve `cert_quarantined` olarak kaydedilir.
- **Yalnızca kaydedilenler:** AuthRoot (Microsoft'un otomatik kökleri) ve CA (ara sertifikalar). Eklemeler konu adıyla kaydedilir, hiçbir şey silinmez. Disallowed deposundan çıkarılan bir sertifika da kaydedilir.
- **Onay:** `--cert-approve PARMAK_İZİ` (yönetici) parmak izini onaylar ve karantinadaki sertifikayı geri koyar. Onay listesi makine anahtarıyla imzalıdır.
- **Kural:** `certutil -addstore root`, `Import-Certificate ... Cert:\...\Root` ve benzerlerini çalıştıran süreç `SATSUMA-WIN-031` kuralıyla durdurulur.

## Suricata IPS (WinDivert)

Suricata'yı ürünün kendisi kurar ve satır içi IPS olarak WinDivert kipinde çalıştırır (`satsuma_win/suricata.py`, sahibinin kararı 2026-11-24).

- **Kurulum:** Resmi OISF Windows WinDivert derlemesi (`Suricata-8.0.8-windivert-1-64bit.zip`) `--install` sırasında indirilir. Hizmet bulamazsa 10 dakikada bir yeniden dener.
  - **Arşiv özeti:** OISF özet yayımlamadığından GitHub'ın Windows sunucusu exe'yi derlerken aynı arşivi indirir ve SHA-256'sını exe'ye sabitler (`suricata-pin.json`). Sahibinin makinesinde özeti tutmayan arşiv kurulmaz; özet sabitlenmemiş exe hiçbir şey kurmaz.
  - **Sürücü imzası:** WinDivert sürücüsünün Authenticode imzası geçerli olmalıdır.
  - **Konum:** Dosyalar `C:\Program Files\Satsuma\Suricata\<sürüm>`, yapılandırma, kurallar ve günlükler `C:\ProgramData\Satsuma\suricata` altına gider.
- **Yapılandırma:** Linux'un kendi `satsuma.suricata_config.build()` koduyla kurulur: bu makinenin ağlarından HOME_NET, EVE günlüğü, satır içi akış, baypas yok. Windows'ta NFQUEUE ve unix soketi kullanılmaz. Sonuç kullanılmadan önce `suricata -T` ile denenir.
- **Kurallar:** Bu Suricata sürümünün ET Open seti indirilir (Linux'ta suricata-update'in kullandığı kaynak) ve yayımlanan MD5 ile denetlenir. Günde bir yenilenir.
  - Satır içi kipte yalnızca eylemi `drop` olan kural düşürür. Bu yüzden "confidence High" ve "signature_severity Major/Critical" işaretli ET kuralları düşürmeye çevrilir; geri kalanı uyarı olarak kalır.
  - Satsuma'nın kendi deneme kuralı yalnızca uydurma bir belirteci (`satsuma-ips-proof-7f3c9a1e`) düşürür.
- **Çalışma:** Suricata hizmetin alt sürecidir. Bir Windows iş nesnesi içinde, `--windivert "not loopback"` seçeneğiyle çalışır ve hizmetle birlikte kapanır. Bu makinenin bütün paketleri Suricata'dan geçer.
  - Suricata durursa WinDivert kapanır ve trafik denetimsiz akar. Hizmet bunu `suricata_exited` olarak kaydeder ve bir dakika içinde yeniden başlatır.
  - EVE uyarıları `suricata_alert` olarak kaydedilir.
- **Bilinen sınır:** WinDivert derlemesinin Npcap'e gerek duyup duymadığı GitHub'daki Windows kanıtında görülecek. Npcap'in yeniden dağıtımı lisans gerektirdiği için Satsuma onu kurmaz.

## Tarayıcı ilkeleri (Linux'tan uyarlandı)

Linux'taki `satsuma/browser_policy.py` ayarları Windows'a, ortak kodun kendisinden alınarak uygulanır (`satsuma_win/browser.py`, sahibinin isteği 2026-11-24):

- **Chrome, Brave ve Chromium:** İlkeler `HKLM\SOFTWARE\Policies` altına yazılır:
  - yalnızca HTTPS ve düz `http://` adreslerinin engellenmesi,
  - vekil sunucu yok,
  - bütün eklentilerin ve native messaging'in engellenmesi,
  - Safe Browsing uyarısının ve sertifika hatasının geçilememesi,
  - üçüncü taraf çerezlerin ve bildirimlerin kapatılması,
  - tarayıcının kendi DoH'unun ve yerleşik DNS istemcisinin kapatılması (Satsuma'nın DNS kilidini atlatamasın diye).
- **Edge:** Aynı ilkeler yazılır; Safe Browsing yerine SmartScreen açık tutulur ve sayfa ile indirmelerde geçilemez.
- **Firefox:** Linux'taki `policies.json` içeriği Program Files'taki Firefox'un `distribution\policies.json` dosyasına yazılır. Önceden bir dosya varsa yedeklenir ve ilgisiz anahtarları korunur.

Hizmet ilkeleri dakikada bir denetler ve değiştirileni geri yazar (`browser_policy_changed` kaydı). İlk yazmadan önce bulunan değerler `browser-policy-backup.json` dosyasına saklanır ve `--uninstall` onları geri yükler. Tarayıcı, değişen ilkeyi bir sonraki açılışında uygular. Ayrıca tarayıcının alt sürecinde çalışan indir-çalıştır kabuğu, Linux'taki `SATSUMA-BROWSER-001` kuralının karşılığı olan `SATSUMA-WIN-013` kuralıyla durdurulur. Her tarayıcıyla gerçek bir Windows makinesinde henüz denenmedi; tarayıcının tanımadığı ilke adını tarayıcı yok sayar.

## Kural motoru (ortak YAML dili)

İki ayrı motor aynı kural dilini okur: Linux'ta `satsuma/smart_rules.py`, Windows'ta `satsuma_win/rules.py` (sahibinin kararı 2026-11-24). Bir kural iki tarafta da aynı YAML eşlemesidir (`id, name, severity, classification, confidence, mitre, base_match, actions, ...`) ve aynı ortak şema denetiminden (`satsuma/rule_schema.py`) geçer. Değişen yalnızca olay alanlarıdır. Windows kuralları `rules/` klasöründedir (bu klasör, depo kökündeki Linux `rules/` klasörü değildir). Başlangıçta 66 kural var: çalıştırma, savunma atlatma, kalıcılık, kimlik bilgisi, keşif ve yanal hareket, komuta-denetim, etki.

**Olaylar:** Kurallar Sysmon olaylarını okur:

| Kaynak | Sysmon olayı |
|---|---|
| `win_proc` | 1 (süreç oluşturma) |
| `win_image` | 7 (DLL yükleme) |
| `win_remote_thread` | 8 (uzak iş parçacığı) |
| `win_process_access` | 10 (başka sürece erişim) |
| `win_tamper` | 25 (süreç kurcalama) |
| `win_network` | 3 (ağ bağlantısı) |
| `win_file` | 11 (dosya oluşturma) |
| `win_registry` | 12-14 (kayıt defteri) |
| `win_dns` | 22 (DNS sorgusu) |

Sysmon ayarı en üst düzeydedir (sahibinin kararı 2026-11-25): yalnızca kaydeden her olay türü süzgeçsiz ve muafiyetsiz kaydedilir; Satsuma'nın kendi programları ve Sysmon da muaf değildir. Satsuma'nın kendi salt okuma erişimleri Sysmon'a düşer ama hizmet bunları kodda yok sayar. Makineyi değiştiren türler (dosya engelleme, silinen dosya arşivi, pano yakalama) açılmaz. Olay günlüğü 1 GiB yapılır. Çok sık gelen DLL yükleme (7) ve süreç erişimi (10) olaylarında aynı süreç en çok 30 saniyede bir bellek taramasına girer; yeni süreç, uzak iş parçacığı ve kurcalama hemen taranır.

**Durdurma:** Eşleşmenin süreci durdurup durdurmadığına Linux'taki gibi ortak `satsuma.enforcement.eligible` karar verir. "suspicious" ve "likely" sınıfları durdurur; "indicator" sınıfı yalnızca kaydeder. Durdurma, olaydaki süreç numarası ve imge yolu yeniden karşılaştırılarak yapılır. Kritik Windows süreçleri, PID 0-4 ve hizmetin kendisi asla durdurulmaz. Satsuma'nın kendisi ve başlattığı programlar eşlenmez.

**Kayıt:** Her bulgu `events.jsonl` dosyasında `rule_finding` olarak durur; `outcome` alanı `stopped`, `recorded`, `not_stopped`, `stop_failed` ya da `critical` değerlerinden birini alır.

## DeepSeek kuralları (otomatik)

Kurallar DeepSeek'ten gelir (sahibinin kararları 2026-11-24). Her saldırı türü için en az 10 kural otomatik çekilir; 20 tür var. Her yerel denetimden geçen kural onay beklemeden devreye girer ve süreç durdurabilir.

- **Anahtar:** Yönetici PowerShell'de `& 'C:\Program Files\Satsuma\satsuma-core-windows.exe' --deepseek-key` komutuyla bir kez verilir. Hizmet anahtarı SYSTEM için DPAPI ile şifreleyip saklar; anahtar kayda ve kurallara asla girmez. Anahtarı vermek, otomatik çekmeye verilen onaydır; `--deepseek-off` anahtarı kaldırır.
- **İstekler:** DeepSeek ile yalnızca hizmet konuşur. Bunun için Linux'la aynı sabitlenmiş HTTPS istemcisini kullanır (tek adres, yönlendirme yok, sınırlı yanıt). Aynı anda tek istek gider, en sık 90 saniyede bir ve günde en çok 400 istek. Üç kez reddedilen tür 30 dakika bekler. Kota yanıtından sonra 1 saat beklenir. Anahtar reddedilirse yeni anahtar verilene kadar istek gitmez.
- **Denetimler:** Her kural şunlardan geçer:
  - ortak şema ve Windows motoru,
  - kendi kimliği (`SATSUMA-AI-WIN-...`) ve var olan bir kuralın tekrarı olmaması,
  - yalnızca record/evidence/correlation_request eylemleri,
  - süreci durduran bir sınıf,
  - doğrusal regex (Linux denemesi, alt süreçte),
  - DeepSeek'in yazdığı olumlu ve olumsuz deneme olaylarının Windows motorunda sınanması,
  - Satsuma'nın kendi komutlarıyla ve gündelik Windows olaylarıyla (`satsuma_win/corpus.py`) hiç eşleşmemesi.

  Reddedilen kural gerekçesiyle `refused.jsonl` dosyasına yazılır ve tür bu gerekçelerle yeniden sorulur.
- **İmza:** Geçen kural makine anahtarıyla imzalanır. İmzası tutmayan ya da elle yazılmış kural yüklenmez.
- **Durdurma sınırları:** Bir DeepSeek kuralı şunları asla durdurmaz: Windows klasöründeki sistem süreçleri, masaüstü, Defender, Sysmon ve Satsuma. Süreç kuralı, durdurmadan hemen önce aynı programın canlı komut satırında yeniden eşleşmelidir. Kural başına 10 dakikada en çok 5 durdurma yapılır; sonra kural 1 saat yalnızca kayıt tutar.
- **Komutlar (yönetici):**
  - `--rules`: paketli kurallar, DeepSeek durumu ve etkin kurallar
  - `--deepseek-now`: beklemeyi atlar
  - `--rule-report KİMLİK`: kuralı yalnızca kayıt tutar hale getirir
  - `--rule-disable KİMLİK`: kuralı kapatır
  - `--rule-enable KİMLİK`: kuralı yeniden açar
  - `--rule-remove KİMLİK`: kuralı siler

  Komutlar yalnızca bir istek yazar; hizmet bunu birkaç saniye içinde yerine getirir. Sahibinin kararları da makine anahtarıyla imzalanır.
- **Bilinen sınır:** Sahibinin sabit PTR kuralı DeepSeek'in adreslerine de uygulanır. Adresin PTR kaydı yoksa ve aynı ziyarette 5'ten fazla bağlantı olursa adres engellenebilir; o durumda istekler `network_or_response_error` ile kaydedilir.

## Bellek incelemesi (RAM-001, Linux 2.2.67 yöntemi)

Sahibinin kararı (2026-11-24): olmaması gereken yerden çalışan programın dosyasız yazılabilir+çalıştırılabilir (RWX) belleği görüldüğü an süreç istisnasız durdurulur. Olmaması gereken yer Temp, kullanıcı klasörü ya da Windows klasörü, Program Files ve parolayla onaylanmış klasörlerin dışındaki her yerdir. Aynısı, dosyasız bellekten iş parçacığı başlatan program için de geçerlidir. Yerinde olup böyle bir iş parçacığı olmayan program (.NET, Java, tarayıcı JIT'i) yalnızca kaydedilir, bekletilmez.

Durdurmadan önce kanıt toplanır:
1. Süreç bekletilir (`NtSuspendProcess`).
2. RWX bölgelerin baytları aynı tutamaçla okunur (`ReadProcessMemory`).
3. Baytlar Linux'un kendi değerlendirme koduyla yargılanır (`satsuma.ram.rwx_inspection`: ELF/PE görüntüsü, implant işaretleri, kabuk kodu, NOP kızağı, yoğun sistem çağrısı). Windows'a özgü işaretler de eklenir: dosyasız bellekten başlayan iş parçacığı (güçlü), PEB erişimi, ROR-13 API özeti, elle yazılmış sistem çağrısı saplaması (her biri orta).

Karar (kötü, temiz ya da belirsiz) ve işaretleri durdurma kaydına `inspection` alanında girer. Kötüyse kayıtta ayrıca `confirmation` alanı bulunur. Karar programı asla çalışır bırakmaz. Durdurma başarısız olursa süreç sürdürülür ve hata kaydedilir.

Bekletme güvenliği Linux'taki gibidir. Kimlik süreç numarası ve oluşturma zamanıdır. Bekletme en çok 10 saniye sürer ve bekçi süresi dolanı kendisi sürdürür. Her bekletme süreç durdurulmadan önce `holds.json` dosyasına yazılır; hizmet çökerse yeniden açılışta bekletilen süreçler sürdürülür. Kritik süreçler, hizmetin kendisi ve muaf süreçler hiç bekletilmez. Okunan bellek saklanmaz; kayda yalnızca boyut, adres, işaret adları ve SHA-256 özeti girer.

## Bellek imza taraması (RAM v2, ClamAV): kaldırıldı

RAM v2 üründen kaldırıldı (2026-11-24). Nedeni: clamd 127.0.0.1:3311'de şifresiz ve bağlananı denetlemeden dinliyordu; yerel her program ona ulaşabiliyordu. Satsuma artık ClamAV indirmez, clamd başlatmaz, 3311'de hiçbir şey dinlemez. SATSUMA-RAM-106/107 bulguları Windows'ta üretilmez. Davranış kuralları (RAM-001..009: RWX bellek, Temp'ten imzasız DLL vb.) ve derleme aracı engeli olduğu gibi çalışır.

Önceki sürümü kurulu makinede hizmet her açılışta, `--install` ve `--uninstall` sırasında `C:\Program Files\Satsuma\ClamAV` klasöründen hâlâ çalışan clamd/freshclam'ı durdurur, bu klasörü ve `C:\ProgramData\Satsuma\clamav` klasörünü siler. Sonuç `events.jsonl` içinde `startup_ram_v2_removed` olarak kaydedilir. Bu iki klasör dışındaki hiçbir şeye dokunulmaz. GitHub'daki derlemede hizmet kurulduktan sonra 3311'de dinleyen olmadığı, clamd çalışmadığı ve klasörlerin kalmadığı denetlenir.

## Hizmet olarak kurulum

Bekçi gerçek bir Windows hizmetidir: **Satsuma Core** (`SatsumaCore`). Otomatik başlar, LocalSystem olarak çalışır, durursa bir dakika içinde yeniden başlatılır. Exe `C:\Program Files\Satsuma` klasörüne kopyalanır; o klasöre yönetici ve SYSTEM dışında biri yazabiliyorsa kurulum reddedilir. Kurulum sihirbazı (Inno Setup) bunu kendisi yapar; elle: `satsuma-core-windows.exe --install`, durum `--status`, kaldırma `--uninstall`. GitHub'daki her derlemede hizmet Windows sunucusunda kurulup doğrulanır ve kaldırılır.

Her engel, Windows Güvenlik Duvarı kuralı geri okunup "etkin" görülünce başarılı sayılır. Her karar `%ProgramData%\Satsuma\events.jsonl` dosyasına yazılır; durum `state.json` dosyasındadır.

## Sonraki aşamalar

2. Süreç izleme ve durdurma (Sysmon olay günlüğü + Satsuma kural motoru; derleme aracı engeli dahil)
3. Dosya taraması ve bütünlük (Windows Defender / ClamAV; ayar dosyaları için örnek ve karşılaştırma)
4. Qt paneli
5. Kurulum paketi: GitHub Actions'ın Windows sunucusunda üretilir; kullanıcının makinesinde derleme yapılmaz

## Geliştirme

Testler sahte PowerShell ve sahte bağlantı tablosuyla Linux'ta da çalışır:

```sh
cd satsuma-core-windows && python3 -m pytest -q tests
```

Windows'ta deneme: GitHub Actions'ın ürettiği `satsuma-core-windows.exe` dosyasını yönetici PowerShell'de `satsuma-core-windows.exe --once` ile çalıştırın. Kaynaktan çalıştırmak için `satsuma-core-windows` klasöründe `$env:PYTHONPATH` depo kökünü gösterecek şekilde: `python -m satsuma_win.guard --once`.

---

Windows 11 counterpart of Satsuma Core 2.2.36, mostly Python, using Windows Firewall, the Windows DNS client and the Windows connection table. Stage 1 (network and interception protection) is implemented and unit-tested; it has not run on a real Windows 11 machine yet.
