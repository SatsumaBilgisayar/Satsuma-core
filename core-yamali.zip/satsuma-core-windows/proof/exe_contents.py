"""List the Python modules inside a PyInstaller one-file exe and refuse forbidden ones (CI).

Usage: python exe_contents.py dist/satsuma-core-windows.exe [--forbid PATTERN ...]
Exits 1 when a module name contains a forbidden pattern. Reads the exe; runs nothing in it.
Tek dosyalık exe'nin içindeki Python modüllerini listeler; yasaklı biri varsa 1 ile çıkar.
"""
import marshal
import struct
import sys

COOKIE = b'MEI\x0c\x0b\x0a\x0b\x0e'


def modules(path):
    data = open(path, 'rb').read()
    at = data.rfind(COOKIE)
    _, length, toc_at, toc_len, _version, _lib = struct.unpack('!8sIIII64s', data[at:at + 88])
    start = at + 88 - length
    toc = data[start + toc_at:start + toc_at + toc_len]
    names, position = [], 0
    while position < len(toc):
        size, offset, packed, _full, _flag, kind = struct.unpack('!IIIIBc', toc[position:position + 18])
        name = toc[position + 18:position + size].rstrip(b'\0').decode()
        position += size
        if kind == b'z':
            pyz = data[start + offset:start + offset + packed]
            table = struct.unpack('!i', pyz[8:12])[0]
            names.extend(entry[0] for entry in marshal.loads(pyz[table:]))
        elif kind in (b's', b'm'):
            names.append(name)
    return sorted(set(names))


def main(argv):
    path, forbid = argv[0], argv[argv.index('--forbid') + 1:] if '--forbid' in argv else []
    found = modules(path)
    ours = [n for n in found if n.startswith(('satsuma', 'satsuma_win'))]
    print(f'{path}: {len(found)} modules, {len(ours)} Satsuma modules')
    for name in ours:
        print('  ' + name)
    bad = [n for n in found if any(p in n for p in forbid)]
    for name in bad:
        print('FORBIDDEN ' + name)
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
