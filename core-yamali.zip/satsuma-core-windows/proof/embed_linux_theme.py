"""Build step: embed the Linux panel's theme.py and security_widgets.py as a module of the panel exe.
Derleme adımı: Linux panelinin iki dosyası exe'ye modül olarak gömülür (owner's approval 2026-11-25)."""
from pathlib import Path

root = Path(__file__).resolve().parents[2] / 'satsuma' / 'dashboard_qt'
sources = {'theme.py': (root / 'style' / 'theme.py').read_text(encoding='utf-8'),
           'security_widgets.py': (root / 'security_widgets.py').read_text(encoding='utf-8')}
target = Path(__file__).resolve().parents[1] / 'satsuma_win' / 'linux_theme_embedded.py'
target.write_text('SOURCES = ' + repr(sources) + '\n', encoding='utf-8')
print('embedded', sorted(sources), target)
