"""Harmless test programs for the memory proof on GitHub's Windows server; never shipped in the exe.

Each mode prepares one memory state the service must find, writes its process
id and waits. rwx_thread starts one thread in RWX memory that only runs
"pause; jump back" (it waits and does nothing else); nothing else is executed
from the prepared memory: rwx_private and
rwx_shared only allocate writable and executable memory (filled with zeros),
temp_dll loads a copy of Windows' own version.dll from the Temp folder with
its signature entry removed (unsigned, so it is stopped), signed_temp loads a
copy of the signed vcruntime140.dll from Temp and must survive (owner's
decision 2026-11-11), plain does nothing and must survive. Since 2026-11-24 the
code in RWX memory is judged before the stop, for the record (the Linux 2.2.67
method): rwx_private and rwx_shared hold only zeros and are recorded clean;
rwx_stager holds bytes shaped like a Windows stager (PEB access, ROR-13 hashing)
and rwx_implant the text of a known implant marker, recorded malicious; none is
ever executed, all of them run from the tool cache (not where a program should be)
and must be stopped.

GitHub'ın Windows sunucusundaki bellek kanıtı için zararsız deneme
programları; exe'ye konmaz. Her kip hizmetin bulması gereken bir bellek
durumu hazırlar, süreç numarasını yazar ve bekler. rwx_thread, RWX bellekte
yalnızca "bekle; geri dön" çalıştıran bir iş parçacığı başlatır (bekler,
başka hiçbir şey yapmaz); hazırlanan bellekten başka hiçbir şey
çalıştırılmaz: rwx_private ve rwx_shared yalnızca sıfırla dolu
yazılabilir+çalıştırılabilir bellek ayırır, temp_dll Windows'un kendi
version.dll dosyasının imza kaydı silinmiş Temp kopyasını yükler (imzasız,
durdurulur), signed_temp imzalı vcruntime140.dll'in Temp'teki
kopyasını yükler ve hayatta kalmalıdır (sahibinin kararı 2026-11-11), plain
hiçbir şey yapmaz ve hayatta kalmalıdır. 2026-11-24'ten beri RWX bellekteki kod
durdurmadan önce kayıt için değerlendirilir: rwx_private ve rwx_shared yalnızca sıfır
tutar, temiz kaydedilir; rwx_stager Windows hazırlayıcısına benzeyen baytlar,
rwx_implant bilinen bir implant işaretinin metnini tutar, kötü kaydedilir; hiçbiri
asla çalıştırılmaz, hepsi araç önbelleğinden (olmaması gereken yer) çalışır ve
durdurulmalıdır.
"""
import ctypes
import os
import shutil
import sys
import tempfile
import time
from ctypes import wintypes

kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
kernel32.VirtualAlloc.restype = ctypes.c_void_p
kernel32.VirtualAlloc.argtypes = (ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD, wintypes.DWORD)
kernel32.CreateFileMappingW.restype = wintypes.HANDLE
kernel32.CreateFileMappingW.argtypes = (wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD,
                                        wintypes.DWORD, wintypes.LPCWSTR)
kernel32.MapViewOfFile.restype = ctypes.c_void_p
kernel32.MapViewOfFile.argtypes = (wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, ctypes.c_size_t)


def strip_signature(path):
    """Remove the embedded signature entry so the copy is truly unsigned; the code is unchanged.

    Gömülü imza kaydını siler, kopya gerçekten imzasız olur; kod değişmez.
    """
    import struct
    with open(path, 'r+b') as stream:
        data = bytearray(stream.read())
        header = struct.unpack_from('<I', data, 0x3C)[0]
        optional = header + 24
        magic = struct.unpack_from('<H', data, optional)[0]
        directories = optional + (112 if magic == 0x20B else 96)
        struct.pack_into('<II', data, directories + 4 * 8, 0, 0)        # IMAGE_DIRECTORY_ENTRY_SECURITY
        stream.seek(0)
        stream.write(data)


def prepare(mode):
    if mode == 'rwx_private':
        address = kernel32.VirtualAlloc(None, 65536, 0x3000, 0x40)   # MEM_COMMIT|MEM_RESERVE, PAGE_EXECUTE_READWRITE
        if not address:
            raise OSError(ctypes.get_last_error(), 'VirtualAlloc')
    elif mode == 'rwx_thread':
        # A thread started in RWX memory running "pause; jump back": harmless, it only waits.
        # RWX bellekte başlatılan, yalnızca "bekle; geri dön" çalıştıran zararsız iş parçacığı.
        address = kernel32.VirtualAlloc(None, 65536, 0x3000, 0x40)
        if not address:
            raise OSError(ctypes.get_last_error(), 'VirtualAlloc')
        ctypes.memmove(address, b'\xf3\x90\xeb\xfc', 4)
        kernel32.CreateThread.restype = wintypes.HANDLE
        kernel32.CreateThread.argtypes = (ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_void_p,
                                          wintypes.DWORD, ctypes.c_void_p)
        if not kernel32.CreateThread(None, 0, address, None, 0, None):
            raise OSError(ctypes.get_last_error(), 'CreateThread')
    elif mode == 'rwx_shared':
        section = kernel32.CreateFileMappingW(wintypes.HANDLE(-1), None, 0x40, 0, 65536, None)
        if not section:
            raise OSError(ctypes.get_last_error(), 'CreateFileMappingW')
        if not kernel32.MapViewOfFile(section, 0x0002 | 0x0020, 0, 0, 65536):   # FILE_MAP_WRITE|FILE_MAP_EXECUTE
            raise OSError(ctypes.get_last_error(), 'MapViewOfFile')
    elif mode == 'temp_dll':
        folder = tempfile.mkdtemp(prefix='satsuma-proof-')
        copy = os.path.join(folder, 'proofver.dll')
        shutil.copyfile(os.path.join(os.environ['SystemRoot'], 'System32', 'version.dll'), copy)
        strip_signature(copy)
        ctypes.WinDLL(copy)
    elif mode == 'signed_temp':
        folder = tempfile.mkdtemp(prefix='satsuma-proof-')
        copy = os.path.join(folder, 'proofsigned.dll')
        shutil.copyfile(os.path.join(sys.base_prefix, 'vcruntime140.dll'), copy)
        ctypes.WinDLL(copy)
    elif mode in ('rwx_stager', 'rwx_implant'):
        # Never executed: only bytes for the inspection to read. Built reversed at run time.
        # Asla çalıştırılmaz: yalnızca incelemenin okuyacağı baytlar; çalışırken ters çevrilerek kurulur.
        if mode == 'rwx_stager':   # mov rax, gs:[60h]; ... ror edi, 0Dh
            content = bytes(reversed(b'\xc7\x01\x0d\xcf\xc1\xc0\x31\x00\x00\x00\x60\x25\x04\x8b\x48\x65\x90'))
        else:
            content = bytes(reversed(b'redaoLevitcelfeR')) + b'\x00'
        address = kernel32.VirtualAlloc(None, 65536, 0x3000, 0x40)   # PAGE_EXECUTE_READWRITE, never run
        if not address:
            raise OSError(ctypes.get_last_error(), 'VirtualAlloc')
        ctypes.memmove(address + 0x100, content, len(content))
    elif mode != 'plain':
        raise SystemExit('unknown mode ' + mode)


if __name__ == '__main__':
    mode, pid_file = sys.argv[1], sys.argv[2]
    prepare(mode)
    with open(pid_file, 'w', encoding='ascii') as stream:
        stream.write(str(os.getpid()))
    time.sleep(600)
