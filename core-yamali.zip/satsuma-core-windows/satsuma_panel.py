"""satsuma-panel.exe: the Satsuma Core Windows panel in the Linux panel's design. Linux tasarımlı Windows paneli."""
import sys

from satsuma_win.qt_panel import main

if __name__ == '__main__':
    sys.exit(main())
