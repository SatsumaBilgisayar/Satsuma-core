"""Firmware baseline: BIOS, TPM and boot measurements (owner's rule 2026-11-25). Ürün yazılımı taban çizgisi."""
import json
import struct

from satsuma_win import firmware
from tests.test_windows_upgrade import _Key

REG = {'bios_vendor': 'American Megatrends International, LLC.', 'bios_version': '2.M1', 'bios_date': '09/03/2024',
       'board_maker': 'Micro-Star International Co., Ltd.', 'board_model': 'B550M PRO-VDH WIFI (MS-7C95)',
       'secure_boot': 'açık'}


def capability_response(fw1=196700, fw2=5, maker=b'AMD '):
    props = [(0x105 + i, 0) for i in range(8)]
    props[0] = (0x105, int.from_bytes(maker, 'big'))
    props[6] = (0x10B, fw1)
    props[7] = (0x10C, fw2)
    body = b'\x00' + struct.pack('>II', 6, len(props)) + b''.join(struct.pack('>II', p, v) for p, v in props)
    return struct.pack('>HII', 0x8001, 10 + len(body), 0) + body


def pcr_response(pcr0=b'\x11' * 32, pcr7=b'\x77' * 32):
    body = struct.pack('>I', 42) + struct.pack('>IHB', 1, 0x000B, 3) + bytes([0x81, 0, 0])
    body += struct.pack('>I', 2) + struct.pack('>H', 32) + pcr0 + struct.pack('>H', 32) + pcr7
    return struct.pack('>HII', 0x8001, 10 + len(body), 0) + body


def fake_tpm(**kw):
    def submit(command):
        code = struct.unpack_from('>I', command, 6)[0]
        return capability_response(**{k: v for k, v in kw.items() if k in ('fw1', 'fw2', 'maker')}) if code == 0x17A \
            else pcr_response(**{k: v for k, v in kw.items() if k in ('pcr0', 'pcr7')})
    return submit


def test_tpm_commands_are_well_formed():
    cap = firmware.get_capability_command()
    assert struct.unpack('>HII', cap[:10]) == (0x8001, len(cap), 0x17A) and struct.unpack('>III', cap[10:]) == (6, 0x105, 8)
    pcr = firmware.pcr_read_command()
    assert struct.unpack('>HII', pcr[:10]) == (0x8001, len(pcr), 0x17E) and pcr[10:] == struct.pack('>IHB', 1, 0xB, 3) + bytes([0x81, 0, 0])


def test_tpm_reading_matches_what_windows_shows_for_the_owners_machine():
    facts = firmware.read_tpm(fake_tpm())
    # certutil showed "VendorID:'AMD ' -Firmware:196700.5", Windows Security "3.92.0.5".
    assert facts['tpm_maker'] == 'AMD' and facts['tpm_firmware'] == '3.92.0.5'
    assert facts['pcr0'] == '11' * 32 and facts['pcr7'] == '77' * 32


def test_a_tpm_error_code_is_an_error_never_a_value():
    bad = struct.pack('>HII', 0x8001, 10, 0x101)
    try:
        firmware.parse_properties(bad)
        assert False
    except ValueError:
        pass
    facts = firmware.read(registry=lambda: dict(REG), tpm=lambda: firmware.read_tpm(lambda c: bad))
    assert 'tpm_error' in facts and 'tpm_firmware' not in facts


def watch(tmp_path, **tpm):
    rec = []
    state = {'tpm': tpm, 'reg': dict(REG)}
    reader = lambda: firmware.read(registry=lambda: dict(state['reg']), tpm=lambda: firmware.read_tpm(fake_tpm(**state['tpm'])))
    w = firmware.Watch(tmp_path, _Key(), lambda k, **f: rec.append({'kind': k, **f}) or {'kind': k, **f}, reader=reader)
    return w, rec, state


def test_first_start_takes_a_signed_baseline_then_nothing_while_unchanged(tmp_path):
    w, rec, state = watch(tmp_path)
    assert w.check(force=True)['kind'] == 'firmware_baseline_taken'
    assert w.check(force=True) is None
    saved = json.loads((tmp_path / firmware.BASELINE).read_text(encoding='utf-8'))
    assert saved['facts']['tpm_firmware'] == '3.92.0.5' and saved['signature']


def test_a_changed_bios_or_tpm_version_0000_is_critical_naming_old_and_new(tmp_path):
    w, rec, state = watch(tmp_path)
    w.check(force=True)
    state['tpm'] = {'fw1': 0, 'fw2': 0}
    state['reg']['bios_version'] = '2.P2'
    event = w.check(force=True)
    assert event['kind'] == 'firmware_changed' and event['severity'] == 'critical'
    assert 'TPM firmware sürümü: 3.92.0.5 → 0.0.0.0' in event['summary']
    assert 'BIOS sürümü: 2.M1 → 2.P2' in event['summary']
    assert w.check(force=True) is None, 'the same difference is recorded once'
    state['tpm'] = {'fw1': 0, 'fw2': 0, 'pcr0': b'\x00' * 32}
    assert w.check(force=True)['kind'] == 'firmware_changed', 'a new difference is recorded again'
    # Satsuma never moves the baseline itself.
    assert json.loads((tmp_path / firmware.BASELINE).read_text(encoding='utf-8'))['facts']['bios_version'] == '2.M1'


def test_a_forged_baseline_is_critical(tmp_path):
    w, rec, state = watch(tmp_path)
    w.check(force=True)
    path = tmp_path / firmware.BASELINE
    body = json.loads(path.read_text(encoding='utf-8'))
    body['facts']['tpm_firmware'] = '0.0.0.0'
    path.write_text(json.dumps(body), encoding='utf-8')
    event = w.check(force=True)
    assert event['kind'] == 'firmware_changed' and 'imza' in event['reason']


def test_only_the_values_the_owner_saw_become_the_baseline(tmp_path):
    w, rec, state = watch(tmp_path)
    w.check(force=True)
    state['reg']['bios_version'] = '2.P2'
    seen = firmware.digest(w.reader())
    state['reg']['bios_version'] = '2.Z9'
    assert not w.approve(seen)['ok']
    state['reg']['bios_version'] = '2.P2'
    assert w.approve(seen)['ok']
    assert w.check(force=True) is None
    assert json.loads((tmp_path / firmware.BASELINE).read_text(encoding='utf-8'))['approved_by_owner'] is True


def test_unreadable_tpm_is_recorded_and_the_rest_still_compared(tmp_path):
    w, rec, state = watch(tmp_path)
    w.check(force=True)
    w.reader = lambda: firmware.read(registry=lambda: {**REG, 'bios_version': 'X'}, tpm=lambda: (_ for _ in ()).throw(OSError('no TPM')))
    event = w.check(force=True)
    kinds = [r['kind'] for r in rec]
    assert 'firmware_unreadable' in kinds and event['kind'] == 'firmware_changed'
    assert [d['field'] for d in event['changes']] == ['bios_version']


def test_hourly_not_every_poll(tmp_path):
    w, rec, state = watch(tmp_path)
    clock = [0.0]
    w.clock = lambda: clock[0]
    w.check()
    clock[0] = 100.0
    assert w.check() is None and len(rec) == 1


def test_no_baseline_from_values_that_could_not_be_read(tmp_path):
    w, rec, state = watch(tmp_path)
    good = w.reader
    w.reader = lambda: firmware.read(registry=lambda: dict(REG), tpm=lambda: (_ for _ in ()).throw(OSError('TBS busy')))
    w.check(force=True)
    assert not (tmp_path / firmware.BASELINE).exists() and rec[-1]['kind'] == 'firmware_unreadable'
    w.reader = good
    assert w.check(force=True)['kind'] == 'firmware_baseline_taken'
