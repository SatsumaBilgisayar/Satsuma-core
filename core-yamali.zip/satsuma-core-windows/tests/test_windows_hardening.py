"""Windows hardening: MITM paths closed (IPv6, LLMNR, NetBIOS, mDNS, WPAD, DoH, TCP/IP), .NET and PowerShell tightened.

Windows sıkılaştırması: MITM yolları kapanır, .NET ve PowerShell sıkılaştırılır.
"""
import json
from types import SimpleNamespace

from satsuma_win import hardening
from satsuma_win.browser import REG_DWORD, REG_SZ
from satsuma_win.hardening import DNS_POLICY, DNSCACHE, NETBT, PS_POLICY, TCPIP6, Hardening


class FakeRegistry:
    def __init__(self, keys=None):
        self.keys = {k: dict(v) for k, v in (keys or {}).items()}

    def read(self, path):
        return dict(self.keys[path]) if path in self.keys else None

    def write(self, path, name, kind, data):
        self.keys.setdefault(path, {})[name] = (kind, data)

    def delete(self, path, name):
        self.keys.get(path, {}).pop(name, None)

    def subkeys(self, path):
        prefix = path + '\\'
        return sorted({k[len(prefix):].split('\\')[0] for k in self.keys if k.startswith(prefix)})


class Windows:
    """The PowerShell side: IPv6 bindings, DoH entries, Teredo, PowerShell 2.0. PowerShell tarafı."""

    def __init__(self, bindings=('Ethernet', 'Wi-Fi'), doh=(), supported=True, ps2='Enabled'):
        self.bindings, self.doh, self.supported, self.ps2, self.teredo = list(bindings), list(doh), supported, ps2, 'Default'
        self.scripts = []

    def state(self):
        return {'ipv6_bindings': self.bindings, 'doh': self.doh, 'doh_supported': self.supported, 'teredo': self.teredo}

    def __call__(self, argv, **kwargs):
        script = argv[-1]
        self.scripts.append(script)
        if 'Get-WindowsOptionalFeature' in script:
            removed = ['MicrosoftWindowsPowerShellV2Root'] if self.ps2 == 'Enabled' else []
            self.ps2 = 'Disabled'
            return SimpleNamespace(returncode=0, stdout=json.dumps({'removed': removed, 'still_enabled': False}), stderr='')
        if 'Remove-DnsClientDohServerAddress' in script or 'Enable-NetAdapterBinding' in script:
            self.restored = script
            return SimpleNamespace(returncode=0, stdout="ok", stderr='')
        if 'Disable-NetAdapterBinding' in script:
            self.bindings, self.teredo = [], 'Disabled'
            if self.supported:
                self.doh = [{'server': s, 'template': hardening.DOH_TEMPLATE, 'fallback': False, 'auto': True}
                            for s in hardening.SERVERS]
        return SimpleNamespace(returncode=0, stdout=json.dumps(self.state()), stderr='')


def make(tmp_path, registry=None, windows=None):
    reg = registry or FakeRegistry({NETBT + r'\Interfaces\Tcpip_{1111}': {'NetbiosOptions': (REG_DWORD, 0)}})
    win = windows or Windows()
    return Hardening(tmp_path, registry=reg, runner=win, clock=lambda: 1_800_000_000), reg, win


def test_every_mitm_path_is_closed_and_reported(tmp_path):
    h, reg, win = make(tmp_path)
    result = h.apply()
    assert result['ok'] and result['status'] == 'LOCKED' and result['doh_supported']
    assert reg.keys[TCPIP6]['DisabledComponents'] == (REG_DWORD, 0xFF)
    assert reg.keys[DNS_POLICY]['EnableMulticast'] == (REG_DWORD, 0)
    assert reg.keys[DNS_POLICY]['DoHPolicy'] == (REG_DWORD, 3)
    assert reg.keys[DNSCACHE]['EnableMDNS'] == (REG_DWORD, 0)
    assert reg.keys[NETBT + r'\Interfaces\Tcpip_{1111}']['NetbiosOptions'] == (REG_DWORD, 2)
    assert reg.keys[r'SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\WinHttp']['DisableWpad'] == (REG_DWORD, 1)
    applied = win.scripts[1]
    assert 'Disable-NetAdapterBinding' in applied and 'Add-DnsClientDohServerAddress' in applied
    assert '-AllowFallbackToUdp $false' in applied and hardening.DOH_TEMPLATE in applied
    assert 'icmpredirects=disabled' in applied and 'Set-NetTeredoConfiguration -Type Disabled' in applied
    assert TCPIP6 + '\\DisabledComponents' in result['restart_needed_for']
    assert h.status() == {'ok': True, 'differs': [], 'live': []}


def test_dotnet_and_powershell_are_tightened(tmp_path):
    h, reg, win = make(tmp_path)
    h.apply()
    for root in (r'SOFTWARE\Microsoft\.NETFramework', r'SOFTWARE\WOW6432Node\Microsoft\.NETFramework'):
        for version in ('v4.0.30319', 'v2.0.50727'):
            assert reg.keys[root + '\\' + version]['SchUseStrongCrypto'] == (REG_DWORD, 1)
            assert reg.keys[root + '\\' + version]['SystemDefaultTlsVersions'] == (REG_DWORD, 1)
    assert reg.keys[PS_POLICY + r'\ScriptBlockLogging']['EnableScriptBlockLogging'] == (REG_DWORD, 1)
    assert reg.keys[PS_POLICY]['ExecutionPolicy'] == (REG_SZ, 'AllSigned')
    assert reg.keys[PS_POLICY + r'\ModuleLogging\ModuleNames']['*'] == (REG_SZ, '*')
    assert reg.keys[r'SOFTWARE\Policies\Microsoft\PowerShellCore\ScriptBlockLogging']['EnableScriptBlockLogging'] == (REG_DWORD, 1)
    first = h.check_ps2(force=True)
    assert first['ok'] and first['removed'] == ['MicrosoftWindowsPowerShellV2Root']
    assert h.check_ps2() is None, 'DISM runs once a day'


def test_a_changed_value_or_a_rebound_ipv6_is_seen_and_written_back(tmp_path):
    h, reg, win = make(tmp_path)
    h.apply()
    reg.write(DNS_POLICY, 'EnableMulticast', REG_DWORD, 1)
    win.bindings = ['Ethernet']
    state = h.status()
    assert not state['ok'] and DNS_POLICY + '\\EnableMulticast' in state['differs'] and state['live'] == ['ipv6_bound:Ethernet']
    assert h.apply()['ok'] and reg.keys[DNS_POLICY]['EnableMulticast'] == (REG_DWORD, 0)


def test_a_doh_entry_with_fallback_to_plain_dns_counts_as_missing(tmp_path):
    h, reg, win = make(tmp_path)
    h.apply()
    win.doh = [{'server': hardening.SERVERS[0], 'template': hardening.DOH_TEMPLATE, 'fallback': True}]
    assert any(item.startswith('doh_missing:') for item in h.status()['live'])


def test_a_windows_without_doh_is_reported_and_still_locks_the_rest(tmp_path):
    h, reg, win = make(tmp_path, windows=Windows(supported=False))
    result = h.apply()
    assert result['ok'] and result['doh_supported'] is False


def test_uninstall_restores_what_was_there(tmp_path):
    reg = FakeRegistry({DNSCACHE: {'EnableMDNS': (REG_DWORD, 1)}, NETBT + r'\Interfaces\Tcpip_{1111}': {}})
    h, reg, win = make(tmp_path, registry=reg)
    h.apply()
    assert h.restore()['status'] == 'RESTORED'
    assert reg.keys[DNSCACHE]['EnableMDNS'] == (REG_DWORD, 1)
    assert 'DisabledComponents' not in reg.keys.get(TCPIP6, {})
    assert "Enable-NetAdapterBinding -Name 'Ethernet'" in win.restored and 'Remove-DnsClientDohServerAddress' in win.restored
    assert h.restore()['status'] == 'NOTHING_TO_RESTORE'


def test_the_guard_writes_back_every_minute(tmp_path):
    from satsuma_win.guard import Guard
    times = [100.0]
    reg = FakeRegistry()
    win = Windows()
    ok = lambda argv, **kw: SimpleNamespace(returncode=0, stdout='{}', stderr='')
    g = Guard(runner=ok, read=lambda: [], clock=lambda: times[0], directory=tmp_path, echo=lambda *_: None,
              hardening_factory=lambda directory: Hardening(directory, registry=reg, runner=win))
    g.start()
    assert g.startup['hardening']['ok'] and g.startup['hardening']['powershell_v2']['ok']
    reg.write(TCPIP6, 'DisabledComponents', REG_DWORD, 0)
    times[0] += 61
    g.check_hardening()
    assert reg.keys[TCPIP6]['DisabledComponents'] == (REG_DWORD, 0xFF) and g.counts['hardening_restored'] == 1
    assert '"hardening_changed"' in (tmp_path / 'events.jsonl').read_text()


def test_satsumas_own_commands_still_run_under_allsigned():
    """AllSigned governs script files; Satsuma runs -Command strings only, never a .ps1 file."""
    from satsuma_win import firewall
    assert firewall.POWERSHELL[-1] == '-Command' and '-File' not in firewall.POWERSHELL
