"""Browser policies on Windows: the Linux settings, written to the registry and Firefox, kept, restored.

Windows'ta tarayıcı ilkeleri: Linux ayarları kayıt defterine ve Firefox'a yazılır, korunur, geri yüklenir.
"""
import json

from satsuma.browser_policy import FIREFOX_PATH, chromium_policy, merged
from satsuma_win import browser
from satsuma_win.browser import CHROMIUM_KEYS, REG_DWORD, REG_SZ, BrowserPolicy

CHROME, EDGE = CHROMIUM_KEYS['chrome'], CHROMIUM_KEYS['edge']


class FakeRegistry:
    def __init__(self, keys=None):
        self.keys = {k: dict(v) for k, v in (keys or {}).items()}

    def read(self, path):
        return dict(self.keys[path]) if path in self.keys else None

    def write(self, path, name, kind, data):
        self.keys.setdefault(path, {})[name] = (kind, data)

    def delete(self, path, name):
        self.keys.get(path, {}).pop(name, None)


def firefox(tmp_path):
    folder = tmp_path / 'Mozilla Firefox'
    folder.mkdir()
    (folder / 'firefox.exe').write_bytes(b'MZ')
    return folder


def make(tmp_path, registry=None, fx=None):
    reg = registry or FakeRegistry()
    folders = [fx] if fx else []
    return BrowserPolicy(tmp_path / 'state', registry=reg, firefox=lambda: folders, clock=lambda: 1_800_000_000), reg


def test_the_chromium_settings_are_the_linux_ones_plus_the_windows_names():
    linux = chromium_policy()
    chrome = browser.chromium_settings()
    for name in ('ProxyMode', 'HttpsOnlyMode', 'URLBlocklist', 'NativeMessagingBlocklist', 'BlockThirdPartyCookies',
                 'DnsOverHttpsMode', 'BuiltInDnsClientEnabled', 'SafeBrowsingProtectionLevel'):
        assert chrome[name] == linux[name], name
    assert chrome['ExtensionSettings'] == {'*': {'installation_mode': 'blocked'}}, 'no GNOME connector id on Windows'
    assert chrome['SSLErrorOverrideAllowed'] is False
    edge = browser.edge_settings()
    assert edge['SmartScreenEnabled'] and edge['PreventSmartScreenPromptOverrideForFiles']
    assert 'SafeBrowsingProtectionLevel' not in edge and edge['DnsOverHttpsMode'] == 'off'


def test_policies_become_registry_values_lists_subkeys_objects_json():
    values, lists = browser.registry_values({'A': True, 'B': 2, 'C': 'x', 'D': ['http://*'], 'E': {'*': {'m': 'b'}}})
    assert values == {'A': (REG_DWORD, 1), 'B': (REG_DWORD, 2), 'C': (REG_SZ, 'x'), 'E': (REG_SZ, '{"*":{"m":"b"}}')}
    assert lists == {'D': ['http://*']}


def test_apply_writes_every_browser_and_a_changed_value_is_written_back(tmp_path):
    policy, reg = make(tmp_path)
    result = policy.apply()
    assert result['ok'] and result['requires_browser_restart']
    assert reg.keys[CHROME]['ProxyMode'] == (REG_SZ, 'direct') and reg.keys[CHROME + '\\URLBlocklist'] == {'1': (REG_SZ, 'http://*')}
    assert reg.keys[EDGE]['SmartScreenEnabled'] == (REG_DWORD, 1)
    assert set(CHROMIUM_KEYS.values()) <= set(reg.keys)
    assert policy.status() == {'ok': True, 'differs': []}
    reg.write(CHROME, 'ProxyMode', REG_SZ, 'fixed_servers')
    reg.write(CHROME + '\\URLBlocklist', '2', REG_SZ, 'x')
    assert set(policy.status()['differs']) == {CHROME + '\\ProxyMode', CHROME + '\\URLBlocklist'}
    assert policy.apply()['ok'] and reg.keys[CHROME]['ProxyMode'] == (REG_SZ, 'direct')
    assert reg.keys[CHROME + '\\URLBlocklist'] == {'1': (REG_SZ, 'http://*')}


def test_uninstall_restores_what_was_there_and_keeps_unrelated_policies(tmp_path):
    reg = FakeRegistry({CHROME: {'ProxyMode': (REG_SZ, 'system'), 'HomepageLocation': (REG_SZ, 'https://x')}})
    policy, reg = make(tmp_path, reg)
    policy.apply()
    assert reg.keys[CHROME]['HomepageLocation'] == (REG_SZ, 'https://x')
    assert policy.restore()['status'] == 'RESTORED'
    assert reg.keys[CHROME] == {'ProxyMode': (REG_SZ, 'system'), 'HomepageLocation': (REG_SZ, 'https://x')}
    assert reg.keys.get(EDGE, {}) == {} and reg.keys.get(CHROME + '\\URLBlocklist', {}) == {}
    assert policy.restore()['status'] == 'NOTHING_TO_RESTORE'


def test_firefox_gets_the_linux_policies_json_kept_backed_up_and_restored(tmp_path):
    fx = firefox(tmp_path)
    (fx / 'distribution').mkdir()
    original = {'policies': {'DisableTelemetry': True}}
    (fx / 'distribution' / 'policies.json').write_text(json.dumps(original))
    policy, _ = make(tmp_path, fx=fx)
    assert policy.apply()['ok']
    written = json.loads((fx / 'distribution' / 'policies.json').read_text())
    assert written == merged(FIREFOX_PATH, original) and written['policies']['DisableTelemetry'] is True
    assert written['policies']['DNSOverHTTPS'] == {'Enabled': False, 'Locked': True}
    assert list((fx / 'distribution').glob('policies.json.satsuma-backup-*'))
    policy.restore()
    assert json.loads((fx / 'distribution' / 'policies.json').read_text()) == original


def test_a_firefox_without_a_policy_file_gets_one_and_loses_it_at_uninstall(tmp_path):
    fx = firefox(tmp_path)
    policy, _ = make(tmp_path, fx=fx)
    policy.apply()
    assert (fx / 'distribution' / 'policies.json').exists()
    policy.restore()
    assert not (fx / 'distribution' / 'policies.json').exists()


def test_the_guard_writes_back_a_changed_policy_every_minute(tmp_path):
    from types import SimpleNamespace
    from satsuma_win.guard import Guard
    times = [100.0]
    reg = FakeRegistry()
    ok = lambda argv, **kw: SimpleNamespace(returncode=0, stdout='{}', stderr='')
    g = Guard(runner=ok, read=lambda: [], clock=lambda: times[0], directory=tmp_path, echo=lambda *_: None,
              browser_factory=lambda directory: BrowserPolicy(directory, registry=reg, firefox=lambda: []))
    g.start()
    assert g.startup['browser_policy']['ok']
    reg.write(EDGE, 'SmartScreenEnabled', REG_DWORD, 0)
    times[0] += 61
    g.check_browser()
    assert reg.keys[EDGE]['SmartScreenEnabled'] == (REG_DWORD, 1) and g.counts['browser_policy_restored'] == 1
    assert '"browser_policy_changed"' in (tmp_path / 'events.jsonl').read_text()
