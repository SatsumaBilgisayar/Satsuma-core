"""Owner requests: unblock, allow list, folder and device approval. Sahip istekleri."""
from satsuma_win import fwauto, owner_requests


class Key:
    def sign(self, data):
        return 'S' + str(len(data))

    def verify(self, data, sig):
        return sig == 'S' + str(len(data))


def make(tmp_path):
    rec = []
    fw = fwauto.FirewallAuto(tmp_path, Key(), lambda k, **f: rec.append((k, f)) or f, runner=None)
    calls = {'unblock': [], 'loc': [], 'dev': [], 'enable': []}
    applier = owner_requests.Applier(
        tmp_path, Key(), lambda k, **f: rec.append((k, f)) or f, fw,
        lambda ip: calls['unblock'].append(ip) or True,
        lambda d, folder, key: calls['loc'].append(folder) or folder,
        lambda d, device, key: calls['dev'].append(device), lambda device: calls['enable'].append(device))
    return fw, applier, calls, rec


def test_unblock_removes_rules_forgets_and_allows(tmp_path):
    fw, applier, calls, rec = make(tmp_path)
    fw.add('203.0.113.9', 'otx'); fw.add('198.51.100.7', 'otx'); fw.add('192.0.2.5', 'no_ptr_connection_flood')
    owner_requests.write(tmp_path, 'unblock', ip='192.0.2.5')
    owner_requests.write(tmp_path, 'unblock_rule', rule='otx')
    events = applier.run()
    assert [e['action'] for e in events] == ['unblock', 'unblock_rule'] and all(e['ok'] for e in events)
    assert sorted(calls['unblock']) == ['192.0.2.5', '198.51.100.7', '203.0.113.9']
    assert fw.blocks() == {} and set(fw.allowed()) == {'192.0.2.5', '198.51.100.7', '203.0.113.9'}
    assert owner_requests.pending(tmp_path) == []


def test_location_and_device_and_bad_requests(tmp_path):
    fw, applier, calls, rec = make(tmp_path)
    owner_requests.write(tmp_path, 'approve_location', folder='C:\\Users\\a\\AppData\\Local\\Programs\\Opera')
    owner_requests.write(tmp_path, 'approve_device', id='SWD\\MSRRAS\\MS_SSTPMINIPORT')
    (tmp_path / 'requests' / 'zz-bad.json').write_text('{oops', encoding='utf-8')
    events = applier.run()
    assert calls['loc'] and calls['dev'] == calls['enable'] == ['SWD\\MSRRAS\\MS_SSTPMINIPORT']
    assert [e['ok'] for e in events] == [True, True, False]


def test_tampered_allow_list_is_ignored(tmp_path):
    fw, applier, calls, rec = make(tmp_path)
    fw.allow('203.0.113.9')
    data = (tmp_path / 'allowed.json').read_text().replace('203.0.113.9', '203.0.113.10')
    (tmp_path / 'allowed.json').write_text(data)
    assert fw.allowed() == {} or '203.0.113.10' not in fw.allowed()
