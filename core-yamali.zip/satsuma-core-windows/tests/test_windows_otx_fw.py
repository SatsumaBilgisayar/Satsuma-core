"""PTR/OTX connection end, OTX decision, firewall auto-config. PTR/OTX bağlantı sonlandırma, OTX kararı, güvenlik duvarı."""
import json
from types import SimpleNamespace as NS

from satsuma_win import connkill, fwauto, otx


def conn(raddr, status='ESTABLISHED'):
    return NS(status=status, laddr=('10.0.0.5', 50000), raddr=raddr, pid=42)


def test_kill_ends_only_established_connections_to_that_address():
    gone = []
    out = connkill.kill('203.0.113.9', [conn(('203.0.113.9', 443)), conn(('203.0.113.9', 80), 'TIME_WAIT'),
                                        conn(('198.51.100.1', 443)), conn(())], delete=gone.append)
    assert [c['remote_port'] for c in out['ended']] == [443] and gone and not out['failed']


def test_kill_records_failures():
    def boom(c):
        raise OSError(5, 'denied')
    assert connkill.kill('203.0.113.9', [conn(('203.0.113.9', 443))], delete=boom)['failed']


class Key:
    def sign(self, data):
        return 'S' + str(len(data))

    def verify(self, data, sig):
        return sig == 'S' + str(len(data))


def test_block_list_is_signed_and_tampering_is_rejected(tmp_path):
    rec = []
    fw = fwauto.FirewallAuto(tmp_path, Key(), lambda k, **f: rec.append(k) or f, runner=None)
    assert fw.add('203.0.113.9', 'ptr') and fw.blocks()['203.0.113.9']['reason'] == 'ptr'
    data = json.loads((tmp_path / 'blocks.json').read_text())
    data['rows']['198.51.100.7'] = {'reason': 'x'}
    (tmp_path / 'blocks.json').write_text(json.dumps(data))
    assert fw.blocks() == {} and 'firewall_block_list_rejected' in rec


def test_profiles_ok_needs_all_three_locked():
    good = {'enabled': 'True', 'inbound': 'Block', 'blocked': 'True', 'notify': 'False'}
    assert fwauto.profiles_ok([good] * 3) and not fwauto.profiles_ok([good, good, {**good, 'inbound': 'NotConfigured'}])


def test_otx_blocks_on_linux_decision_and_keeps_protected_open(tmp_path):
    blocked, rec = [], []
    items = {'203.0.113.9': {'ip': '203.0.113.9', 'pulse_count': 30, 'tls_verified': True},
             '192.168.1.1': {'ip': '192.168.1.1', 'pulse_count': 30, 'tls_verified': True}}
    o = otx.Otx(tmp_path, lambda k, **f: rec.append(k) or f, lambda ip, r, **e: blocked.append(ip),
                lambda ip: 'gateway' if ip == '192.168.1.1' else None, query=lambda ip, k: items[ip],
                unprotect=lambda b: b, protect=lambda b: b, threads=False)
    o.decide = lambda item: (item['pulse_count'] >= 11, 'threshold')
    (tmp_path / otx.KEY_FILE).write_bytes(b'k' * 20)
    o.check([{'remote': '203.0.113.9'}, {'remote': '192.168.1.1'}])
    o.check([])
    assert blocked == ['203.0.113.9'] and o.counts['queried'] == 1


def test_otx_uses_the_linux_should_block():
    from satsuma import otx as linux
    assert linux.MIN_BLOCK_PULSES == 2 and callable(linux._should_block)


class FakeRules:
    """Windows Firewall rules by name: enabled and action, as Get-NetFirewallRule reports them."""
    def __init__(self):
        self.rules, self.removed = {}, []

    def run(self, script, runner=None, **_):
        if script.startswith('@(Get-NetFirewallRule'):
            return json.dumps([{'name': n, 'enabled': e, 'action': a} for n, (e, a) in self.rules.items()
                               if "'" + n + "'" in script])
        if script.startswith('Remove-NetFirewallRule'):
            for name in list(self.rules):
                if "'" + name + "'" in script:
                    self.rules.pop(name)
                    self.removed.append(name)
        return ''

    def block(self, ip, reason, runner=None):
        for name in fwauto.firewall.rule_names(ip):
            self.rules.setdefault(name, ('True', 'Block'))
        return {'ok': True}


def kept_block(tmp_path, monkeypatch):
    fake, rec = FakeRules(), []
    monkeypatch.setattr(fwauto.firewall, 'run_powershell', fake.run)
    monkeypatch.setattr(fwauto.firewall, 'block_ip', fake.block)
    fw = fwauto.FirewallAuto(tmp_path, Key(), lambda k, **f: rec.append((k, f)) or {'kind': k, **f}, runner=None)
    fw.add('160.79.104.10', 'no_ptr_connection_flood')
    fake.block('160.79.104.10', 'x')
    return fw, fake, rec


def test_a_disabled_block_rule_is_turned_back_on_with_a_critical_record(tmp_path, monkeypatch):
    fw, fake, rec = kept_block(tmp_path, monkeypatch)
    out, inn = fwauto.firewall.rule_names('160.79.104.10')
    assert fw.restore_blocks() == []
    fake.rules[out] = ('False', 'Block')
    fake.rules[inn] = ('False', 'Block')
    events = fw.restore_blocks()
    assert [e['kind'] for e in events] == ['firewall_block_disabled']
    assert events[0]['severity'] == 'critical' and events[0]['rules'] == {out: 'kapatılmış', inn: 'kapatılmış'}
    assert fake.rules[out] == ('True', 'Block') and fake.rules[inn] == ('True', 'Block')


def test_a_block_rule_turned_to_allow_or_one_deleted_is_caught(tmp_path, monkeypatch):
    fw, fake, rec = kept_block(tmp_path, monkeypatch)
    out, inn = fwauto.firewall.rule_names('160.79.104.10')
    fake.rules[inn] = ('True', 'Allow')
    events = fw.restore_blocks()
    assert events[0]['kind'] == 'firewall_block_disabled' and 'engellemiyor' in events[0]['rules'][inn]
    assert fake.rules[inn] == ('True', 'Block')
    fake.rules.pop(inn)
    events = fw.restore_blocks()
    assert events[0]['kind'] == 'firewall_block_restored' and events[0]['rules'] == [inn]


def test_owner_unblock_is_not_reported(tmp_path, monkeypatch):
    fw, fake, rec = kept_block(tmp_path, monkeypatch)
    assert fw.forget('160.79.104.10')
    fake.run(fwauto.remove_script('160.79.104.10'))
    assert fw.restore_blocks() == []


def test_panel_shows_disabled_block_as_alert():
    from satsuma_win import panel_data
    d = panel_data.describe({'time': 0, 'kind': 'firewall_block_disabled', 'severity': 'critical', 'ip': '160.79.104.10',
                             'rules': {'Satsuma-Block-160.79.104.10-Out': 'kapatılmış'}, 'restored': True})
    assert d['level'] == 'alert' and d['badge'] == 'Geri açıldı' and 'kapatılmış' in d['what']
