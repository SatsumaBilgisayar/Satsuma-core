"""Sysmon configuration (owner's decision 2026-11-25): the maximal one, no filter and no exemption."""
import xml.etree.ElementTree as ET

from satsuma_win import sysmon

RECORDING = {'ProcessCreate', 'FileCreateTime', 'NetworkConnect', 'ProcessTerminate', 'DriverLoad', 'ImageLoad',
             'CreateRemoteThread', 'RawAccessRead', 'ProcessAccess', 'FileCreate', 'RegistryEvent',
             'FileCreateStreamHash', 'PipeEvent', 'WmiEvent', 'DnsQuery', 'FileDeleteDetected',
             'ProcessTampering', 'FileExecutableDetected'}


def test_every_recording_event_type_is_on_with_an_empty_exclude_list():
    root = ET.fromstring(sysmon.CONFIG)
    groups = {rule.tag: rule for group in root.iter('RuleGroup') for rule in group}
    assert set(groups) == RECORDING
    for tag, rule in groups.items():
        assert rule.get('onmatch') == 'exclude' and len(rule) == 0 and not (rule.text or '').strip(), tag


def test_nothing_is_exempt_not_even_satsuma_or_sysmon():
    for name in ('Program Files', 'Sysmon64', 'lsass', '<Rule ', '<Rule>', '<Image ', '<Image>', 'SourceImage', 'GrantedAccess'):
        assert name not in sysmon.CONFIG, name


def test_types_that_change_the_machine_stay_off():
    for tag in ('FileBlockExecutable', 'FileBlockShredding', 'FileDelete ', 'FileDelete>', 'ClipboardChange'):
        assert '<' + tag not in sysmon.CONFIG, tag
    assert '<FileDeleteDetected onmatch="exclude" />' in sysmon.CONFIG


def test_the_sha256_the_lineage_check_reads_is_still_recorded():
    assert '<HashAlgorithms>SHA256</HashAlgorithms>' in sysmon.CONFIG
