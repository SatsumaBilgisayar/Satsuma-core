"""Panel data: what the single page shows. Panel verisi: tek sayfanın gösterdikleri."""
import json

from satsuma_win import panel_data as p

NOW = 1795500000.0


def ev(kind, t, **f):
    return {'kind': kind, 'time': NOW - t, **f}


EVENTS = [
    ev('otx_key', 900, ok=True),
    ev('blocked', 800, ip='203.0.113.9', rule='otx', otx={'pulse_count': 30, 'reason': 'x'}),
    ev('blocked', 700, ip='198.51.100.7', rule='no_ptr_connection_flood', connections_ended=2),
    ev('memory_finding', 600, image='C:\\Users\\a\\AppData\\Local\\Temp\\x.exe', outcome='stopped', rule_id='SATSUMA-RAM-001'),
    ev('memory_finding', 590, image='C:\\Program Files\\b.exe', outcome='recorded', rule_id='SATSUMA-RAM-001'),
    ev('suricata_alert', 500, signature='ET SCAN', src='10.0.0.2', dest='192.0.2.1', dest_port=22, action='allowed'),
    ev('mitm_proxy_set', 400, proxies=['127.0.0.1:1']),
    ev('accounts_not_applied', 300, ok=False), ev('accounts_not_applied', 200, ok=False),
    ev('suricata_install', 150, ok=False, status='CONFIG_REJECTED'),
    ev('startup_sysmon', 120, ok=False), ev('startup_sysmon', 100, ok=True),
]


def test_summary_lists_and_problems():
    s = p.summary(EVENTS, {'updated_at': NOW - 30}, {'service': 'running', 'sysmon': 'running', 'suricata_pid': 7}, now=NOW)
    assert [r['cols'][0] for r in s['blocks']] == ['198.51.100.7', '203.0.113.9']
    assert [r['cols'][0] for r in s['stops']] == ['x.exe']
    assert {r['event']['kind'] for r in s['alerts']} == {'suricata_alert', 'mitm_proxy_set'}
    problems = {r['cols'][0]: r['cols'][1] for r in s['problems']}
    assert problems == {'accounts_not_applied': 2}          # fixed sysmon and running suricata are not problems
    tiles = {t['name']: t['level'] for t in s['tiles']}
    assert tiles['Hizmet'] == 'ok' and tiles['Suricata'] == 'ok' and tiles['Araya girme (24 sa)'] == 'warn'
    assert s['recent'][0]['event']['kind'] == 'startup_sysmon'


def test_stale_service_state_is_bad():
    s = p.summary(EVENTS, {'updated_at': NOW - 3600}, {'service': 'running'}, now=NOW)
    assert next(t for t in s['tiles'] if t['name'] == 'Hizmet')['level'] == 'bad'


def test_tail_reads_only_the_end_and_skips_bad_lines(tmp_path):
    path = tmp_path / 'events.jsonl'
    lines = [json.dumps({'kind': 'k', 'time': i, 'n': i}) for i in range(5000)] + ['{broken', '[1]']
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    events = p.load_events(path, count=100)
    assert len(events) == 98 and events[-1]['n'] == 4999
    assert p.load_events(tmp_path / 'missing.jsonl') == []


def test_panel_fixture_reads_in_plain_turkish(tmp_path):
    import shutil
    from pathlib import Path
    shutil.copy(Path(__file__).parent / 'fixtures' / 'panel_events.jsonl', tmp_path / 'events.jsonl')
    data = p.read_panel(tmp_path)
    titles = [w['title'] for w in data['waiting']]
    assert any('Browser' in t for t in titles) and not any('Temp' in t or 'x:' in t for t in titles)
    assert any(r['d']['badge'] == 'Engellendi' and r['d']['actions'] for r in data['feed'])
    assert len(data['devices']) == 2 and all(p.builtin_device(d['id']) for d in data['devices']) and len(data['layers']) == 8


def test_important_records_stay_in_the_panel_whatever_the_noise(tmp_path):
    import json as _json
    from satsuma_win import panel_data
    from satsuma_win.guard import important
    blocked = {'time': 1.0, 'kind': 'blocked', 'ip': '203.0.113.7'}
    noise = [{'time': 2.0 + i, 'kind': 'memory_exempt_summary'} for i in range(panel_data.TAIL + 50)]
    (tmp_path / 'events.jsonl').write_text('\n'.join(_json.dumps(e) for e in [blocked] + noise) + '\n', encoding='utf-8')
    (tmp_path / 'important.jsonl').write_text(_json.dumps(blocked) + '\n', encoding='utf-8')
    merged = panel_data.merged_events(tmp_path)
    assert merged[0] == blocked and sum(e['kind'] == 'blocked' for e in merged) == 1
    assert important(blocked) and important({'kind': 'x', 'severity': 'critical'}) and important({'kind': 'x', 'outcome': 'stopped'})
    assert not important({'kind': 'memory_exempt_summary'})


def test_backfill_copies_old_important_records_once(tmp_path):
    import json as _json
    from satsuma_win.guard import backfill_important, IMPORTANT
    old = [{'time': 1.0, 'kind': 'blocked', 'ip': '203.0.113.7'}, {'time': 2.0, 'kind': 'memory_finding', 'outcome': 'stopped'},
           {'time': 3.0, 'kind': 'memory_exempt_summary'}]
    (tmp_path / 'events.jsonl').write_text('\n'.join(_json.dumps(e) for e in old) + '\n', encoding='utf-8')
    (tmp_path / IMPORTANT).write_text(_json.dumps({'time': 9.0, 'kind': 'blocked', 'ip': '198.51.100.1'}) + '\n', encoding='utf-8')
    assert backfill_important(tmp_path)['count'] == 2
    lines = (tmp_path / IMPORTANT).read_text(encoding='utf-8').splitlines()
    assert [_json.loads(l)['time'] for l in lines] == [1.0, 2.0, 9.0]
    assert backfill_important(tmp_path)['status'] == 'ALREADY_DONE'
    assert len((tmp_path / IMPORTANT).read_text(encoding='utf-8').splitlines()) == 3
