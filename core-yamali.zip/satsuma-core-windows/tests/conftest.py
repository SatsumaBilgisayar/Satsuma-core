"""satsuma_win from this folder, satsuma (shared rules) from the repository root.

satsuma_win bu klasörden, satsuma (ortak kurallar) depo kökünden alınır.
"""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(HERE), str(HERE.parent)]


import pytest  # noqa: E402


@pytest.fixture(autouse=True)
def no_real_memory_scanner(monkeypatch):
    """A test never runs the real memory scanner: on Windows it would stop real processes of the test machine.

    Bir test gerçek bellek tarayıcısını asla çalıştırmaz: Windows'ta test makinesinin gerçek süreçlerini durdururdu.
    Tests that need one pass their own memory_factory; the live Win32 test builds its reader itself.
    """
    from contextlib import contextmanager
    from satsuma import memory_decision
    from satsuma_win import guard, machine_key, memory

    class Empty:
        def pids(self):
            return []

        @contextmanager
        def open(self, pid):
            yield None
    rules = memory_decision.load_rules()
    # Never stops processes or deletes folders of the test machine. Test makinesinde süreç durdurulmaz, klasör silinmez.
    monkeypatch.setattr(guard, 'default_retire', lambda directory=None: {'ok': True, 'status': 'NOTHING_LEFT'})
    monkeypatch.setattr(guard, 'default_memory_scanner',
                        lambda record, directory=None, key=None, enforce=True: memory.Scanner(rules, Empty(), record))
    real_ensure = machine_key.ensure
    reverse = lambda b: b[::-1]
    monkeypatch.setattr(machine_key, 'ensure', lambda directory, protect=reverse, unprotect=reverse: real_ensure(
        directory, protect=protect, unprotect=unprotect))

    class NoSysmon:
        def read(self):
            return []
    monkeypatch.setattr(guard, 'default_sysmon_reader', lambda: NoSysmon())

    class NoGateway:
        counts = {}
        def load(self):
            return None
        def approve_now(self):
            return {'gateway': '192.168.1.1', 'mac': 'aa-bb-cc-dd-ee-ff', 'interface': '192.168.1.5'}
        def check(self):
            return []
    monkeypatch.setattr(guard, 'default_gateway', lambda *a: NoGateway())

    class NoAccounts:
        def enforce(self):
            return {'ok': True, 'status': 'LOCKED', 'owner': 'S-1-5-21-1-2-3-1001', 'disabled': []}
    monkeypatch.setattr(guard, 'default_accounts', lambda *a: NoAccounts())

    class NoDevices:
        def check(self):
            return []
    monkeypatch.setattr(guard, 'default_devices', lambda *a: NoDevices())
    monkeypatch.setattr(guard, 'default_sysmon_installer', lambda: {'ok': False, 'status': 'TEST'})

    class NoBrowser:
        """Never writes the test machine's registry. Test makinesinin kayıt defterine yazmaz."""
        def apply(self):
            return {'ok': True, 'status': 'LOCKED', 'written': [], 'left': []}

        def status(self):
            return {'ok': True, 'differs': []}
    monkeypatch.setattr(guard, 'default_browser', lambda directory: NoBrowser())

    class NoHardening:
        """Never changes the test machine's network or PowerShell. Test makinesini değiştirmez."""
        def apply(self):
            return {'ok': True, 'status': 'LOCKED', 'written': [], 'left': []}

        def status(self):
            return {'ok': True, 'differs': [], 'live': []}

        def check_ps2(self, force=False):
            return None
    monkeypatch.setattr(guard, 'default_hardening', lambda directory: NoHardening())

    class NoCerts:
        def start(self):
            return {'ok': True, 'status': 'TEST'}

        def check(self):
            return []
    monkeypatch.setattr(guard, 'default_certs', lambda directory, key, record: NoCerts())

    class NoFirewall:
        def __init__(self):
            self.kept = {}

        def baseline(self):
            return {'ok': True, 'status': 'LOCKED'}

        def baseline_ok(self):
            return True

        def restore_blocks(self):
            return []

        def add(self, ip, reason, **extra):
            self.kept[ip] = reason
            return True
    monkeypatch.setattr(guard, 'default_fwauto', lambda directory, key, record, runner: NoFirewall())
    monkeypatch.setattr(guard, 'default_connkill', lambda ip: {'ended': [], 'failed': []})

    class NoOtx:
        def check(self, connections):
            return []
    monkeypatch.setattr(guard, 'default_otx', lambda directory, record, block, protected: NoOtx())

    class NoSuricata:
        """Never downloads Suricata or starts WinDivert in a test. Testte Suricata indirilmez."""
        def start(self):
            return {'ok': False, 'status': 'NOT_INSTALLED'}

        def check(self):
            return []

        def stop(self):
            pass
    monkeypatch.setattr(guard, 'default_suricata', lambda directory, record: NoSuricata())
