"""Sysmon events reach the Windows rules: stop what the shared decision stops, record every finding.

Sysmon olayları Windows kurallarına ulaşır: ortak kararın durdurduğu durdurulur, her bulgu kaydedilir.
"""
import json

from satsuma_win import sysmon
from test_windows_sysmon import make_guard

SHADOWS = {'id': 1, 'record': 10, 'ProcessId': '700', 'Image': r'C:\Windows\System32\vssadmin.exe',
           'CommandLine': 'vssadmin.exe delete shadows /all /quiet', 'ParentImage': r'C:\Windows\System32\cmd.exe',
           'ParentCommandLine': 'cmd.exe', 'ParentProcessId': '600'}
WHOAMI = {'id': 1, 'record': 11, 'ProcessId': '701', 'Image': r'C:\Windows\System32\whoami.exe',
          'CommandLine': 'whoami /priv', 'ParentImage': r'C:\Windows\System32\cmd.exe', 'ParentProcessId': '600'}
RUN_KEY = {'id': 13, 'record': 12, 'ProcessId': '702', 'Image': r'C:\Users\ali\AppData\Local\Temp\x.exe',
           'EventType': 'SetValue', 'TargetObject': r'HKU\S-1-5-21-1\Software\Microsoft\Windows\CurrentVersion\Run\u',
           'Details': r'C:\Users\Public\u.exe'}


def findings(tmp_path):
    rows = [json.loads(line) for line in (tmp_path / 'events.jsonl').read_text().splitlines()]
    return [r for r in rows if r['kind'] == 'rule_finding']


def test_the_rules_load_at_start_and_are_recorded(tmp_path):
    g, _ = make_guard(tmp_path, [])
    assert g.startup['rules']['ok'] and g.startup['rules']['rules'] >= 60 and not g.startup['rules']['load_errors']


def test_a_stopping_rule_stops_the_process_through_its_image_and_records_it(tmp_path):
    g, memory = make_guard(tmp_path, [[SHADOWS, RUN_KEY]])
    g.check_sysmon()
    assert memory.reader.stopped == [(700, SHADOWS['Image']), (702, RUN_KEY['Image'])]
    rows = {r['rule_id']: r for r in findings(tmp_path)}
    assert rows['SATSUMA-WIN-120']['outcome'] == 'stopped' and rows['SATSUMA-WIN-040']['outcome'] == 'stopped'
    assert rows['SATSUMA-WIN-120']['cmd'] == SHADOWS['CommandLine'] and rows['SATSUMA-WIN-120']['mitre']['technique'] == 'T1490'
    assert g.counts['rule_stopped'] == 2


def test_an_indicator_is_recorded_and_the_process_goes_on(tmp_path):
    g, memory = make_guard(tmp_path, [[WHOAMI]])
    g.check_sysmon()
    assert memory.reader.stopped == []
    assert [(r['rule_id'], r['outcome']) for r in findings(tmp_path)] == [('SATSUMA-WIN-080', 'recorded')]


def test_the_same_rule_for_the_same_process_is_recorded_once_in_ten_minutes(tmp_path):
    g, memory = make_guard(tmp_path, [[WHOAMI], [WHOAMI]])
    g.check_sysmon()
    g.check_sysmon()
    assert len(findings(tmp_path)) == 1


def test_a_system_process_id_and_report_mode_are_never_stopped(tmp_path):
    g, memory = make_guard(tmp_path, [[{**SHADOWS, 'ProcessId': '4'}]])
    g.check_sysmon()
    memory.enforce = False
    g.sysmon.batches.append([{**SHADOWS, 'ProcessId': '800', 'record': 20}])
    g.check_sysmon()
    assert memory.reader.stopped == []
    assert [r['not_stopped'] for r in findings(tmp_path)] == ['protected_process', 'report_mode']


def test_a_critical_process_is_reported_not_stopped(tmp_path):
    g, memory = make_guard(tmp_path, [[SHADOWS]])
    memory.reader.stop_if_image = lambda pid, image, not_after=None: 'critical'
    g.check_sysmon()
    assert findings(tmp_path)[0]['outcome'] == 'critical' and g.counts['rule_stopped'] == 0


def test_a_failed_stop_is_recorded_never_hidden(tmp_path):
    g, memory = make_guard(tmp_path, [[SHADOWS]])

    def refuse(pid, image, not_after=None):
        raise OSError(5, 'access denied')
    memory.reader.stop_if_image = refuse
    g.check_sysmon()
    row = findings(tmp_path)[0]
    assert row['outcome'] == 'stop_failed' and 'access denied' in row['error'] and g.counts['rule_stop_failed'] == 1


def test_sysmon_now_records_what_the_rules_read():
    for part in ('<NetworkConnect onmatch="exclude" />', '<FileCreate onmatch="exclude" />',
                 '<RegistryEvent onmatch="exclude" />', '<DnsQuery onmatch="exclude" />'):
        assert part in sysmon.CONFIG, part
    import xml.etree.ElementTree as ET
    ET.fromstring(sysmon.CONFIG)
