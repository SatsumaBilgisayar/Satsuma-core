"""Installation and update under the owner's eyes. Kurulum ve güncelleme sahibinin gözü önünde."""
import json

from satsuma_win import owner_requests, upgrade


def rules(**changes):
    base = {'SATSUMA-WIN-001': {'name': 'a', 'severity': 'high', 'sha256': '1'},
            'SATSUMA-WIN-002': {'name': 'b', 'severity': 'high', 'sha256': '2'}}
    base.update(changes)
    return {k: v for k, v in base.items() if v}


def test_changes_lists_new_removed_and_changed_rules():
    old = {'exe': 'aaa', 'panel': 'p', 'rules': rules(), 'device_policy': 'x'}
    new = {'exe': 'bbb', 'panel': 'p', 'device_policy': 'y',
           'rules': rules(**{'SATSUMA-WIN-002': None, 'SATSUMA-WIN-003': {'name': 'c', 'severity': 'critical', 'sha256': '3'},
                             'SATSUMA-WIN-001': {'name': 'a', 'severity': 'high', 'sha256': 'changed'}})}
    text = '\n'.join(upgrade.changes(old, new))
    assert "Hizmet exe'si değişiyor" in text and 'Yeni kural: SATSUMA-WIN-003' in text
    assert 'Kaldırılan kural: SATSUMA-WIN-002' in text and 'Değişen kural: SATSUMA-WIN-001' in text
    assert 'Aygıt politikası' in text
    assert upgrade.changes(old, old) == ['Kurallarda ve politikada değişiklik yok; yalnızca aynı sürüm yeniden kuruluyor.']


def test_manifest_reads_the_bundled_rules():
    from pathlib import Path
    data = upgrade.manifest(__file__, Path(__file__).resolve().parents[1] / 'rules')
    assert len(data['rules']) >= 60 and all(r['sha256'] for r in data['rules'].values())


def test_no_request_can_change_the_owner(tmp_path):
    import pytest
    with pytest.raises(ValueError):
        owner_requests.write(tmp_path, 'set_owner', sid='S-1-5-21-1-2-3-1002')


def test_first_installation_signs_the_owner_only_while_there_is_none(tmp_path):
    from satsuma_win import memory, accounts

    class Key:
        def sign(self, data):
            return 'S' + str(len(data))

        def verify(self, data, sig):
            return sig == 'S' + str(len(data))
    (tmp_path / memory.PENDING).write_text(json.dumps({'owner': 'S-1-5-21-1-2-3-1001'}))
    memory.apply_install_approvals(tmp_path, Key(), created=False)
    assert accounts.load_owner(tmp_path, Key()) == 'S-1-5-21-1-2-3-1001'
    (tmp_path / memory.PENDING).write_text(json.dumps({'owner': 'S-1-5-21-1-2-3-1002'}))
    done = memory.apply_install_approvals(tmp_path, Key(), created=True)
    assert done['owner_kept'] and accounts.load_owner(tmp_path, Key()) == 'S-1-5-21-1-2-3-1001'


def test_integrity_signs_a_baseline_then_finds_a_changed_exe(tmp_path, monkeypatch):
    from satsuma_win import guard as guard_module
    folder = tmp_path / 'pf'
    folder.mkdir()
    (folder / 'satsuma-core-windows.exe').write_bytes(b'service-v1')
    (folder / 'satsuma-panel.exe').write_bytes(b'panel-v1')
    monkeypatch.setattr(upgrade, 'install_dir', lambda: folder)
    state = tmp_path / 'state'
    state.mkdir()
    upgrade.save_manifest(state, {'exe': upgrade._digest(folder / 'satsuma-core-windows.exe'),
                                  'panel': upgrade._digest(folder / 'satsuma-panel.exe'), 'rules': {}})

    class Key:
        def sign(self, data):
            return 'S' + str(len(data))

        def verify(self, data, sig):
            return sig == 'S' + str(len(data))
    rec = []
    g = guard_module.Guard.__new__(guard_module.Guard)
    g.key, g.directory, g.clock, g.integrity_at = Key(), state, (lambda: 1000.0), None
    g.record = lambda kind, **f: rec.append(kind) or {'kind': kind, **f}
    assert g.check_integrity()['kind'] == 'satsuma_integrity_baseline'
    (folder / 'satsuma-panel.exe').write_bytes(b'panel-evil')
    g.integrity_at = None
    found = g.check_integrity()
    assert found['kind'] == 'satsuma_tampered' and found['exes'] == ['satsuma-panel.exe']
    g.integrity_at = None
    assert g.check_integrity() is None  # the same state is recorded once, not every five minutes
    # B5: a new install whose panel could not be copied is one install_incomplete record.
    (folder / 'satsuma-core-windows.exe').write_bytes(b'service-v2')
    upgrade.save_manifest(state, {'exe': upgrade._digest(folder / 'satsuma-core-windows.exe'),
                                  'panel': upgrade._digest(b'x' and folder / 'satsuma-core-windows.exe'), 'rules': {}})
    (folder / 'satsuma-panel.exe').write_bytes(b'panel-v1')
    g.integrity_at = None
    found = g.check_integrity()
    assert found['kind'] == 'install_incomplete' and found['exes'] == ['satsuma-panel.exe']
    g.integrity_at = None
    assert g.check_integrity() is None


class _Key:
    """A real Ed25519 key, as the service's machine key signs and verifies."""
    def __init__(self):
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives import serialization as s
        from satsuma_win.machine_key import MachineKey
        private = Ed25519PrivateKey.generate()
        self.inner = MachineKey(private, private.public_key().public_bytes(s.Encoding.Raw, s.PublicFormat.Raw))

    def sign(self, data):
        return self.inner.sign(data)

    def verify(self, data, signature):
        return self.inner.verify(data, signature)


EXES = {'satsuma-core-windows.exe': 'e1', 'satsuma-panel.exe': 'p1'}


def test_typed_consent_starts_approved_and_survives_restarts(tmp_path):
    key = _Key()
    upgrade.write_consent_request(tmp_path, False, EXES)
    kind, fields = upgrade.settle_consent(tmp_path, key, EXES)
    assert kind == 'satsuma_started_approved' and 'onaylıyorum' in fields['consent']
    assert not (tmp_path / upgrade.CONSENT_PENDING).exists()
    assert upgrade.settle_consent(tmp_path, key, EXES)[0] == 'satsuma_started_approved'


def test_unapproved_install_starts_with_a_critical_record(tmp_path):
    key = _Key()
    upgrade.write_consent_request(tmp_path, True, EXES)
    kind, fields = upgrade.settle_consent(tmp_path, key, EXES)
    assert kind == 'satsuma_started_unapproved' and fields['severity'] == 'critical'
    assert 'onaysız' in fields['reason']


def test_exe_copied_by_hand_without_the_installer_is_critical(tmp_path):
    key = _Key()
    upgrade.write_consent_request(tmp_path, False, EXES)
    upgrade.settle_consent(tmp_path, key, EXES)
    other = {'satsuma-core-windows.exe': 'e2', 'satsuma-panel.exe': 'p1'}
    kind, fields = upgrade.settle_consent(tmp_path, key, other)
    assert kind == 'satsuma_started_unapproved' and 'onay kaydı yok' in fields['reason']
    swapped_panel = {'satsuma-core-windows.exe': 'e1', 'satsuma-panel.exe': 'p9'}
    assert 'panel' in upgrade.settle_consent(tmp_path, key, swapped_panel)[1]['reason']


def test_pending_for_another_exe_or_forged_store_is_critical(tmp_path):
    key = _Key()
    upgrade.write_consent_request(tmp_path, False, {'satsuma-core-windows.exe': 'x', 'satsuma-panel.exe': 'p1'})
    kind, fields = upgrade.settle_consent(tmp_path, key, EXES)
    assert kind == 'satsuma_started_unapproved' and 'eşleşmiyor' in fields['reason']
    (tmp_path / upgrade.CONSENT).write_text(json.dumps({'builds': {'e1': {'consent': 'typed', 'panel': 'p1'}},
                                                        'signature': 'AAAA'}), encoding='utf-8')
    kind, fields = upgrade.settle_consent(tmp_path, key, EXES)
    assert kind == 'satsuma_started_unapproved' and 'imza' in fields['reason']


def test_rollback_to_an_earlier_approved_build_stays_approved(tmp_path):
    key = _Key()
    upgrade.write_consent_request(tmp_path, False, EXES)
    upgrade.settle_consent(tmp_path, key, EXES)
    newer = {'satsuma-core-windows.exe': 'e2', 'satsuma-panel.exe': 'p2'}
    upgrade.write_consent_request(tmp_path, False, newer)
    assert upgrade.settle_consent(tmp_path, key, newer)[0] == 'satsuma_started_approved'
    assert upgrade.settle_consent(tmp_path, key, EXES)[0] == 'satsuma_started_approved'


def test_without_machine_key_it_is_critical(tmp_path):
    kind, fields = upgrade.settle_consent(tmp_path, None, EXES)
    assert kind == 'satsuma_started_unapproved' and fields['severity'] == 'critical'


def test_panel_shows_unapproved_start_as_alert():
    from satsuma_win import panel_data
    d = panel_data.describe({'time': 0, 'kind': 'satsuma_started_unapproved', 'severity': 'critical',
                             'reason': 'onaysız kuruldu (--yes, otomatik sınama)', 'consent': 'x'})
    assert d['level'] == 'alert' and d['badge'] == 'Onaysız'


def test_behaviour_changes_are_listed_since_the_installed_build():
    from satsuma_win import changes as behaviour
    base = {'exe': 'a', 'panel': 'p', 'rules': {}, 'device_policy': 'd'}
    new = {**base, 'exe': 'b', 'change_ids': behaviour.ids()}
    lines = upgrade.changes({**base, 'change_ids': list(range(1, 11))}, new)
    assert any(l.startswith('Yeni davranış #11') for l in lines) and any(l.startswith('Yeni davranış #12') for l in lines)
    assert not any(l.startswith('Yeni davranış #10:') for l in lines)
    old_style = upgrade.changes(base, new)
    assert 'değişiklik listesi yok' in old_style[1] and any('#1 ' in l for l in old_style)
    same = upgrade.changes({**new}, new)
    assert same == ['Kurallarda ve politikada değişiklik yok; yalnızca aynı sürüm yeniden kuruluyor.']


def test_change_numbers_are_unique_and_never_reordered():
    from satsuma_win import changes as behaviour
    assert behaviour.ids() == list(range(1, len(behaviour.CHANGES) + 1))
