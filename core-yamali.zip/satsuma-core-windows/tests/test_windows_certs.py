"""Certificate store watch: an unapproved root or trusted publisher is quarantined; auto-updated roots are recorded.

Sertifika deposu bekçisi: onaylanmamış kök ya da yayıncı karantinaya alınır; otomatik güncellenen kökler kaydedilir.
"""
import json
import struct

from satsuma_win import certs, machine_key
from satsuma_win.certs import MACHINE, RECORD_ONLY, CertWatch

reverse = lambda b: b[::-1]
A, B, C = 'A' * 40, 'B' * 40, 'C' * 40


def blob():
    """A registry Blob holding a real self-signed certificate (property 32). Gerçek bir sertifika."""
    import datetime
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    key = ec.generate_private_key(ec.SECP256R1())
    name = x509.Name([x509.NameAttribute(x509.oid.NameOID.COMMON_NAME, 'Evil Interception CA')])
    now = datetime.datetime(2026, 1, 1, tzinfo=datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(1).not_valid_before(now).not_valid_after(now + datetime.timedelta(days=3650))
            .sign(key, hashes.SHA256()))
    der = cert.public_bytes(serialization.Encoding.DER)
    other = struct.pack('<III', 3, 1, 20) + b'\x01' * 20
    return other + struct.pack('<III', 32, 1, len(der)) + der


class Hive:
    def __init__(self, keys=None, sids=()):
        self.keys, self._sids = {k: dict(v) for k, v in (keys or {}).items()}, list(sids)

    def sids(self):
        return self._sids

    def subkeys(self, path):
        prefix = path + '\\'
        return sorted({k[len(prefix):].split('\\')[0] for k in self.keys if k.startswith(prefix)})

    def blob(self, path):
        return self.keys.get(path, {}).get('Blob', b'')

    def delete_key(self, path):
        self.keys.pop(path)

    def restore(self, path, data):
        self.keys[path] = {'Blob': data}


def make(tmp_path, machine, users=None):
    key, _ = machine_key.ensure(tmp_path, protect=reverse, unprotect=reverse)
    records = []
    watch = CertWatch(tmp_path, key, lambda kind, **f: records.append((kind, f)) or f, machine=machine,
                      users=users or Hive(), clock=lambda: 1_800_000_000)
    return watch, records


def test_the_first_start_takes_a_signed_baseline_and_quarantines_a_new_root(tmp_path):
    machine = Hive({MACHINE['Root'] + '\\' + A: {'Blob': b''}})
    watch, records = make(tmp_path, machine)
    assert watch.start()['status'] == 'BASELINE_TAKEN'
    machine.keys[MACHINE['Root'] + '\\' + B] = {'Blob': blob()}
    watch.check()
    assert MACHINE['Root'] + '\\' + B not in machine.keys and MACHINE['Root'] + '\\' + A in machine.keys
    kind, fields = records[-1]
    assert kind == 'cert_quarantined' and fields['thumbprint'] == B and fields['subject'] == 'CN=Evil Interception CA'
    assert list((tmp_path / 'cert-quarantine').glob('Root-' + B + '.json'))


def test_a_new_trusted_publisher_and_a_users_root_are_quarantined_too(tmp_path):
    machine, users = Hive(), Hive(sids=['S-1-5-21-1-2-3-1001'])
    watch, records = make(tmp_path, machine, users)
    watch.start()
    machine.keys[MACHINE['TrustedPublisher'] + '\\' + B] = {'Blob': blob()}
    users.keys['S-1-5-21-1-2-3-1001\\' + certs.USER['UserRoot'] + '\\' + C] = {'Blob': blob()}
    watch.check()
    assert sorted(f['store'] for k, f in records if k == 'cert_quarantined') == ['S-1-5-21-1-2-3-1001:UserRoot', 'TrustedPublisher']
    assert users.keys == {} and machine.keys == {}


def test_a_root_the_machine_already_trusts_is_not_taken_from_a_user(tmp_path):
    machine, users = Hive({MACHINE['Root'] + '\\' + A: {'Blob': b''}}), Hive(sids=['S-1-5-21-9'])
    watch, records = make(tmp_path, machine, users)
    watch.start()
    users.keys['S-1-5-21-9\\' + certs.USER['UserRoot'] + '\\' + A] = {'Blob': b''}
    assert watch.check() == []


def test_microsofts_automatic_roots_and_intermediates_are_recorded_not_removed(tmp_path):
    machine = Hive()
    watch, records = make(tmp_path, machine)
    watch.start()
    machine.keys[RECORD_ONLY['AuthRoot'] + '\\' + B] = {'Blob': blob()}
    machine.keys[RECORD_ONLY['CA'] + '\\' + C] = {'Blob': b''}
    watch.check()
    assert sorted(k for k, _ in records) == ['cert_added', 'cert_added'] and len(machine.keys) == 2
    assert watch.check() == [], 'recorded once'


def test_the_owner_approves_and_a_quarantined_certificate_comes_back(tmp_path):
    machine = Hive()
    watch, records = make(tmp_path, machine)
    watch.start()
    machine.keys[MACHINE['Root'] + '\\' + B] = {'Blob': blob()}
    watch.check()
    certs.write_request(tmp_path, B.lower())
    watch.check()
    assert MACHINE['Root'] + '\\' + B in machine.keys
    assert ('cert_approved', {'thumbprint': B, 'restored': ['Root']}) in records
    assert watch.check() == []


def test_a_baseline_or_approval_changed_by_hand_is_never_trusted(tmp_path):
    machine = Hive()
    watch, records = make(tmp_path, machine)
    watch.start()
    data = json.loads((tmp_path / 'cert-approved.json').read_text()) if (tmp_path / 'cert-approved.json').exists() else None
    assert data is None
    (tmp_path / 'cert-approved.json').write_text(json.dumps({'body': {'thumbprints': [B]}, 'signature': 'AAAA'}))
    machine.keys[MACHINE['Root'] + '\\' + B] = {'Blob': b''}
    watch.check()
    assert ('cert_quarantined' in [k for k, _ in records])
    base = json.loads((tmp_path / 'cert-baseline.json').read_text())
    base['body']['stores']['Root'].append(C)
    (tmp_path / 'cert-baseline.json').write_text(json.dumps(base))
    watch2, records2 = make(tmp_path, machine)
    watch2.start()
    assert 'cert_baseline_rejected' in [k for k, _ in records2]


def test_a_removed_disallowed_certificate_is_recorded(tmp_path):
    machine = Hive({certs.DISALLOWED + '\\' + A: {'Blob': b''}})
    watch, records = make(tmp_path, machine)
    watch.start()
    machine.keys.pop(certs.DISALLOWED + '\\' + A)
    watch.check()
    assert ('cert_disallowed_removed', {'thumbprint': A}) in records


def test_the_command_line_writes_an_approval_request(tmp_path):
    from satsuma_win.guard import cert_command
    out = []
    assert cert_command(['--cert-approve', 'ab ' * 13 + 'a'], tmp_path, out.append) == 2
    assert cert_command(['--cert-approve', B.lower()], tmp_path, out.append) == 0
    assert [json.loads(p.read_text())['approve'] for p in (tmp_path / 'cert-requests').glob('*.json')] == [B]
