"""RAM-001 on Windows (owner, 2026-11-24): a misplaced program or a thread from fileless memory stops on sight.

Before the stop the memory is held, read and judged with the Linux 2.2.67 method, only for the
record; the verdict never keeps the program running.
Windows'ta RAM-001: yeri yanlış program ya da dosyasız bellekten iş parçacığı görüldüğü an durur; bellek
önce yalnızca kayıt için bekletilir, okunur, değerlendirilir.
"""
import json

from satsuma_win import memory, rwx_inspection
from satsuma_win.rwx_inspection import Holds
from test_windows_memory import RULES, RWX_PRIVATE, STAGER, TEMP_DLL, Process, Reader

MISPLACED = 'C:\\Users\\ali\\AppData\\Local\\Tool\\tool.exe'      # outside Windows and Program Files


def info(pid=800, regions=(RWX_PRIVATE,), image=MISPLACED, **extra):
    return {'pid': pid, 'created': 222, 'image': image, 'image_exists': True, 'debugged': False,
            'critical': False, 'parent': 1, 'thread_starts': [], 'regions': list(regions), **extra}


class Clock:
    def __init__(self):
        self.now = 1000.0

    def __call__(self):
        return self.now


class NoTimer:
    """A watchdog that only fires when the test says so. Yalnızca test isteyince çalışan bekçi."""
    made = []

    def __init__(self, seconds, function, args=()):
        self.seconds, self.function, self.args, self.cancelled, self.started = seconds, function, args, False, False
        NoTimer.made.append(self)

    def start(self):
        self.started = True

    def cancel(self):
        self.cancelled = True

    def fire(self):
        self.function(*self.args)


def scan(processes, enforce=True, clock=None, holds=None):
    events = []
    clock = clock or Clock()
    holds = holds or Holds(clock=clock, timer=NoTimer)
    scanner = memory.Scanner(RULES, Reader(processes), lambda kind, **f: events.append((kind, f)) or f,
                             own_pid=1, enforce=enforce, holds=holds, clock=clock)
    return scanner, events


def only(events):
    assert len(events) == 1, events
    return events[0][1]


def test_a_misplaced_program_with_empty_rwx_memory_is_stopped_anyway_the_verdict_is_only_evidence():
    target = Process(info(), memory=b'\x00' * 4096)
    scanner, events = scan({800: target})
    scanner.scan()
    finding = only(events)
    assert target.terminated == 222 and target.suspended == 1 and target.resumed == 0
    assert finding['outcome'] == 'stopped' and finding['stop_reason'] == 'program_not_in_expected_location'
    assert 'kept' not in finding and 'confirmation' not in finding
    report = finding['inspection']
    assert report['verdict'] == 'clean' and report['held'] and 'resumed' not in report
    assert report['raw_memory_persisted'] is False and 'data' not in json.dumps(report)
    assert report['regions'][0]['empty'] and len(report['regions'][0]['sha256']) == 64
    assert scanner.counts['inspection_clean'] == 1 and not scanner.holds.active


def test_stager_code_is_stopped_while_still_held():
    target = Process(info(), memory=STAGER)
    scanner, events = scan({800: target})
    scanner.scan()
    finding = only(events)
    assert target.terminated == 222 and target.suspended == 1 and target.resumed == 0
    assert finding['outcome'] == 'stopped' and finding['confirmation'] == 'malicious_code_in_writable_executable_memory'
    assert {s['sign'] for s in finding['inspection']['signs']} >= {'peb_access', 'api_hash_ror13'}
    assert not scanner.holds.active and NoTimer.made[-1].cancelled


def test_a_known_implant_marker_alone_is_malicious():
    target = Process(info(), memory=b'\x00' * 64 + b'ReflectiveLoader' + b'\x00' * 64)
    scanner, events = scan({800: target})
    scanner.scan()
    assert only(events)['outcome'] == 'stopped'


def test_one_medium_sign_is_recorded_as_inconclusive_and_the_program_is_stopped():
    stub = b'\x4c\x8b\xd1\xb8\x18\x00\x00\x00\x0f\x05\xc3'        # mov r10,rcx; mov eax,18h; syscall; ret
    target = Process(info(), memory=b'\xcc' * 16 + stub + b'\xcc' * 16)
    scanner, events = scan({800: target})
    scanner.scan()
    finding = only(events)
    assert target.terminated == 222 and finding['outcome'] == 'stopped'
    assert finding['inspection']['verdict'] == 'inconclusive'
    assert [s['sign'] for s in finding['inspection']['signs']] == ['direct_syscall_stub']


def test_memory_that_cannot_be_read_does_not_delay_the_stop():
    target = Process(info(), unreadable=True)
    scanner, events = scan({800: target})
    scanner.scan()
    finding = only(events)
    assert finding['outcome'] == 'stopped' and target.terminated == 222
    assert finding['inspection']['verdict'] == 'inconclusive'
    assert finding['inspection']['reason'] == 'some_regions_unreadable'


def test_a_failing_inspection_does_not_delay_the_stop():
    class Broken(Process):
        def read_memory(self, address, size):
            raise RuntimeError('unexpected')
    target = Broken(info())
    scanner, events = scan({800: target})
    scanner.scan()
    finding = only(events)
    assert finding['outcome'] == 'stopped' and finding['inspection']['reason'] == 'inspection_failed'
    assert not scanner.holds.active


def test_a_thread_started_in_fileless_memory_is_malicious_even_when_the_bytes_look_empty():
    # Owner's decision 2026-11-11 kept: a thread from fileless memory is a strong sign.
    target = Process(info(image='C:\\Program Files\\App\\app.exe', thread_starts=[0x1010]), memory=b'\x00' * 4096)
    scanner, events = scan({800: target})
    scanner.scan()
    finding = only(events)
    assert finding['outcome'] == 'stopped' and finding['stop_reason'] == 'thread_started_from_fileless_memory'
    assert finding['inspection']['signs'][0] == {'sign': 'thread_started_from_fileless_memory', 'level': 'strong',
                                                 'offset': 0, 'region': '0x1010'}


def test_a_failed_stop_resumes_the_held_program_as_privd_does():
    target = Process(info(), memory=STAGER, fail='access denied')
    scanner, events = scan({800: target})
    scanner.scan()
    assert only(events)['outcome'] == 'stop_failed' and target.resumed == 1 and not scanner.holds.active


def test_jit_memory_of_a_program_in_its_place_is_not_held_at_all():
    target = Process(info(image='C:\\Program Files\\dotnet\\dotnet.exe'), memory=STAGER)
    scanner, events = scan({800: target})
    scanner.scan()
    finding = only(events)
    assert target.suspended == 0 and 'inspection' not in finding and finding['kept'] == 'no_thread_from_fileless_memory'


def test_an_exempt_critical_process_is_never_held():
    target = Process(info(critical=True), memory=STAGER)
    scanner, events = scan({800: target})
    scanner.scan()
    assert target.suspended == 0 and target.terminated is None and only(events)['exempt'] == 'windows_critical_process'


def test_with_another_stopping_rule_the_process_is_stopped_once_with_the_evidence():
    target = Process(info(regions=[RWX_PRIVATE, TEMP_DLL]), memory=b'\x00' * 4096)
    target.data['temp_signed'] = False
    scanner, events = scan({800: target})
    scanner.scan()
    assert target.terminated == 222 and target.suspended == 1
    assert {f['rule_id'] for _, f in events} == {'SATSUMA-RAM-001', 'SATSUMA-RAM-008'}
    assert {f['outcome'] for _, f in events} == {'stopped'}
    assert [f['rule_id'] for _, f in events if 'inspection' in f] == ['SATSUMA-RAM-001']


def test_report_mode_judges_without_holding_or_stopping():
    target = Process(info(), memory=STAGER)
    scanner, events = scan({800: target}, enforce=False)
    scanner.scan()
    finding = only(events)
    assert target.suspended == 0 and target.terminated is None
    assert finding['outcome'] == 'recorded' and finding['inspection']['verdict'] == 'malicious'


def test_a_stop_that_failed_is_not_repeated_on_every_scan():
    target = Process(info(), memory=STAGER, fail='access denied')
    scanner, events = scan({800: target})
    scanner.scan()
    scanner.scan()
    assert len(events) == 1 and target.suspended == 1 and target.resumed == 1


# -- the hold -----------------------------------------------------------------------------

def test_a_hold_is_written_down_before_the_process_is_suspended_and_forgotten_after(tmp_path):
    holds = Holds(tmp_path, timer=NoTimer)
    seen = []

    class Watching(Process):
        def suspend(self):
            seen.append(json.loads((tmp_path / 'holds.json').read_text()))
            super().suspend()
    target = Watching(info())
    assert holds.hold(target, 800, 222)['held']
    assert seen == [[{'pid': 800, 'created': 222, 'wall_deadline': seen[0][0]['wall_deadline']}]]
    assert holds.release((800, 222)) and target.resumed == 1
    assert json.loads((tmp_path / 'holds.json').read_text()) == []


def test_the_watchdog_resumes_at_the_deadline_and_never_waits_beyond_ten_seconds(tmp_path):
    holds = Holds(tmp_path, timer=NoTimer)
    target = Process(info())
    assert holds.hold(target, 800, 222, seconds=600)['seconds'] == rwx_inspection.MAX_SECONDS
    watchdog = NoTimer.made[-1]
    assert watchdog.started and watchdog.seconds == rwx_inspection.MAX_SECONDS
    watchdog.fire()
    assert target.resumed == 1 and not holds.active
    assert not holds.release((800, 222))                  # the caller's own resume finds nothing to do
    assert target.resumed == 1


def test_a_process_that_cannot_be_suspended_is_read_anyway_and_not_written_down(tmp_path):
    class Protected(Process):
        def suspend(self):
            raise OSError('NtSuspendProcess 0xc0000022')
    holds = Holds(tmp_path, timer=NoTimer)
    answer = holds.hold(Protected(info()), 800, 222)
    assert answer['held'] is False and answer['status'] == 'suspend_failed' and not holds.active
    assert json.loads((tmp_path / 'holds.json').read_text()) == []


def test_a_restarted_service_resumes_what_the_earlier_one_left_held(tmp_path):
    (tmp_path / 'holds.json').write_text(json.dumps([{'pid': 800, 'created': 222, 'wall_deadline': 1},
                                                     {'pid': 801, 'created': 999, 'wall_deadline': 1},
                                                     {'pid': 802, 'created': 1, 'wall_deadline': 1}]))
    held, reused = Process(info()), Process(info(pid=801))     # 801 is now another process (created 222)
    records = []
    resumed = Holds(tmp_path).recover(Reader({800: held, 801: reused}),
                                      lambda kind, **f: records.append((kind, f)))
    assert resumed == [800] and held.resumed == 1 and reused.resumed == 0
    assert records == [('memory_hold_recovered', {'pids': [800]})] and not (tmp_path / 'holds.json').exists()


# -- the judging --------------------------------------------------------------------------

def test_windows_signs_and_the_linux_judging_together():
    assert rwx_inspection.windows_signs(b'\x00' * 100) == []
    x86 = b'\x64\xa1\x30\x00\x00\x00\x8b\x40\x0c'               # mov eax, fs:[30h]
    assert [s['sign'] for s in rwx_inspection.windows_signs(x86)] == ['peb_access']
    assert [s['sign'] for s in rwx_inspection.judge(b'\x90' * 200)] == ['nop_sled']          # Linux sign
    assert rwx_inspection.verdict(rwx_inspection.judge(STAGER)) == 'malicious'
    assert rwx_inspection.verdict(rwx_inspection.judge(b'\x48\x89\xe5\x5d\xc3' * 50)) == 'clean'   # ordinary code
