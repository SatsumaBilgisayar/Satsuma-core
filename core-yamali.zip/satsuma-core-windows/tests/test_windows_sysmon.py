"""Sysmon on Windows: verified install, event reading, build tool stop, immediate memory scan.

Windows'ta Sysmon: doğrulanmış kurulum, olay okuma, derleme aracı durdurma, anında bellek taraması.
"""
import io
import json
import zipfile
from types import SimpleNamespace

import pytest

from satsuma_win import guard as guard_module, sysmon
from satsuma_win.guard import Guard

EVENT = ('<Event xmlns="http://schemas.microsoft.com/win/2004/08/events/event"><System>'
         '<EventID>{id}</EventID><EventRecordID>{record}</EventRecordID></System><EventData>{data}</EventData></Event>')


def xml(event_id, record, **fields):
    return EVENT.format(id=event_id, record=record,
                        data=''.join(f'<Data Name="{k}">{v}</Data>' for k, v in fields.items()))


def test_events_are_parsed_and_a_dtd_is_refused():
    event = sysmon.parse(xml(1, 7, ProcessId='4321', Image='C:\\x\\gcc.exe'))
    assert event == {'id': 1, 'record': 7, 'ProcessId': '4321', 'Image': 'C:\\x\\gcc.exe'}
    with pytest.raises(ValueError):
        sysmon.parse('<!DOCTYPE x [<!ENTITY a "b">]>' + xml(1, 1))


def test_injection_events_point_at_both_processes():
    assert sysmon.pids_to_scan({'id': 8, 'TargetProcessId': '900', 'SourceProcessId': '800'}) == [900, 800]
    assert sysmon.pids_to_scan({'id': 10, 'TargetProcessId': '4', 'SourceProcessId': 'x'}) == []
    assert sysmon.pids_to_scan({'id': 3, 'ProcessId': '900'}) == []


def zipped():
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as archive:
        archive.writestr('Sysmon64.exe', b'MZ sysmon')
    return buffer.getvalue()


def runner(signature, installed=False, fails=False, channel_missing=False):
    calls = []
    def run(argv, **kwargs):
        calls.append(argv)
        if argv[0].startswith('powershell'):
            return SimpleNamespace(returncode=0, stdout=json.dumps(signature), stderr='')
        if argv[0] == 'sc.exe':
            return SimpleNamespace(returncode=0 if installed else 1060, stdout='', stderr='')
        if argv[0] == 'wevtutil.exe':
            return SimpleNamespace(returncode=1 if channel_missing else 0, stdout='', stderr='not found')
        return SimpleNamespace(returncode=1 if fails else 0, stdout='', stderr='boom' if fails else '')
    run.calls = calls
    return run


MICROSOFT = {'status': 'Valid', 'subject': 'CN=Microsoft Corporation, O=Microsoft Corporation, L=Redmond'}


def test_only_a_valid_microsoft_signature_is_installed(tmp_path):
    run = runner(MICROSOFT)
    result = sysmon.install(tmp_path, run, fetch=lambda url: zipped())
    assert result['ok'] and result['status'] == 'INSTALLED'
    assert run.calls[-3][1:3] == ['-accepteula', '-i'] and (tmp_path / 'satsuma-sysmon.xml').exists()
    assert run.calls[-2] == ['wevtutil.exe', 'sl', sysmon.CHANNEL, '/ms:%d' % sysmon.LOG_SIZE]
    assert run.calls[-1][:2] == ['wevtutil.exe', 'gl']
    for bad in ({'status': 'NotSigned', 'subject': ''}, {'status': 'Valid', 'subject': 'CN=Evil, O=Evil Corp'},
                {'status': 'HashMismatch', 'subject': MICROSOFT['subject']}):
        run = runner(bad)
        result = sysmon.install(tmp_path / 'x', run, fetch=lambda url: zipped())
        assert result['status'] == 'SIGNATURE_REJECTED' and not (tmp_path / 'x' / sysmon.EXE).exists()
        assert not any('-i' in call for call in run.calls)


def test_a_failed_download_or_install_is_reported(tmp_path):
    def offline(url):
        raise OSError('no network')
    assert sysmon.install(tmp_path, runner(MICROSOFT), fetch=offline)['status'] == 'DOWNLOAD_FAILED'
    assert sysmon.install(tmp_path, runner(MICROSOFT, fails=True), fetch=lambda u: zipped())['status'] == 'INSTALL_FAILED'
    assert sysmon.install(tmp_path, runner(MICROSOFT, installed=True), fetch=lambda u: zipped())['status'] == 'UPDATED'


def test_config_records_injection_events_and_every_process():
    for part in ('<ProcessCreate onmatch="exclude" />', '<CreateRemoteThread onmatch="exclude" />',
                 '<ProcessTampering onmatch="exclude" />', '<ImageLoad onmatch="exclude" />',
                 '<ProcessAccess onmatch="exclude" />'):
        assert part in sysmon.CONFIG


class Events:
    def __init__(self, batches):
        self.batches = list(batches)

    def read(self):
        return self.batches.pop(0) if self.batches else []


class Reader:
    def __init__(self):
        self.stopped = []

    def stop_if_image(self, pid, image, not_after=None):
        self.stopped.append((pid, image))
        return 'stopped'


class Memory:
    def __init__(self):
        self.reader, self.scanned, self.enforce, self.counts = Reader(), [], True, {}

    def scan(self, pids=None, not_after=None):
        self.scanned.append(pids)
        return []


def make_guard(tmp_path, batches, pm=False):
    memory = Memory()
    ok = lambda argv, **kw: SimpleNamespace(returncode=0, stdout='{}', stderr='')
    g = Guard(runner=ok, read=lambda: [], directory=tmp_path, echo=lambda *_: None,
              memory_factory=lambda record, directory, key: memory, sysmon_factory=lambda: Events([[]] + batches),
              package_manager_running=lambda: pm)
    g.start()
    return g, memory


def test_a_build_tool_started_is_stopped_and_injection_targets_are_scanned_at_once(tmp_path):
    batch = [{'id': 1, 'record': 2, 'ProcessId': '700', 'Image': 'C:\\proof\\gcc.exe', 'ParentImage': 'C:\\x.exe'},
             {'id': 1, 'record': 3, 'ProcessId': '701', 'Image': 'C:\\Windows\\System32\\notepad.exe'},
             {'id': 8, 'record': 4, 'TargetProcessId': '900', 'SourceProcessId': '800'}]
    g, memory = make_guard(tmp_path, [batch])
    assert g.startup['sysmon']['ok']
    g.check_sysmon()
    assert memory.reader.stopped == [(700, 'C:\\proof\\gcc.exe')]
    assert memory.scanned == [[700, 701, 800, 900]]
    text = (tmp_path / 'events.jsonl').read_text()
    assert '"build_tool_stopped"' in text and '"SATSUMA-BUILD-001"' in text
    assert g.counts['build_tool_stopped'] == 1 and g.counts['sysmon_events'] == 3


def test_during_windows_installer_the_tool_runs_and_is_recorded(tmp_path):
    batch = [{'id': 1, 'record': 2, 'ProcessId': '700', 'Image': 'C:\\x\\csc.exe'}]
    g, memory = make_guard(tmp_path, [batch], pm=True)
    g.check_sysmon()
    assert memory.reader.stopped == [] and '"build_tool_allowed"' in (tmp_path / 'events.jsonl').read_text()


def test_without_sysmon_the_guard_runs_says_so_and_retries(tmp_path):
    clock = [0.0]
    attempts = []
    def missing():
        attempts.append(clock[0])
        raise OSError('channel not found')
    ok = lambda argv, **kw: SimpleNamespace(returncode=0, stdout='{}', stderr='')
    installs = []
    g = Guard(runner=ok, read=lambda: [], directory=tmp_path, echo=lambda *_: None, clock=lambda: clock[0],
              memory_factory=lambda record, directory, key: Memory(), sysmon_factory=missing,
              sysmon_installer=lambda: installs.append(clock[0]) or {'ok': False, 'status': 'DOWNLOAD_FAILED'})
    g.start()
    assert g.startup['sysmon']['status'] == 'UNAVAILABLE'
    g.check_sysmon()
    clock[0] = 61.0
    g.check_sysmon()
    assert attempts == [0.0, 0.0, 61.0]
    assert installs == [0.0], 'Satsuma installs Sysmon itself, at most every ten minutes'
    assert '"sysmon_install"' in (tmp_path / 'events.jsonl').read_text()


@pytest.mark.skipif(__import__('os').name != 'nt', reason='Win32 layer runs only on Windows')
def test_live_stop_if_image_stops_only_the_named_program():
    import subprocess
    import sys
    from satsuma_win.memory import Win32Reader
    reader = Win32Reader()
    child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'])
    try:
        assert reader.stop_if_image(child.pid, 'C:\\Windows\\System32\\notepad.exe') == 'changed'
        assert child.poll() is None
        assert reader.stop_if_image(child.pid, sys.executable) == 'stopped'
        assert child.wait(timeout=10) == 0xC5A75B
    finally:
        if child.poll() is None:
            child.kill()


def test_install_is_ok_only_when_the_event_channel_exists(tmp_path):
    result = sysmon.install(tmp_path, runner(MICROSOFT, channel_missing=True), fetch=lambda u: zipped())
    assert result['ok'] is False and result['status'] == 'CHANNEL_MISSING'


def test_full_access_to_own_child_is_confirmed_other_access_stays_critical(tmp_path):
    import sys as _sys
    own = _sys.executable
    batch = [{'id': 10, 'record': 5, 'SourceImage': own, 'GrantedAccess': '0x1fffff', 'SourceProcessId': '1',
              'TargetProcessId': '5912', 'TargetImage': 'C:\\Windows\\System32\\arp.exe'},
             {'id': 10, 'record': 6, 'SourceImage': own, 'GrantedAccess': '0x1fffff', 'SourceProcessId': '1',
              'TargetProcessId': '6000', 'TargetImage': 'C:\\Windows\\explorer.exe'}]
    memory = Memory()
    ok = lambda argv, **kw: SimpleNamespace(returncode=0, stdout='{}', stderr='')
    g = Guard(runner=ok, read=lambda: [], directory=tmp_path, echo=lambda *_: None,
              memory_factory=lambda record, directory, key: memory, sysmon_factory=lambda: Events([[], batch]),
              own_child=lambda e: None if e['TargetProcessId'] == '5912' else 'hedef süreç Satsuma tarafından başlatılmadı')
    g.start()
    g.check_sysmon()
    lines = [l for l in (tmp_path / 'events.jsonl').read_text(encoding='utf-8').splitlines() if 'satsuma_unexpected_access' in l]
    assert len(lines) == 1 and 'explorer.exe' in lines[0] and 'başlatılmadı' in lines[0]
    assert g.counts['own_child_confirmed'] == 1


def test_a_failed_download_still_loads_the_new_configuration_with_the_signed_sysmon_here(tmp_path):
    # Owner's machine 2026-11-25: two installs timed out downloading and never loaded their configuration.
    def offline(url):
        raise OSError('The read operation timed out')
    sysmon.install(tmp_path, runner(MICROSOFT, installed=True), fetch=lambda u: zipped())
    result = sysmon.install(tmp_path, runner(MICROSOFT, installed=True), fetch=offline)
    assert result['ok'] and result['status'] == 'UPDATED' and result['binary'] == 'already_here'
    assert 'timed out' in result['download_error'] and len(result['config_sha256']) == 64
    # Nothing here yet: still a failed download.
    assert sysmon.install(tmp_path / 'empty', runner(MICROSOFT), fetch=offline)['status'] == 'DOWNLOAD_FAILED'


# --- identity: reused process ids and a replaced Sysmon log (2026-11-25) -------------------------
def filetime(text):
    return sysmon.event_filetime({'UtcTime': text})


def test_event_time_is_a_filetime_and_a_later_process_is_another_process():
    assert filetime('1970-01-01 00:00:00.000') == 11644473600 * 10 ** 7
    assert filetime('1970-01-01 00:00:01.500') - filetime('1970-01-01 00:00:00.000') == 15_000_000
    assert sysmon.event_filetime({}) is None and sysmon.event_filetime({'UtcTime': 'x'}) is None
    event = filetime('2026-11-25 10:00:00.000')
    assert not sysmon.started_after(event - 10 ** 7, event)            # older: the same process
    assert not sysmon.started_after(event + 10 ** 7, event)            # within the slack
    assert sysmon.started_after(event + 30 * 10 ** 7, event)           # created later: reused id
    assert not sysmon.started_after(None, event) and not sysmon.started_after(event, None)


def test_targets_keep_the_latest_event_time_and_unknown_time_means_no_bound():
    targets = {}
    sysmon.add_targets(targets, {'id': 1, 'ProcessId': '700', 'UtcTime': '2026-11-25 10:00:00.000'})
    sysmon.add_targets(targets, {'id': 8, 'TargetProcessId': '700', 'SourceProcessId': '800',
                                 'UtcTime': '2026-11-25 10:00:05.000'})
    assert targets[700] == filetime('2026-11-25 10:00:05.000') and targets[800] == targets[700]
    sysmon.add_targets(targets, {'id': 1, 'ProcessId': '700'})          # no time: no bound, and it stays so
    sysmon.add_targets(targets, {'id': 1, 'ProcessId': '700', 'UtcTime': '2026-11-25 11:00:00.000'})
    assert targets[700] is None


def test_the_guard_passes_the_event_time_to_the_scan_and_the_stop(tmp_path):
    stamp = '2026-11-25 10:00:00.000'
    batch = [{'id': 1, 'record': 2, 'ProcessId': '700', 'Image': 'C:\\proof\\gcc.exe', 'UtcTime': stamp}]
    g, memory = make_guard(tmp_path, [batch])
    calls = []
    memory.reader.stop_if_image = lambda pid, image, not_after=None: calls.append(not_after) or 'stopped'
    seen = []
    memory.scan = lambda pids=None, not_after=None: seen.append((pids, not_after)) or []
    g.check_sysmon()
    assert calls == [filetime(stamp)] and seen == [([700], {700: filetime(stamp)})]


class FakeProcess:
    def __init__(self, created):
        self.created = created

    def read(self):
        return {'pid': 700, 'created': self.created, 'image': 'C:\\x\\a.exe', 'regions': [], 'thread_starts': []}


def test_a_scan_skips_a_process_created_after_the_event_that_named_its_id():
    from contextlib import contextmanager
    from satsuma_win import memory
    event = filetime('2026-11-25 10:00:00.000')
    procs = {700: FakeProcess(event + 60 * 10 ** 7)}

    class R:
        @contextmanager
        def open(self, pid):
            yield procs[pid]

    scanner = memory.Scanner([], R(), lambda kind, **f: f, own_pid=1)
    scanner.scan([700], not_after={700: event})
    assert scanner.counts['identity_changed'] == 1 and scanner.counts['scanned'] == 0
    procs[700] = FakeProcess(event - 10 ** 7)
    scanner.scan([700], not_after={700: event})
    assert scanner.counts['scanned'] == 1
    scanner.scan([700])                                                   # no bound: as before
    assert scanner.counts['scanned'] == 2


class Log:
    """A fake win32evtlog: records {number: time}; queries by 'EventRecordID > n' or '= n'."""
    EvtQueryChannelPath, EvtQueryReverseDirection, EvtRenderEventXml = 1, 2, 1

    def __init__(self, records):
        self.records = dict(records)

    def EvtQuery(self, channel, flags, text):
        if flags & self.EvtQueryReverseDirection:
            return sorted(self.records, reverse=True)
        if 'EventRecordID' not in text:                      # the first read's time window: everything
            return sorted(self.records)
        number = int(text.split()[-1].rstrip(']'))
        if '>' in text:
            return sorted(r for r in self.records if r > number)
        return [r for r in self.records if r == number]

    def EvtNext(self, query, count):
        taken, query[:] = query[:count], query[count:]
        return taken

    def EvtRender(self, handle, flag):
        return ('<Event xmlns="http://schemas.microsoft.com/win/2004/08/events/event"><System>'
                '<EventID>1</EventID><EventRecordID>%d</EventRecordID><TimeCreated SystemTime="%s"/></System>'
                '<EventData></EventData></Event>' % (handle, self.records[handle]))


def test_a_cleared_sysmon_log_does_not_blind_the_reader():
    log = Log({1: 't1', 2: 't2', 3: 't3'})
    reader = sysmon.EventReader(log, clock=lambda: 0.0)
    reader.read()                                           # the first read fixes the cursor at record 3
    assert reader.last == 3
    log.records[4] = 't4'
    assert [e['record'] for e in reader.read()] == [4] and reader.resets == 0
    # Cleared: the numbers start again, and soon pass the old cursor with other times.
    log.records = {1: 'u1', 2: 'u2', 3: 'u3', 4: 'u4', 5: 'u5'}
    assert [e['record'] for e in reader.read()] == [1, 2, 3, 4, 5]
    assert reader.resets == 1 and reader.last == 5
    log.records[6] = 'u6'
    assert [e['record'] for e in reader.read()] == [6] and reader.resets == 1


def test_busy_events_scan_the_same_process_at_most_every_cooldown_but_new_processes_always(tmp_path):
    now = [100.0]
    batch = lambda *events: [dict(e, record=i) for i, e in enumerate(events, 2)]
    load = {'id': 7, 'ProcessId': '700', 'ImageLoaded': 'C:\\x.dll'}
    access = {'id': 10, 'TargetProcessId': '700', 'SourceProcessId': '800'}
    created = {'id': 1, 'ProcessId': '700', 'Image': 'C:\\Windows\\System32\\notepad.exe'}
    g, memory = make_guard(tmp_path, [batch(load, access), batch(load, access), batch(created), batch(load)])
    g.clock = lambda: now[0]
    g.check_sysmon()
    assert memory.scanned == [[700, 800]]
    now[0] += 5
    g.check_sysmon()                                        # inside the cooldown: not scanned again
    assert memory.scanned == [[700, 800]]
    now[0] += 1
    g.check_sysmon()                                        # a new process is always scanned at once
    assert memory.scanned == [[700, 800], [700]]
    now[0] += sysmon.SCAN_COOLDOWN + 1
    g.check_sysmon()                                        # after the cooldown a load scans again
    assert memory.scanned[-1] == [700]
