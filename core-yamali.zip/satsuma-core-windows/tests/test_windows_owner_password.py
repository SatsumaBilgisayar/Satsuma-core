"""The Satsuma administrator password (owner's request 2026-11-25) and the run that ended without a stop."""
import json

from satsuma_win import owner_password, owner_requests
from satsuma_win.liveness import Liveness, MARKER

reverse = lambda data: bytes(reversed(data))


class Clock:
    def __init__(self, now=1000.0):
        self.now = now

    def __call__(self):
        return self.now


def gate(tmp_path, records, clock):
    return owner_password.Gate(tmp_path, reverse, reverse, lambda kind, **f: records.append(dict(kind=kind, **f)) or f,
                               clock=clock)


def setup(tmp_path, records, clock, password='dogru-parola'):
    g = gate(tmp_path, records, clock)
    owner_password.prepare(tmp_path, password, clock=clock)
    g.settle()
    return g


def test_password_is_set_once_and_never_stored(tmp_path):
    records, clock = [], Clock()
    setup(tmp_path, records, clock)
    assert [r['kind'] for r in records] == ['owner_password_set']
    assert not (tmp_path / owner_password.PENDING).exists()
    for f in tmp_path.iterdir():
        assert b'dogru-parola' not in f.read_bytes()


def test_signed_request_passes_once_and_wrong_or_unsigned_is_critical(tmp_path):
    records, clock = [], Clock()
    g = setup(tmp_path, records, clock)
    body = owner_password.sign(tmp_path, 'dogru-parola', {'action': 'unblock', 'ip': '1.2.3.4'}, clock=clock)
    assert g.check(body, 'unblock') is None
    assert g.check(body, 'unblock') == 'aynı istek ikinci kez geldi'
    assert g.check({'action': 'unblock', 'ip': '1.2.3.4'}, 'unblock') == 'parola kanıtı yok'
    bad = owner_password.sign(tmp_path, 'yanlis-parola', {'action': 'unblock', 'ip': '1.2.3.4'}, clock=clock)
    assert g.check(bad, 'unblock') == 'yanlış parola'
    changed = dict(owner_password.sign(tmp_path, 'dogru-parola', {'action': 'unblock', 'ip': '1.2.3.4'}, clock=clock),
                   ip='6.6.6.6')
    assert g.check(changed, 'unblock') == 'yanlış parola'
    refused = [r for r in records if r['kind'] == 'owner_password_refused']
    assert len(refused) == 4 and all(r['severity'] == 'critical' for r in refused)


def test_old_request_and_lockout(tmp_path):
    records, clock = [], Clock()
    g = setup(tmp_path, records, clock)
    old = owner_password.sign(tmp_path, 'dogru-parola', {'action': 'x'}, clock=clock)
    clock.now += owner_password.WINDOW + 1
    assert g.check(old, 'x') == 'istek süresi geçmiş'
    for _ in range(owner_password.MAX_FAILURES):
        g.check(owner_password.sign(tmp_path, 'yanlis-parola', {'action': 'x'}, clock=clock), 'x')
    good = owner_password.sign(tmp_path, 'dogru-parola', {'action': 'x'}, clock=clock)
    assert g.check(good, 'x').startswith('kilitli')
    clock.now += owner_password.LOCKOUT + 1
    assert g.check(owner_password.sign(tmp_path, 'dogru-parola', {'action': 'x'}, clock=clock), 'x') is None


def test_change_needs_the_old_password_and_missing_verifier_is_reported(tmp_path):
    records, clock = [], Clock()
    g = setup(tmp_path, records, clock)
    try:
        owner_password.prepare(tmp_path, 'yeni-parola-1', clock=clock)
        raise AssertionError('eski parola istenmedi')
    except ValueError:
        pass
    owner_password.prepare(tmp_path, 'yeni-parola-1', old_password='yanlis-parola', clock=clock)
    g.settle()
    assert records[-1]['kind'] == 'owner_password_set_refused'
    owner_password.prepare(tmp_path, 'yeni-parola-1', old_password='dogru-parola', clock=clock)
    g.settle()
    assert records[-1]['kind'] == 'owner_password_set'
    assert g.check(owner_password.sign(tmp_path, 'yeni-parola-1', {'a': 1}, clock=clock), 'a') is None
    (tmp_path / owner_password.VERIFIER).unlink()
    g.settle()
    g.settle()
    assert [r['kind'] for r in records].count('owner_password_missing') == 1


def test_applier_refuses_without_the_password(tmp_path):
    records, clock = [], Clock()
    g = setup(tmp_path, records, clock)
    done = []
    applier = owner_requests.Applier(tmp_path, object(), lambda kind, **f: records.append(dict(kind=kind, **f)), None,
                                     lambda ip: done.append(ip) or True, None, None, None, gate=g)
    owner_requests.write(tmp_path, 'unblock', ip='1.1.1.1')
    applier.run()
    assert done == [] and records[-1]['ok'] is False and 'parola' in records[-1]['error']
    g.clock = lambda: __import__('time').time()
    owner_requests.write(tmp_path, 'unblock', password='dogru-parola', ip='2.2.2.2')
    applier.run()
    assert done == ['2.2.2.2'] and records[-1]['ok'] is True
    assert owner_requests.CLOSED.check({}, 'x')


def test_a_run_that_ended_without_stop_is_critical_and_shutdown_is_not(tmp_path):
    records, clock = [], Clock(5000.0)
    rec = lambda kind, **f: records.append(dict(kind=kind, **f)) or f
    first = Liveness(tmp_path, rec, pid=10, boot=100.0, clock=clock)
    assert first.check_previous() is None
    second = Liveness(tmp_path, rec, pid=11, boot=130.0, clock=clock)
    second.check_previous()
    assert records[-1]['kind'] == 'satsuma_ended_without_stop' and records[-1]['previous_pid'] == 10
    second.clean_stop()
    assert json.loads((tmp_path / MARKER).read_text())['clean'] is True
    third = Liveness(tmp_path, rec, pid=12, boot=130.0, clock=clock)
    assert third.check_previous() is None
    fourth = Liveness(tmp_path, rec, pid=13, boot=9000.0, clock=clock)
    fourth.check_previous()
    assert records[-1]['kind'] == 'satsuma_previous_run_ended_by_shutdown'


def test_old_suricata_folders_go_and_the_running_one_stays(tmp_path):
    from satsuma_win import suricata
    root = tmp_path / 'Satsuma' / 'Suricata'
    running = root / '8.0.8' / 'PFiles' / 'Suricata'
    running.mkdir(parents=True)
    (root / '8.0.7').mkdir()
    (root / '8.0.8-20261124').mkdir()
    (tmp_path / 'Satsuma' / 'Suricata-eski').mkdir()
    state = tmp_path / 'state'
    suricata.data_dir(state).mkdir(parents=True)
    (suricata.data_dir(state) / 'engine.json').write_text(json.dumps({'folder': str(running)}))
    result = suricata.cleanup_old(state, root=root)
    assert result['ok'] and len(result['removed']) == 3 and running.is_dir()
    assert not (root / '8.0.7').exists() and not (tmp_path / 'Satsuma' / 'Suricata-eski').exists()


def test_devices_page_shows_disabled_devices_not_plugged_in(tmp_path):
    from satsuma_win import panel_data
    (tmp_path / 'disabled-devices.json').write_text(json.dumps(['SWD\\MSRRAS\\PPPOE', 'USB\\X']))
    events = [{'kind': 'device_disabled', 'id': 'SWD\\MSRRAS\\PPPOE', 'name': 'WAN Miniport (PPPOE)', 'time': 1}]
    rows = panel_data.absent_devices(tmp_path, events, [{'id': 'USB\\X'}])
    assert rows == [{'id': 'SWD\\MSRRAS\\PPPOE', 'name': 'WAN Miniport (PPPOE)', 'category': None, 'absent': True}]


def test_owner_allows_one_program_for_one_rule_by_its_digest(tmp_path):
    from satsuma_win import guard as guard_module

    class Key:
        sign = staticmethod(lambda data: 'sig:' + __import__('hashlib').sha256(data).hexdigest())
        verify = staticmethod(lambda data, sig: sig == 'sig:' + __import__('hashlib').sha256(data).hexdigest())

    tool = tmp_path / 'Unlocker.exe'
    tool.write_bytes(b'unlocker-1.9.2')
    g = guard_module.Guard.__new__(guard_module.Guard)
    g.directory, g.key, g.clock = tmp_path, Key(), lambda: 1.0
    finding = {'rule_id': 'SATSUMA-AI-WIN-TOKEN-SEDEBUGPRIV-HANDLE', 'image': str(tool)}
    assert not g.rule_allowed(finding)
    assert g.allow_rule_process(finding['rule_id'], str(tool))['ok']
    assert g.rule_allowed(finding)
    assert not g.rule_allowed(dict(finding, rule_id='SATSUMA-AI-WIN-OTHER'))
    tool.write_bytes(b'changed')
    assert not g.rule_allowed(finding)  # the file changed: the permission is void


def test_a_twin_of_an_existing_rule_is_refused():
    from satsuma_win.ai_rules import duplicate_of
    old = {'id': 'SATSUMA-AI-WIN-A', 'name': 'a', 'severity': 'high', 'classification': 'likely', 'actions': ['record'],
           'mitre': {'tactic': 'exfiltration', 'technique': 'T1567'},
           'base_match': {'source': 'win_proc', 'exe_regex': ['\\\\rclone\\.exe$'], 'cmd_regex': ['\\bcopy\\b']}}
    new = {'detection': {'id': 'SATSUMA-AI-WIN-B', 'base_match': {'source': 'win_proc', 'exe_regex': ['\\\\rclone\\.exe$']}},
           'test_cases': {'positive': [{'id': 1, 'Image': 'C:\\x\\rclone.exe', 'CommandLine': 'rclone copy a remote:b'}]}}
    assert duplicate_of(new, [old]) == 'SATSUMA-AI-WIN-A'
    new['test_cases']['positive'].append({'id': 1, 'Image': 'C:\\x\\rclone.exe', 'CommandLine': 'rclone sync a remote:b'})
    assert duplicate_of(new, [old]) is None


def test_choice_c_trusts_only_signed_programs_from_system_folders():
    from satsuma_win.netcontext import Context, shared_network
    paths = {1: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
             2: 'C:\\Users\\a\\AppData\\Local\\Temp\\x.exe',
             3: 'C:\\ProgramData\\Microsoft\\Windows Defender\\Platform\\4.18\\MsMpEng.exe',
             4: 'C:\\Program Files\\Bad\\unsigned.exe'}
    ctx = Context(signed=lambda p: 'unsigned' not in p, image=paths.get)
    assert ctx.all_trusted([(1, 'msedge.exe')])[0]
    assert not ctx.all_trusted([(1, 'msedge.exe'), (2, 'x.exe')])[0]   # one untrusted process: the rule blocks
    assert not ctx.all_trusted([(4, 'unsigned.exe')])[0]
    assert not ctx.all_trusted([(9, 'gone.exe')])[0]
    assert not ctx.all_trusted([])[0]
    assert ctx.defender_or_update([(3, 'MsMpEng.exe')]) and not ctx.defender_or_update([(1, 'msedge.exe')])
    assert shared_network('3.173.21.63') and shared_network('104.16.1.1') and not shared_network('51.8.207.171')
