"""RAM v2 is removed: what an earlier version left (clamd on 127.0.0.1:3311, ClamAV folders) is deleted.

RAM v2 kaldırıldı: önceki sürümün bıraktığı (127.0.0.1:3311'deki clamd, ClamAV klasörleri) silinir.
"""
import ast
from pathlib import Path

from satsuma_win import retired

HERE = Path(__file__).resolve().parents[1]


class Proc:
    def __init__(self, pid, name, exe, fail=None):
        self.info = {'pid': pid, 'name': name, 'exe': exe}
        self.fail, self.killed = fail, False

    def kill(self):
        if self.fail:
            raise PermissionError(self.fail)
        self.killed = True

    def wait(self, timeout):
        return 0


def leftover(tmp_path):
    program_files = tmp_path / 'Program Files'
    engine = program_files / 'Satsuma' / 'ClamAV'
    (engine / 'certs').mkdir(parents=True)
    (engine / 'clamd.exe').write_bytes(b'MZ')
    state = tmp_path / 'ProgramData' / 'Satsuma'
    (state / 'clamav' / 'database').mkdir(parents=True)
    (state / 'clamav' / 'database' / 'daily.cvd').write_bytes(b'x')
    (state / 'events.jsonl').write_text('{}\n')
    return {'ProgramFiles': str(program_files)}, engine, state


def test_the_old_clamd_is_stopped_and_both_folders_are_deleted(tmp_path):
    environ, engine, state = leftover(tmp_path)
    own = Proc(10, 'clamd.exe', str(engine / 'clamd.exe'))
    fresh = Proc(11, 'FreshClam.exe', str(engine / 'freshclam.exe'))
    elsewhere = Proc(12, 'clamd.exe', str(tmp_path / 'ClamAV' / 'clamd.exe'))   # the owner's own ClamAV
    lookalike = Proc(13, 'clamd.exe', str(engine) + 'X\\clamd.exe')
    other = Proc(14, 'notepad.exe', str(engine / 'notepad.exe'))
    result = retired.remove(state, environ, processes=lambda: [own, fresh, elsewhere, lookalike, other])
    assert result['ok'] and result['status'] == 'REMOVED'
    assert own.killed and fresh.killed and not elsewhere.killed and not lookalike.killed and not other.killed
    assert [s['pid'] for s in result['stopped']] == [10, 11]
    assert not engine.exists() and not (state / 'clamav').exists()
    assert (state / 'events.jsonl').exists() and engine.parent.exists()   # nothing else is touched


def test_a_clean_machine_reports_nothing_left(tmp_path):
    state = tmp_path / 'ProgramData' / 'Satsuma'
    result = retired.remove(state, {'ProgramFiles': str(tmp_path)}, processes=lambda: [])
    assert result == {'ok': True, 'status': 'NOTHING_LEFT', 'removed': [], 'left': [], 'stopped': [],
                      'stop_failed': []}


def test_a_clamd_that_cannot_be_stopped_is_reported_never_hidden(tmp_path):
    environ, engine, state = leftover(tmp_path)
    stuck = Proc(10, 'clamd.exe', str(engine / 'clamd.exe'), fail='access denied')
    result = retired.remove(state, environ, processes=lambda: [stuck])
    assert not result['ok'] and result['status'] == 'REMOVE_FAILED'
    assert 'access denied' in result['stop_failed'][0]['error']


def test_nothing_in_the_product_listens_on_3311_or_runs_clamd_any_more():
    """No module of the Windows product opens a socket or reaches the RAM v2 code; only comments name it."""
    assert not (HERE / 'satsuma_win' / 'clamav.py').exists() and not (HERE / 'satsuma_win' / 'ramscan.py').exists()
    for path in sorted((HERE / 'satsuma_win').glob('*.py')) + [HERE / 'satsuma_core_windows.py']:
        tree = ast.parse(path.read_text(encoding='utf-8'))
        modules = {alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names}
        modules |= {(node.module or '') + '.' + alias.name for node in ast.walk(tree)
                    if isinstance(node, ast.ImportFrom) for alias in node.names}
        modules |= {node.module or '' for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)}
        assert 'socket' not in modules, path.name
        assert not any(m.split('.')[-1] in ('clamav', 'ramscan', 'clamd', 'coordinator', 'revalidate')
                       or m.startswith('satsuma.ram.engine') for m in modules), (path.name, modules)
        numbers = {node.value for node in ast.walk(tree) if isinstance(node, ast.Constant)}
        assert path.name == 'retired.py' or 3311 not in numbers, path.name


def test_install_answer_is_read_after_powershell_warnings():
    from satsuma_win import service
    out = "WARNING: Waiting for service 'Satsuma Core (SatsumaCore)' to stop...\n" * 3 + '{"ok": true, "status": "Running"}\n'
    assert service._result(out)['status'] == 'Running'


def test_idle_windows_installer_service_is_not_a_running_install():
    from satsuma_win.guard import msiexec_working
    assert not msiexec_working(['C:\\Windows\\system32\\msiexec.exe', '/V'])
    assert msiexec_working(['msiexec.exe', '/i', 'C:\\x.msi', '/qn']) and msiexec_working(['msiexec.exe', '/a', 'x.msi'])


def test_disabled_builtin_admin_missing_deny_is_not_a_failure():
    from satsuma_win.accounts import open_gaps
    accounts = [{'name': 'Administrator', 'sid': 'S-1-5-21-1-2-3-500', 'enabled': False},
                {'name': 'Eve', 'sid': 'S-1-5-21-1-2-3-1002', 'enabled': True}]
    gaps = {'SeDenyInteractiveLogonRight': ['*S-1-5-21-1-2-3-500', '*S-1-5-21-1-2-3-1002']}
    assert open_gaps(gaps, accounts) == {'SeDenyInteractiveLogonRight': ['*S-1-5-21-1-2-3-1002']}
    accounts[0]['enabled'] = True
    assert '*S-1-5-21-1-2-3-500' in open_gaps(gaps, accounts)['SeDenyInteractiveLogonRight']


def test_locked_engine_folder_gets_a_new_folder(tmp_path, monkeypatch):
    from satsuma_win import suricata
    old, staging = tmp_path / '8.0.8', tmp_path / '8.0.8.new'
    old.mkdir(); staging.mkdir(); (staging / 'suricata.exe').write_text('x')
    monkeypatch.setattr(suricata.shutil, 'rmtree', lambda *a, **k: None)  # the old folder stays (locked driver)
    placed = suricata.replace_folder(staging, old)
    assert placed != old and placed.name.startswith('8.0.8-') and (placed / 'suricata.exe').exists() and old.exists()


def test_every_local_account_but_the_owner_is_disabled(tmp_path):
    from satsuma_win.accounts import Accounts
    ran = []
    a = Accounts(tmp_path, None, runner=None)
    import satsuma_win.accounts as mod
    orig = mod.run_powershell
    mod.run_powershell = lambda script, runner=None: ran.append(script) or ''
    try:
        done = a.disable_unused([
            {'name': 'Administrator', 'sid': 'S-1-5-21-1-2-3-500', 'enabled': True},
            {'name': 'Sahip', 'sid': 'S-1-5-21-1-2-3-1001', 'enabled': True},
            {'name': 'Yeni', 'sid': 'S-1-5-21-1-2-3-1002', 'enabled': True},
            {'name': 'Guest', 'sid': 'S-1-5-21-1-2-3-501', 'enabled': False}], 'S-1-5-21-1-2-3-1001')
    finally:
        mod.run_powershell = orig
    assert done == ['Administrator', 'Yeni'] and len(ran) == 2
