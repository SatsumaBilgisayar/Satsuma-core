"""Suricata on Windows: verified install, the Linux configuration, WinDivert inline, drops, restarts, alerts.

Windows'ta Suricata: doğrulanmış kurulum, Linux yapılandırması, WinDivert satır içi, düşürme, yeniden başlatma, uyarılar.
"""
import hashlib
import io
import json
import tarfile
import zipfile
from types import SimpleNamespace

import yaml

from satsuma_win import suricata

SYSTEM_YAML = """%YAML 1.1
---
vars:
  address-groups:
    HOME_NET: "[10.0.0.0/8]"
default-rule-path: C:\\\\Program Files\\\\Suricata\\\\rules
rule-files:
  - suricata.rules
classification-file: C:\\\\Program Files\\\\Suricata\\\\classification.config
outputs:
  - fast:
      enabled: yes
nfq:
  mode: accept
"""
CONFIDENT = ('alert http $HOME_NET any -> $EXTERNAL_NET any (msg:"ET MALWARE x"; content:"a"; '
             'metadata: confidence High, signature_severity Major; sid:2000001; rev:1;)\n')
INFO = ('alert dns $HOME_NET any -> any any (msg:"ET INFO y"; content:"b"; '
        'metadata: confidence Medium, signature_severity Informational; sid:2000002; rev:1;)\n')


def archive(extra=None, top='Suricata'):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as z:
        z.writestr(top + '/suricata.exe', b'MZ suricata')
        z.writestr(top + '/WinDivert.dll', b'MZ dll')
        z.writestr(top + '/WinDivert64.sys', b'MZ sys')
        z.writestr(top + '/suricata.yaml', SYSTEM_YAML)
        z.writestr(top + '/classification.config', 'config classification: x')
        for name, data in (extra or {}).items():
            z.writestr(name, data)
    return buffer.getvalue()


def rules_tar():
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w:gz') as t:
        data = (CONFIDENT + INFO).encode()
        info = tarfile.TarInfo('rules/emerging-malware.rules')
        info.size = len(data)
        t.addfile(info, io.BytesIO(data))
    return buffer.getvalue()


def fetcher(zip_bytes, tar_bytes=None, md5=None):
    tar_bytes = tar_bytes or rules_tar()
    def fetch(url):
        if url == suricata.URL:
            return zip_bytes
        if url.endswith('.md5'):
            return ((md5 or hashlib.md5(tar_bytes).hexdigest()) + '  emerging.rules.tar.gz\n').encode()
        return tar_bytes
    return fetch


def runner(ok=True):
    calls = []
    def run(argv, **kwargs):
        calls.append(argv)
        return SimpleNamespace(returncode=0 if ok else 1, stdout='' if ok else 'bad config', stderr='')
    run.calls = calls
    return run


VALID = lambda path: {'status': 'Valid', 'subject': 'CN=WinDivert'}


def install(tmp_path, data=None, **kw):
    data = data or archive()
    options = dict(runner=runner(), fetch=fetcher(data), expected=hashlib.sha256(data).hexdigest(),
                   signature=VALID, engine=tmp_path / 'engine')
    options.update(kw)
    return suricata.install(tmp_path / 'state', **options)


def test_without_a_pin_or_with_another_archive_nothing_is_installed(tmp_path):
    assert install(tmp_path, expected='')['status'] == 'NO_PIN'
    result = install(tmp_path, expected='0' * 64)
    assert result['status'] == 'ARCHIVE_MISMATCH' and not (tmp_path / 'engine').exists()


def test_an_archive_with_an_escaping_path_is_refused(tmp_path):
    bad = archive({'../evil.exe': b'MZ'})
    assert install(tmp_path, bad, fetch=fetcher(bad), expected=hashlib.sha256(bad).hexdigest())['status'] == 'UNPACK_FAILED'
    assert not (tmp_path / 'evil.exe').exists()


def test_an_unsigned_driver_is_never_installed(tmp_path):
    result = install(tmp_path, signature=lambda path: {'status': 'NotSigned'})
    assert result['status'] == 'DRIVER_SIGNATURE_REJECTED' and not (tmp_path / 'engine').exists()


def test_a_verified_archive_installs_with_rules_drops_and_a_tested_config(tmp_path):
    run = runner()
    result = install(tmp_path, runner=run)
    assert result['ok'] and result['status'] == 'INSTALLED' and result['rules']['drops'] == 1
    state = tmp_path / 'state' / 'suricata'
    rules = (state / 'rules' / 'suricata.rules').read_text()
    assert rules.count('drop http') == 2 and 'alert dns' in rules and suricata.PROOF_TOKEN in rules
    assert run.calls[-1][1] == '-T'
    config = yaml.safe_load((state / 'suricata.yaml').read_text())
    assert 'nfq' not in config and config['unix-command'] == {'enabled': 'no'}
    assert config['stream']['inline'] == 'yes' and config['stream']['bypass'] == 'no'
    assert config['rule-files'] == ['suricata.rules'] and config['default-rule-path'].endswith('rules')
    assert config['classification-file'].endswith('classification.config')
    eve = [o for o in config['outputs'] if 'eve-log' in o]
    assert eve and 'alert' in json.dumps(eve)
    assert json.loads((state / 'engine.json').read_text())['folder'].endswith('Suricata')


def test_rules_with_a_wrong_md5_are_refused(tmp_path):
    data = archive()
    result = install(tmp_path, fetch=fetcher(data, md5='0' * 32))
    assert not result['ok'] and result['rules']['status'] == 'RULES_UNAVAILABLE'


def test_a_config_suricata_rejects_is_reported(tmp_path):
    result = install(tmp_path, runner=runner(ok=False))
    assert result['status'] == 'CONFIG_REJECTED' and 'bad config' in result['error']


def test_only_confident_major_et_rules_become_drops():
    text, converted = suricata.drop_converted(CONFIDENT + INFO + '# alert comment confidence High signature_severity Major\n')
    assert converted == 1 and text.startswith('drop http') and '\nalert dns' in text and '# alert comment' in text


def test_suricata_runs_inline_through_windivert_without_loopback(tmp_path):
    argv = suricata.command(r'C:\Program Files\Satsuma\Suricata\8.0.8\Suricata', tmp_path)
    index = argv.index('--windivert')
    assert argv[index + 1] == 'not loopback' and '--init-errors-fatal' in argv and 'stream.inline=yes' in argv


class Proc:
    def __init__(self):
        self.pid, self.returncode, self.terminated = 4242, None, False

    def poll(self):
        return self.returncode

    def terminate(self):
        self.terminated, self.returncode = True, 0

    def wait(self, timeout):
        return 0


class Job:
    def __init__(self):
        self.added = []

    def add(self, process):
        self.added.append(process)


def runtime(tmp_path, clock):
    install(tmp_path)
    records, started, jobs = [], [], []
    def popen(argv):
        started.append(argv)
        return Proc()
    def job():
        jobs.append(Job())
        return jobs[-1]
    rt = suricata.Runtime(tmp_path / 'state', lambda kind, **f: records.append((kind, f)) or f, clock=lambda: clock[0],
                          popen=popen, job=job)
    rt.installer = lambda: {'ok': True}
    rt.rules_updater = lambda: {'ok': True}
    return rt, records, started, jobs


def test_a_stopped_suricata_is_reported_and_restarted_once_a_minute(tmp_path):
    clock = [100.0]
    rt, records, started, jobs = runtime(tmp_path, clock)
    assert rt.start()['status'] == 'RUNNING' and jobs[0].added == [rt.process]
    rt.process.returncode = 1
    rt.check()
    assert [k for k, _ in records][:1] == ['suricata_exited'] and len(started) == 1
    clock[0] += suricata.RESTART_EVERY
    rt.check()
    assert len(started) == 2 and 'suricata_started' in [k for k, _ in records]


def test_eve_alerts_are_recorded_from_where_reading_started(tmp_path):
    clock = [100.0]
    rt, records, _, _ = runtime(tmp_path, clock)
    log = tmp_path / 'state' / 'suricata' / 'log' / 'eve.json'
    log.write_text(json.dumps({'event_type': 'alert', 'alert': {'signature_id': 1}}) + '\n')
    assert rt.alerts() == []                     # what was there before the service started is not replayed
    with open(log, 'a') as stream:
        stream.write(json.dumps({'event_type': 'flow'}) + '\n')
        stream.write(json.dumps({'event_type': 'alert', 'src_ip': '10.0.0.5', 'dest_ip': '203.0.113.9', 'dest_port': 80,
                                 'alert': {'signature_id': suricata.PROOF_SID, 'signature': 'SATSUMA IPS self-test',
                                           'action': 'blocked', 'severity': 3}}) + '\n')
        stream.write('{"event_type": "alert", "partial')
    alerts = rt.alerts()
    assert len(alerts) == 1 and alerts[0]['sid'] == suricata.PROOF_SID and alerts[0]['action'] == 'blocked'
    assert rt.counts['blocked'] == 1


def test_a_missing_suricata_is_installed_in_the_background_and_rules_refresh_daily(tmp_path):
    clock = [100.0]
    records = []
    rt = suricata.Runtime(tmp_path / 'state', lambda kind, **f: records.append((kind, f)) or f, clock=lambda: clock[0],
                          popen=lambda argv: Proc(), job=Job)
    rt.installer = lambda: {'ok': True, 'status': 'INSTALLED'}
    rt.background()
    rt.worker.join(5)
    rt.background()
    assert ('suricata_install', {'ok': True, 'status': 'INSTALLED'}) in records
    install(tmp_path)
    rt.rules_updater = lambda: {'ok': True, 'status': 'UPDATED'}
    rt.background()                     # installed now: the daily clock starts
    clock[0] += suricata.RULES_EVERY
    rt.background()
    rt.worker.join(5)
    rt.background()
    assert ('suricata_rules_update', {'ok': True, 'status': 'UPDATED'}) in records


def test_the_pin_is_read_only_for_this_archive(tmp_path, monkeypatch):
    import sys
    (tmp_path / 'suricata-pin.json').write_text(json.dumps({'archive': suricata.ARCHIVE, 'sha256': 'a' * 64}))
    monkeypatch.setattr(sys, '_MEIPASS', str(tmp_path), raising=False)
    assert suricata.pin() == 'a' * 64
    (tmp_path / 'suricata-pin.json').write_text(json.dumps({'archive': 'other.zip', 'sha256': 'a' * 64}))
    assert suricata.pin() is None
